from moviepy import editor
import os
import sys
import speech_recognition as sr
def SpeechToText(filename:str, lang="en"):
	editor.AudioFileClip(filename).write_audiofile(f"{filename}.wav")
	listen=sr.Recognizer()
	with sr.AudioFile(f"{filename}.wav") as source:
		audio = listen.record(source)
		result=listen.recognize_google(audio, language=lang, show_all=True)
		pesan=""
		#print(lang)
		if result:
			x="Transcript"
			for i in result["alternative"]:
				pesan+=f"{x}:  {i['transcript']} \n\n"
				x="Alternatif"
			print(pesan.strip())
		else:
			print("Gagal Menerjemahkan Audio")

def main():
	#path = input(f"Input list > ")
	path = str(sys.argv[1])
	SpeechToText(path, lang='id')


if __name__ == '__main__':
	main()

