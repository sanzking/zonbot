const { WAConnection, MessageType, Presence, MessageOptions, Mimetype, Browsers, WALocationMessage, WA_MESSAGE_STUB_TYPES, ReconnectMode, ProxyAgent, GroupSettingChange, waChatKey, mentionedJid, processTime } = require("@adiwajshing/baileys")
const benny = new WAConnection()
benny.logger.level = 'warn'
benny.browserDescription = Browsers.ubuntu('Safari')
const qrcode = require("qrcode-terminal")
const qrcodes = require("qrcode")
const moment = require("moment-timezone")
const fs = require("fs")
const { addCommands, checkCommands, deleteCommands } = require('./lib/autoresp')
const { addBadword, checkBadword, deleteBadword } = require('./lib/badword')
const commandsDB = JSON.parse(fs.readFileSync('./src/autoresp.json'))
const badwordDB = JSON.parse(fs.readFileSync('./src/badword.json'))
const ms = require('parse-ms')
const toMs = require('ms')
var util = require('util')
const crypto = require('crypto')
const fetch = require('node-fetch')
const { EmojiAPI } = require("emoji-api");
const emojiss = new EmojiAPI()
const loggc = JSON.parse(fs.readFileSync('./src/loggc.json'))
const { color, bgcolor } = require('./lib/color')
const translate = require('@vitalets/google-translate-api')
const imgtopdf = require("pdfkit")
const { donasi } = require('./lib/donasi')
const { fetchJson, uploadImages } = require('./lib/fetcher')
const { uploadimg } = require('./lib/uploadimage')
const { webp2mp4Url, webp2gifFile, reverseVideoFile, voiceremover } = require('./lib/ezgif')
const { recognize } = require('./lib/ocr')
const os = require('os')
const PasteGG = require('paste.gg')
const BitlyClient = require('bitly').BitlyClient;
const bitly = new BitlyClient('50bcf0925ccd566144dff12dde796ac252034d9d');
const pasteGG = new PasteGG()
const { wait, simih, kepo, generateMessageID, getGroupAdmins, getRandom, banner, custom, halah, hilih, huluh, heleh, holoh, start, info, success, close } = require('./lib/functions')
const igdl = require('instagram-scraping')
const { yta, ytv, buffer2Stream, ytsr, baseURI, stream2Buffer, noop } = require('./lib/ytdl')
const igdls = require('instagram-url-direct')
const cheerio = require('cheerio')
const infotlp = require('no-telp')
const { addbot, addBot } = require('./lib/addbot')
const ytdl = require('ytdownload')
const ytsearch = require('scrape-youtube').default;
const brainly = require('brainly-scraper')
const axios = require("axios")
const request = require('request')
const igstalk = require('instatouch')
const sID = process.env.sID;
const rumus = require('rumus-bdr')
const angkab = require('@develoka/angka-terbilang-js')
const ffmpeg = require('fluent-ffmpeg')
const imageToBase64 = require('image-to-base64');
const base64ToImage = require('base64-to-image');
var base64Img = require('base64-img');
const { removeBackgroundFromImageFile, RemoveBgResult, RemoveBgError, removeBackgroundFromImageUrl } = require('remove.bg')
const kasar = JSON.parse(fs.readFileSync('./src/antibadword.json'))
const ls = fs.readdirSync('./')
const virus = JSON.parse(fs.readFileSync('./src/antivirus.json'))
const autostick = JSON.parse(fs.readFileSync('./src/autosticker.json'))
const _autostick = JSON.parse(fs.readFileSync('./src/autostickpc.json'))
const kotor = JSON.parse(fs.readFileSync('./src/kasar.json'))
const _registered = JSON.parse(fs.readFileSync('./src/registered.json'))
const register = require('./functions/register')
const reminder = require('./functions/reminder')
const _reminder = JSON.parse(fs.readFileSync('./src/reminder.json'))
const _level = JSON.parse(fs.readFileSync('./src/level.json'))
const anlink = JSON.parse(fs.readFileSync('./src/antilink.json'))
let ownerNumber = JSON.parse(fs.readFileSync('./setting.json'))
const _premium = JSON.parse(fs.readFileSync('./src/premium.json'))
const _sewa = JSON.parse(fs.readFileSync('./src/sewa.json'))
const kickarea = JSON.parse(fs.readFileSync('./src/kickarea.json'))
const _ban = JSON.parse(fs.readFileSync('./src/banned.json'))
const _bot = JSON.parse(fs.readFileSync('./src/bot.json'))
const _afk = JSON.parse(fs.readFileSync('./src/afk.json'))
const limit = require('./functions/limit')
let _limit = JSON.parse(fs.readFileSync('./src/limit.json'))
const botHit = JSON.parse(fs.readFileSync('./src/botHit.json'))
const _porn = JSON.parse(fs.readFileSync('./src/aporn.json'))
const jadwas = require('./lib/jadwalsholat')
const hit = require('./functions/hit')
const _hit = JSON.parse(fs.readFileSync('./src/userhit.json'))
const premium = require('./functions/premium')
const sewa = require('./functions/sewa')
const afk = require('./functions/afk')
const welkom = JSON.parse(fs.readFileSync('./src/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./src/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./src/simi.json'))
const setiker = JSON.parse(fs.readFileSync('./src/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./src/video.json'))
const audionye = JSON.parse(fs.readFileSync('./src/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./src/image.json'))
const Math_js = require('mathjs')
const speed = require('performance-now')
const speedTest = require('@lh2020/speedtest-net');
const time = moment().tz('Asia/Jakarta').format("HH:mm:ss DD:MM:YYYY")
const cron = require('node-cron')
const { exec, spawn } = require("child_process")

const mediafireDl = async (url) => {
const res = await axios.get(url) 
const $ = cheerio.load(res.data)
const link = $('a#downloadButton').attr('href')
const size = $('a#downloadButton').text().replace('Download', '').replace('(', '').replace(')', '').replace('\n', '').replace('\n', '').replace('                         ', '')
const seplit = link.split('/')
const nama = seplit[5]
mime = nama.split('.')
mime = mime[1]
return { nama, mime, size, link }
}

const getBuffer = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (e) {
		console.log(`Error : ${e}`)
	}
}

const getBaper = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (e) {
		console.log(`Error : ${e}`)
	}
}

const getName = (jid) => {
	if (jid == benny.user.jid) return benny.user.name
	const nama = benny.contacts[jid]
	console.log(nama)
	name = nama.notify || nama.vname || nama.name || 'Tidak Terbaca'
	return name
}

// Message filter
const usedCommandRecently = new Set()

const isFiltered = (from) => {
    return !!usedCommandRecently.has(from)
}

const addFilter = (from) => {
    usedCommandRecently.add(from)
    setTimeout(() => {
        return usedCommandRecently.delete(from)
    }, 5000) // 5 seconds delay, I don't recommend below that.
}

const jadwalSolat = async(tempat) => {
const url = `https://m.dream.co.id/jadwal-salat/${tempat}`
const res = await axios.get(url)
const $ = cheerio.load(res.data)
const a = $('table').find('tbody > tr > td')
const emror = "_[ ! ] Error Daerah Tidak DiTemukan_"
const daerah = url.split('/')[4]
const tanggal = $(a).eq(0).text()
const shubuh = $(a).eq(1).text()
const dzuhur = $(a).eq(2).text()
const ashar = $(a).eq(3).text()
const maghrib = $(a).eq(4).text()
const isya = $(a).eq(5).text()
return { daerah, tanggal, shubuh, dzuhur, ashar, maghrib, isya}
}

const uploadBerkas = (path) => new Promise((resolve, reject) => {
     const {default: Axios} = require('axios')
     const FormData = require('form-data')
     const fd = new FormData()
     fd.append('sampleFile', fs.createReadStream(path))
     Axios({
          method: 'POST',
          url: 'https://top4top.io/index.php',
          data: fd,
          headers: {
               'user-agent': 'MRHRTZ-ZONE :D',
               'content-type': `multipart/form-data; boundary=${fd._boundary}`
          }
     }).then(({ data }) => resolve(data)).catch(reject)
})

async function uploadMedia(path) {
	return new Promise((resolve, reject) => {
	Form = require('form-data'),
	form = new Form(),
	form.append('file', fs.createReadStream(path))
	fetch('https://storage.restfulapi.my.id/upload', {
		method: 'post',
		body: form
	})
	.then(res => res.json())
	.then(resolve)
	.catch(reject)
	})
}

const wikiSearch = async (query) => {
const res = await axios.get(`https://id.m.wikipedia.org/wiki/${query}`)
const $ = cheerio.load(res.data)
let wiki = $('#mf-section-0').find('p').text()
let thumb = 'https:' + $('#mf-section-0').find('div > div > a > img').attr('src')
let judul = $('h1#section_0').text()
return { wiki, thumb, judul }
}

const kusonime = async(query) => {
	const ling = await axios.get(`https://kusonime.com/?s=${query}&post_type=post`)
const $ = cheerio.load(ling.data)
const hasil = []
 
const link = $('div.venz > ul > div.kover > div.detpost > div.content > h2.episodeye > a').attr('href')
const judul = $('div.venz > ul > div.kover > div.detpost > div.content > h2.episodeye > a').attr('title')
 
 
const lling = await axios.get(`${link}`) 
const $$ = cheerio.load(lling.data)
const img = $$('div.venser > div.post-thumb > img').attr('src')
const title_japanese = $$('div.venser > div.venutama > div.lexot > div.info > p').eq(0).text().replace('Japanese: ','')
const genre = $$('div.venser > div.venutama > div.lexot > div.info > p').eq(1).text().replace('Genre : ','')
const season =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(2).text().replace('Seasons : ','')
const producer =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(3).text().replace('Producers: ','')
const tipe =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(4).text().replace('Type: ','')
const status = $$('div.venser > div.venutama > div.lexot > div.info > p').eq(5).text().replace('Status: ','')
const total_eps =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(6).text().replace('Total Episode: ','')
const score =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(7).text().replace('Score: ','')
const duration =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(8).text().replace('Duration: ','')
const rilis =  $$('div.venser > div.venutama > div.lexot > div.info > p').eq(9).text().replace('Released on: ','')
return { link, judul, img, title_japanese, genre, season, producer, tipe, status, total_eps, score, duration, rilis }
}

async function ArtiNama(nama) {
  return new Promise((resolve, reject) => {
    axios.get(`https://www.primbon.com/arti_nama.php?nama1=${nama}&proses=+Submit%21+`)
      .then(({
        data
      }) => {
        const $ = cheerio.load(data)
        const isi = $('#body').text().split('Nama:')[0].replace(/\n\n\n\n\n\n\n\n\n/gi, '\n').split('ARTI NAMA\n')[1].replace('\n      \n        \n        \n          ', '')
          resolve(isi)
      })
      .catch(reject)
  })
}

async function ArtiMimpi(mimpi) {
  return new Promise((resolve, reject) => {
    axios.get(`https://www.primbon.com/tafsir_mimpi.php?mimpi=${mimpi}&submit=+Submit+`)
      .then(({
        data
      }) => {
        const $ = cheerio.load(data)
        const detect = $('#body > font > i').text()
        const isAva = /Tidak ditemukan/g.test(detect) ? false : true
        if (isAva) {
          const isi = $('#body').text().split(`Hasil pencarian untuk kata kunci: ${mimpi}`)[1].replace(/\n\n\n\n\n\n\n\n\n/gi, '\n')
          resolve(isi)
        } else {
          const res = {
            status: 404,
            result: `Arti Mimpi ${mimpi} Tidak Di Temukan`
          }
          resolve(res)
        }
      })
      .catch(reject)
  })
}

function kbbiSearch(KATA) {
    return new Promise(function (resolve, reject) {                                                                                                                                                               //<https://github.com/ArugaZ/whatsapp-bot>
		axios.get(`https://kbbi.kemdikbud.go.id/entri/${KATA}`)
		.then(req => {
			try {
				const arti = []
				let soup = cheerio.load(req.data)
				soup('ol').each(function(a, b) {
					soup(b).find('li').each(function(c, d) {
						arti.push(soup(d).text())
					})
				})
				soup('ul.adjusted-par').each(function(a, b) {
					soup(b).find('li').each(function(c, d) {
						arti.push(soup(d).text())
					})
				})
				resolve({result: arti})
			} catch (err) {
				reject({
					status: 'error',
					error: err
				})
			}
		})
		.catch((err) => {
			reject({
				status: 'error',
				error: err
			})
		})
	})
}
 
const uploadFile = (path) => new Promise((resolve, reject) => {
	const { default: Axios } = require('axios')
	const FormData = require('form-data')
     const fd = new FormData()
     fd.append('sampleFile', fs.createReadStream(path))
     Axios({
          method: 'POST',
          url: 'https://pecundang.herokuapp.com/upload',
          data: fd,
          headers: {
               'user-agent': 'MRHRTZ-ZONE :D',
               'content-type': `multipart/form-data; boundary=${fd._boundary}`
          }
     }).then(({ data }) => resolve(data)).catch(reject)
})

const uploadimgs = async (filename, name) => {
	const FormData = require('form-data')
    var image = fs.readFileSync(filename)
    var form = new FormData()
	
    form.append('files[]', image, name)
     
    const upload = fetch('https://uguu.se/upload.php', {
        method: 'POST',
        body: form
    }).then((response) => response.json())
        .then((result) => {
			console.log(result)
            return result
        })
        .catch(e => {
            return e
        })
    return upload
}

const resepnya = async (QUERY) => {
	try {
		const resep1 = await axios.get(`https://masak-apa.tomorisakura.vercel.app/api/search/?q=${QUERY}`)
		if (resep1.data.results[0] == '' || resep1.data.results[0] == undefined)
			return {
				"status": 200,
				"error": "Query yang anda cari tidak tersedia!"
			}
		//console.log(resep1)
		const random = Math.floor(Math.random() * resep1.data.results.length);
		const resep2 = await axios.get('https://masak-apa.tomorisakura.vercel.app/api/recipe/' + resep1.data.results[random].key)
		//console.log(resep2)
		const results = resep2.data.results
		return {
			results
		}
	} catch (err) {
		return { err }
	}
}

const jagoKata = async (query) => {
const base = `https://jagokata.com/kata-bijak/kata-${query}.html`
const des = await axios.get(base)
const sup = cheerio.load(des.data)
var page = sup('h4 > strong').eq(2).text() / 10
page = parseInt(page)
const randomPage = Math.floor(Math.random() * page)
const res = await axios.get(`${base}?page=${randomPage}`)
const $ = cheerio.load(res.data)
const hasil = []
const list = $('ul > li')
const random = Math.floor(Math.random() * 10)
const isi = $(list).find('q.fbquote').eq(random).text() 

var by = $(list).find('div > div > a').eq(random).text()
by = by ? by : "Kang Galon"
return { isi,  by }
}

const alay = (text) => {
     const K = new RegExp("[AaOoIiSs]", "g")
    text = text.replace(K, "4", "6", "0", "1", "5")
    return text
}

var dates = moment().tz('Asia/Jakarta').format("YYYY-MM-DDTHH:mm:ss");
		var date = new Date(dates);
        var tahun = date.getFullYear();
        var bulan1 = date.getMonth();
        var tanggal = date.getDate();
        var hari = date.getDay();
        var haris = date.getDay();
        var jam = date.getHours();
        var menit = date.getMinutes();
        var detik = date.getSeconds();
        var waktoo = date.getHours();
            switch(hari) {
                case 0: hari = "Minggu"; break;
                case 1: hari = "Senin"; break;
                case 2: hari = "Selasa"; break;
                case 3: hari = "Rabu"; break;
                case 4: hari = "Kamis"; break;
                case 5: hari = "Jum`at"; break;
                case 6: hari = "Sabtu"; break;
            }
            switch(bulan1) {
                case 0: bulan1 = "Januari"; break;
                case 1: bulan1 = "Februari"; break;
                case 2: bulan1 = "Maret"; break;
                case 3: bulan1 = "April"; break;
                case 4: bulan1 = "Mei"; break;
                case 5: bulan1 = "Juni"; break;
                case 6: bulan1 = "Juli"; break;
                case 7: bulan1 = "Agustus"; break;
                case 8: bulan1 = "September"; break;
                case 9: bulan1 = "Oktober"; break;
                case 10: bulan1 = "November"; break;
                case 11: bulan1 = "Desember"; break;
            }
            switch(waktoo){
                case 0: waktoo = "Tengah Malam🌚 - Tidur Kak:)"; break;
                case 1: waktoo = "Tengah Malam🌚 - Tidur Kak:)"; break;
                case 2: waktoo = "Dini Hari🌒 - Tidur Kak:)"; break;
                case 3: waktoo = "Dini Hari🌓 - Tidur Kak:)"; break;
                case 4: waktoo = "Subuh🌔"; break;
                case 5: waktoo = "Subuh🌔"; break;
                case 6: waktoo = "Selamat Pagi🌝"; break;
                case 7: waktoo = "Selamat Pagi🌝"; break;
                case 8: waktoo = "Selamat Pagi🌝"; break;
                case 9: waktoo = "Selamat Pagi"; break;
                case 10: waktoo = "Selamat Pagi🌞"; break;
                case 11: waktoo = "Selamat Siang🌞"; break;
                case 12: waktoo = "Selamat Siang🌞"; break;
                case 13: waktoo = "Selamat Siang🌞"; break;
                case 14: waktoo = "Selamat Siang🌞"; break;
                case 15: waktoo = "Selamat Sore🌝"; break;
                case 16: waktoo = "Selamat Sore🌝"; break;
                case 17: waktoo = "Selamat Sore🌖"; break;
                case 18: waktoo = "Magrib🌘"; break;
                case 19: waktoo = "Magrib🌚"; break;
                case 20: waktoo = "Selamat Malam🌚"; break;
                case 21: waktoo = "Selamat Malam🌚"; break;
                case 22: waktoo = "Selamat Malam🌚"; break;
                case 23: waktoo = "Tengah Malam🌚 - Tidur Kak:)"; break;
            }
            var tampilTanggal = "" + hari + ", " + tanggal + " " + bulan1 + " " + tahun;
            var tampilHari = "" + waktoo;
            var tampilWaktu = moment().tz('Asia/Jakarta').format("HH:mm:ss");
            var tampilWaktus = moment().tz('Asia/Makassar').format("HH:mm:ss");
            var tampilWaktuss = moment().tz('Asia/Jayapura').format("HH:mm:ss");

prefix2 = '#'
baterai = {
	battery: "" || "Tidak terdeteksi",
	isCharge: "" || false
}
numbernye = '0@s.whatsapp.net'
fake = `SELFBOT`
teroli = 99999999999999
namabot = 'MohammadBOT'
namastc = `./src/iri.mp3`
targetprivate = '0'
blocked = []            
banChats = true
autojoin = false
antitag = true
autoblock = false
autodemote = false
autoread = false
autoget = false
banChat = false
tebakgamb = false
setgrup = "6289636006352-1606097314@g.us"
alasanoff = 'Mengtidur'
simple = true
monospace = '```'
logprofile = false
blockcall = false
harganya = '150000000'
totalhit = 0
setthumb = fs.readFileSync('./src/sticker/keseltag.webp')
waktuafk = `${time}`
lbua = 'https://paste.gg/p/bennyhidayat21/44f950b1ca1d4448b8d012afe6a51229'
reason = 'Nothing'
txtwl = ''
adadeh = ''
waktuoff = `${time}`
const limitCount = 25
const hitCount = 0
const arrayBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']

const bulan = arrayBulan[moment().format('MM') - 1]

function joinGroup(link) {
	benny.query({
json:["action", "invite", `${link.replace('https://chat.whatsapp.com/','')}`]
})
}

async function groupInfo(link) {
	const gcinfo = await benny.query({
json:["query", "invite", link.replace('https://chat.whatsapp.com/','')]
})
console.log(gcinfo)
return gcinfo
}

function revokeLink(jid) {
	benny.query({
json:["action", "inviteReset", jid]
})
}

function getGempa() {
	const {default: Axios} = require('axios')
	const cheerio = require('cheerio')
     return new Promise((resolve, reject) => {
          Axios.get('https://www.bmkg.go.id/')
               .then(({ data }) => {
                    const $ = cheerio.load(data)
                    // console.log(data);
                    resolve({
                         status: true,
                         gambar: $('div.gempabumi-home-bg.margin-top-13 > div > div:nth-child(1) > a').attr('href'),
                         waktu: $('span.waktu').text(),
                         magnitudo: $('div.gempabumi-detail > ul > li:nth-child(2)').text(),
                         kedalaman: $('div.gempabumi-detail > ul > li:nth-child(3)').text(),
                         koordinat: $('div.gempabumi-detail > ul > li:nth-child(4)').text(),
                         lokasi: $('div.gempabumi-detail > ul > li:nth-child(5)').text(),
                         tsunami: $('div.gempabumi-detail > ul > li:nth-child(6)').text()
                    })
               })
               .catch((response) => {
                    reject({ status: false, message: response })
               })
     })
}

function tek(seconds){
  function tok(s){
    return (s < 10 ? '' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${tok(hours)}Jam ${tok(minutes)}Menit ${tok(seconds)}Detik`
}

function speedText(speed) {
    let bits = speed * 8;
    const units = ['', 'K', 'M', 'G', 'T'];
    const places = [0, 1, 2, 3, 3];
    let unit = 0;
    while (bits >= 2000 && unit < 4) {
      unit++;
      bits /= 1000;
    }

    return `${bits.toFixed(places[unit])} ${units[unit]}bps`;
}

benny.on('qr', qr => {
	
   qrcode.generate(qr, { small: true })
    console.log(`[ ${time} ] Sqan Qr nih`)
   console.log(color('B', 'green'), color('e', 'red'), color('n', 'yellow'), color('n', 'purple'), color('y', 'blue'), color('BOT', 'cyan'))
   console.log(color('SUPPORT by https://pecundang.herokuapp.com', 'cyan'))
})

benny.on('credentials-updated', () => {
   const authInfo = benny.base64EncodedAuthInfo()
   console.log(`credentials updated!`)
   
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t'))
   benny.logger.info('Welcome Back Owner Have Fun With This Script :)')
})

fs.existsSync('./session.json') && benny.loadAuthInfo('./session.json')

benny.connect();

benny.on('CB:Chat,cmd:action', async (mek) => {
	if (!loggc.includes(mek[1].id)) return
	const groupMetadata = await benny.groupMetadata(mek[1].id)
	const groupMembers = groupMetadata.participants
	const groupAdmins = getGroupAdmins(groupMembers)
	const isBotGroupAdmins = groupAdmins.includes(benny.user.jid)
	console.log(mek[1])
	if (mek[1].data[0] == 'announce') {
	if (mek[1].data[0] == 'announce' && mek[1].data[2] == true && isBotGroupAdmins) return benny.sendMessage(mek[1].id, `*Group telah ditutup oleh admin:* @${mek[1].data[1].split('@')[0]}`, MessageType.text, {contextInfo: {mentionedJid: [mek[1].data[1].replace('c.us', 's.whatsapp.net')]}})
	if (mek[1].data[0] == 'announce' && mek[1].data[2] == false) return benny.sendMessage(mek[1].id, `*Group telah dibuka oleh admin:* @${mek[1].data[1].split('@')[0]}`, MessageType.text, {contextInfo: {mentionedJid: [mek[1].data[1].replace('c.us', 's.whatsapp.net')]}})
	} else if (mek[1].data[0] == 'subject') {
	benny.sendMessage(mek[1].id, `*Nama group telah diubah oleh admin:* @${mek[1].data[1].split('@')[0]} *menjadi:* ${mek[1].data[2].subject}`, MessageType.text, {contextInfo: {mentionedJid: [mek[1].data[1].replace('c.us', 's.whatsapp.net')]}})
	} else if (mek[1].data[0] == 'ephemeral') {
	if (mek[1].data[0] == 'ephemeral' && mek[1].data[2] == 604800 && isBotGroupAdmins) return benny.sendMessage(mek[1].id, `*Admin* @${mek[1].data[1].split('@')[0]} *Telah menyalakan pesan sementara*`, MessageType.text, {contextInfo: {mentionedJid: [mek[1].data[1].replace('c.us', 's.whatsapp.net')]}})
	if (mek[1].data[0] == 'ephemeral' && mek[1].data[2] == 0) return benny.sendMessage(mek[1].id, `*Admin* @${mek[1].data[1].split('@')[0]} *Telah mematikan pesan sementara*`, MessageType.text, {contextInfo: {mentionedJid: [mek[1].data[1].replace('c.us', 's.whatsapp.net')]}})
} else if (mek[1].data[0] == 'desc_add') {
	if (mek[1].data[0] == 'desc_add') return benny.sendMessage(mek[1].id, `*Admin* @${mek[1].data[1].split('@')[0]} *Telah mengubah deskripsi group menjadi:*\n${mek[1].data[2].desc}`, MessageType.text, {contextInfo: {mentionedJid: [mek[1].data[1].replace('c.us', 's.whatsapp.net')]}})
}
})

benny.on('contact-update', async (lan) => {
	console.log(lan)
})

benny.on('CB:action,,user', async (hexa) => {
	console.log(hexa)
})

benny.on('CB:Cmd,type:picture', async (BTS) => {
	benny.setProfilePicture(BTS[1])
	if (!logprofile) return
	console.log(BTS)
	if (BTS[1].jid == '6282299784421@c.us') return
	try {
					ppimg = await benny.getProfilePicture(BTS[1].jid.split('@')[0] + '@s.whatsapp.net')
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
	buffer = await getBaper(ppimg)
	benny.sendMessage(BTS[1].jid.split('@')[0] + '@s.whatsapp.net', buffer, MessageType.image, {caption: '*Anda telah mengubah profile picture*'})
})

benny.on('CB:Status,status', async (lol) => {
	if (!logprofile) return
	console.log(lol)
	benny.sendMessage(lol[1].id.replace('c.us', 's.whatsapp.net'), `*Anda telah mengubah bio menjadi:* ${lol[1].status}`, MessageType.text, {quoted: adadeh})
})

benny.on("CB:action,,battery", json => {
	  const battery = json[2][0][1].value
	  const persenbat = parseInt(battery)
	  baterai.battery = `${persenbat}%`
	  baterai.isCharge = json[2][0][1].live
})

benny.on('CB:pushname', async (bts) => {
	if (!logprofile) return
	console.log(bts)
})

benny.on("CB:Call", json => {
	 if (blockcall === false) return
	  let call;
	  calling = JSON.parse(JSON.stringify(json))
	  call = calling[1].from
		  benny.sendMessage(call, `*Maaf ${benny.user.name} tidak bisa menerima panggilan.*\n*Nelfon = Block!*`, MessageType.text)
		  .then(() => benny.blockUser(call, "add"))

})

benny.on('message-new', async (ben) => {
	try {
		if (!ben.message) return
		ben.message = (Object.keys(ben.message)[0] === 'ephemeralMessage') ? ben.message.ephemeralMessage.message : ben.message
		let infoMSG = JSON.parse(fs.readFileSync('./src/.dat/msg.data.json'))
		infoMSG.push(JSON.parse(JSON.stringify(ben)))
		fs.writeFileSync('./src/.dat/msg.data.json', JSON.stringify(infoMSG, null, 2))
		const urutan_pesan = infoMSG.length
		if (urutan_pesan >= 1000) {
			infoMSG.splice(1, 999)
			fs.writeFileSync('./src/.dat/msg.data.json', JSON.stringify(infoMSG, null, 2))
		}
		global.blocked
		const content = JSON.stringify(ben.message)
		var from = ben.key.remoteJid
		const type = Object.keys(ben.message)[0]
		const isMedia = (type === 'imageMessage' || type === 'videoMessage')
		const barbarkey = '--'
		const naufalkey = 'YunitaGanteng'
		const lolkey = 'oniichan'
		const vhtearkey = 'YunitaGanteng'
		const hujankey = 'AdelwinNL'
		const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
		const time = moment.tz('Asia/Jakarta').format('HH:mm:ss DD:MM:YYYY')
		budy = (type === 'conversation') ? ben.message.conversation : (type === 'extendedTextMessage') ? ben.message.extendedTextMessage.text : ''
		prefix = /^[°zZ•π.'":÷×¶∆£¢€¥®™✓=;~ |!+<?#$%^&\/\\©^]/.test(budy) ? budy.match(/^[°zZ•π.'":÷×¶∆£¢€¥®™✓=;~ |!+<?#$%^&\/\\©^]/gi)[0] : '-'
		body = (type === 'conversation' && ben.message.conversation.startsWith(prefix)) ? ben.message.conversation : (type == 'imageMessage') && ben.message.imageMessage.caption.startsWith(prefix) ? ben.message.imageMessage.caption : (type == 'videoMessage') && ben.message.videoMessage.caption.startsWith(prefix) ? ben.message.videoMessage.caption : (type == 'extendedTextMessage') && ben.message.extendedTextMessage.text.startsWith(prefix) ? ben.message.extendedTextMessage.text : ''
		const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
		const commando = body.slice(1)
		var Link = budy = (type === 'conversation') ? ben.message.conversation : (type === 'extendedTextMessage') ? ben.message.extendedTextMessage.text : ''
		const messageLink = Link.slice(0).trim().split(/ +/).shift().toLowerCase()
		const args = body.trim().split(/ +/).slice(1)
		const isCmd = body.startsWith(prefix)
		const q = args.join(' ')
		const arg = budy.slice(command.length + 2, budy.length)
		mess = {
			wait: '[ WAIT ] Sedang di proses ...⏳',
			success: 'Berhasil!',
			error: {
				stick: 'Maaf, terjadi kesalahan saat convert gambar ke sticker',
				Iv: 'Linknya mokad:v',
				api: 'Error'
			},
			only : {
				pc: 'Perintah ini hanya bisa digunakan di private chat saja!',
				Registered: `Kamu belum terdaftar di database!\n\nSilakan register dengan format:\n*${prefix}daftar*\n\nNote:\nHarap save nomor ku agar bisa mendapatkan serial!!`,
				group: 'Grup only bruh...',
				ownerG: 'Owner grup only bruh...',
				ownerB: 'Lu siapa?',
				admin: 'Mimin grup only bruh...',
				premium: `Premium user only bruh...\nMau jadi user premium?\nChat wa.me/6289636006352`,
				Badmin: 'Jadiin gw admin dlu su!'
			}
		}

		const botNumber = benny.user.jid
		const buattag = botNumber.replace('@s.whatsapp.net', '')
		const devNumber = [botNumber] // ganti nomer lu
		const isGroup = from.endsWith('@g.us')
		const isStatus = from.includes('status@broadcast')
		const sender = ben.key.fromMe ? benny.user.jid : isGroup ? ben.participant : ben.key.remoteJid
		const totalchat = await benny.chats.all()
        const nameReq = isGroup ? ben.participant : ben.key.remoteJid
		const pushname = ben.key.fromMe ? benny.user.name : benny.contacts[nameReq].vname || benny.contacts[nameReq].notify || '-'
		const groupMetadata = isGroup ? await benny.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isRegistered = register.checkRegisteredUser(sender, _registered)
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
		const isAntilink = isGroup ? anlink.includes(from) : false
		const isAntiPorn = isGroup ? _porn.includes(from) : false
		const isWelkom = isGroup ? welkom.includes(from) : false
		const isKasar = isGroup ? kasar.includes(from) : false
		const isBot = isGroup ? _bot.includes(from) : false
		const isVirus = isGroup ? virus.includes(from) : false
		const isAutoSticker = isGroup ? autostick.includes(from) : false
		const isAutoStick = _autostick.includes(sender)
		const isNsfw = isGroup ? nsfw.includes(from) : false
		const isSimi = isGroup ? samih.includes(from) : false
		const isKickArea = isGroup ? kickarea.includes(from) : false
		const isOwner = ownerNumber.includes(sender)
		const isDev = devNumber.includes(sender)
		const isBanned = _ban.includes(sender)
		const isAfk = _afk.includes(sender)
		const isPremium = premium.checkPremiumUser(sender, _premium)
		const isSewa = sewa.checkPremiumUser(from, _sewa)
        const chats = type == 'conversation' || type == 'extendedTextMessage'
		const isUrl = (url) => {
			return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
		}
		
		const fetch = require("node-fetch");
const cheerio = require("cheerio");
const cookie = require("cookie");
const FormData = require("form-data");

async function keeptiktok(url) {
	console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Scrapping keeptiktok...'))
  const geturl = await fetch("https://keeptiktok.com/?lang=ID", {
    method: "GET",
    headers: {
      "User-Agent": "GoogleBot",
    },
  });
  const caritoken = await geturl.text();
  let hasilcookie = geturl.headers
    .get("set-cookie")
    .split(",")
    .map((v) => cookie.parse(v))
    .reduce((a, c) => {
      return { ...a, ...c };
    }, {});
  hasilcookie = {
    _cfduid: hasilcookie._cfduid,
    PHPSESSID: hasilcookie.PHPSESSID,
  };
  hasilcookie = Object.entries(hasilcookie)
    .map(([name, value]) => cookie.serialize(name, value))
    .join("; ");
  const $ = cheerio.load(caritoken);
  const token = $('input[name="token"]').attr("value");
  const form = new FormData();
  form.append("url", url);
  form.append("token", token);
  const geturl2 = await fetch("https://keeptiktok.com/?lang=ID", {
    method: "POST",
    headers: {
      Accept: "/",
      "Accept-Language": "en-US,en;q=0.9",
      "User-Agent": "GoogleBot",
      Cookie: hasilcookie,
      ...form.getHeaders(),
    },
    body: form.getBuffer(),
  });
  const cariurl = await geturl2.text();
  const $$ = cheerio.load(cariurl);
  const hasil = $$("source").attr("src");
  return hasil;
}

		const downloadM = async (path) => {
			path ? path : Date.now()
const buat = JSON.parse(JSON.stringify(ben).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
const dia = await benny.downloadAndSaveMediaMessage(buat, path)
return fs.readFileSync(dia)
}

if (ben.key.remoteJid == 'status@broadcast') from = 'status@broadcast'

		const sendMediaURL = async(to, url, text="", mids=[]) =>{
				if(mids.length > 0){
					text = normalizeMention(to, text, mids)
				}
				const fn = Date.now() / 10000;
				const filename = fn.toString()
				let mime = ""
				var download = function (uri, filename, callback) {
					request.head(uri, function (err, res, body) {
						mime = res.headers['content-type']
						request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
					});
				};
				download(url, filename, async function () {
					console.log('Done..');
					let media = fs.readFileSync(filename)
					let type = mime.split("/")[0]+"Message"
					if(mime === "image/gif"){
						type = MessageType.video
						mime = Mimetype.gif
					}
					if(mime.split("/")[0] === "audio"){
						mime = Mimetype.mp4Audio
					}
					benny.sendMessage(to, media, type, { quoted: adadeh, mimetype: mime, caption: text })
					
					fs.unlinkSync(filename)
				});
			}
			if (banChats == false) fake = namabot
			if (banChats == true) fake = 'SELFBOT'
			
		const reply = (teks) => {
			benny.sendMessage(from, {title: 'p', text: teks, jpegThumbnail: setthumb}, extendedText, {quoted: adadeh})
		}
		const sendMess = (hehe, teks) => {
			benny.sendMessage(hehe, teks, text, { quoted: adadeh})
		}
		const acak = (teks) => {
			teks[Math.floor(Math.random() * teks.length)]
		}
		const sendPesan = (hehe, teks) => {
			benny.sendMessage(hehe, teks, text, { "contextInfo": {mentionedJid: [sender], "forwardingScore": 999,"isForwarded": true}, quoted: adadeh})
		}
		const mentions = (teks, memberr, id) => {
			(id == null || id == undefined || id == false) ? benny.sendMessage(from, teks.trim(), extendedText, { contextInfo: { "mentionedJid": memberr } }) : benny.sendMessage(from, teks.trim(), extendedText, { quoted: adadeh, contextInfo: { "mentionedJid": memberr } })
		}
		const sendPtt = (teks) => {
			  benny.sendMessage(from, audio, mp3, {quoted: adadeh, ptt: true})
        }
		
		const telestick = async (to, url) => {
let packName = url.replace("https://t.me/addstickers/", "");
 
let gas = await fetch(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getStickerSet?name=${encodeURIComponent(packName)}`, { method: "GET", headers: { "User-Agent": "GoogleBot" } } );
 
let json = await gas.json();
 
console.log(json)
for(let i of json.result.stickers) {
let fileId = i.thumb.file_id;
 
let gasIn = await fetch(`https://api.telegram.org/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/getFile?file_id=${fileId}`)
 
let jisin = await gasIn.json();
console.log(jisin)
 buffer = await getBaper("https://api.telegram.org/file/bot891038791:AAHWB1dQd-vi0IbH2NjKYUk-hqQ8rQuzPD4/" + jisin.result.file_path)
benny.sendMessage(to, buffer, sticker);
}
}

		const msgs = (message) => {
            if (body.startsWith(prefix))  {
                if (message.length >= 10){
                    return `${message.substr(0, 15)}`
                }else{
                    return `${message}`
                }
            }
        }
		
		const msgss = (message) => {
                if (message.length >= 10){
                    return `${message.substr(0, 15)}`
                }else{
                    return `${message}`
                }
        }
		
		const getUserLimit = (userId) => {
            let position = false
            Object.keys(_registered).forEach((i) => {
                if (_registered[i].id === userId) {
                    position = i
                }
            })
            if (position !== false) {
                return _registered[position].limitCount
            }
        }
		
		const sendSticker = async(to, file) => {
			ran = getRandom('.webp')
							require('./lib/exif.js').createExif(namabot, '')
							exec(`ffmpeg -i ${file} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ran}`, (err) => {
								if (err) return reply('error')
							exec(`webpmux -set exif ./src/sticker/data.exif ${ran} -o ${ran}`, async (error) => {
                          benny.sendMessage(to, fs.readFileSync(ran), sticker, {quoted: adadeh})
							})
							})							
						}

		const sendStickerUrl = async(to, url) => {
			console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Downloading sticker...'))
				var names = getRandom('.webp')
				var namea = getRandom('.png')
				var download = function (uri, filename, callback) {
					request.head(uri, function (err, res, body) {
						request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
					});
				};
				download(url, namea, async function () {
					let filess = namea
					let asw = names
					require('./lib/exif.js').createExif(namabot, '')
					exec(`ffmpeg -i ${filess} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${asw}`, (err) => {
					exec(`webpmux -set exif ./src/sticker/data.exif ${asw} -o ${asw}`, async (error) => {
					let media = fs.readFileSync(asw)
					benny.sendMessage(to, media, sticker, {quoted: adadeh})
					console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color('Succes send sticker...'))
					});
					});
				});
			}

offline = process.uptime()
waktuoff = `${tek(offline)}`
		
		const isQuotedImages = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedStickers = type === 'extendedTextMessage' && content.includes('stickerMessage')
		
		if (isGroup && isAutoSticker) {
			if (isMedia && !ben.message.videoMessage || isQuotedImages) {
							const encmedia = isQuotedImages ? JSON.parse(JSON.stringify(ben).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : ben
							const media = await benny.downloadAndSaveMediaMessage(encmedia)
							sendSticker(from, media)
			}
		}
		
    if (!isGroup && isAutoStick) {
			if (isMedia && !ben.message.videoMessage || isQuotedImages) {
							const encmedia = isQuotedImages ? JSON.parse(JSON.stringify(ben).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : ben
							const media = await benny.downloadAndSaveMediaMessage(encmedia)
							sendSticker(from, media)
			}
		}

		colors = ['red', 'white', 'black', 'blue', 'yellow', 'green']
		const isQuotedText = type === 'extendedTextMessage'
		const isQuotedLink = type === 'extendedTextMessage' && content.includes('extendedTextMessage')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
	
	    //Ignore ban user
		    if (isBanned && !isGroup && !isCmd) console.log(color(time, "gold"), color("[ BAN ]", "red"), color(msgss(budy)), color("from", "pink"), color(sender.split('@')[0], "yellow"))
            if (isBanned && isGroup && !isCmd) console.log(color(time, "gold"), color("[ BAN ]", "red"), color(msgss(budy)), color("from", "pink"), color(sender.split('@')[0], "yellow"), color("in", "purple"), color(groupName, "yellow"))
            if (isBanned && !isGroup && isCmd) console.log(color(time, "gold"), color("[ BAN ]", "red"), color(msgs(command)), color("from", "pink"), color(sender.split('@')[0], "blue"))
			
	    //Message
		if (!isStatus && !isGroup && command) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ COMMAND ]", "aqua"), color(msgs(command)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"))
		    if (!isStatus && !isGroup && !command) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ PRIVATE ]", "aqua"), color(msgss(budy)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"))
	        if (!isStatus && isGroup && command) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ COMMAND ]", "aqua"), color(msgs(command)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"), color("in", "purple"), color(groupName, "yellow"))
	        if (!isStatus && isGroup && !command) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ GROUP ]", "aqua"), color(msgss(budy)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"), color("in", "purple"), color(groupName, "yellow"))
	        if (isStatus) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ STATUS ]", "aqua"), color(msgss(budy)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"))
          
		 //Anti spam
		  if (isCmd && isFiltered(from) && !isGroup && !isOwner && !ben.key.fromMe) return console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ SPAM ]", "red"), color(msgs(command)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"))
		   if (isCmd && isFiltered(from) && isGroup && !isOwner && !ben.key.fromMe) return console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ SPAM ]", "red"), color(msgs(command)), color("from", "pink"), color('+' + sender.split('@')[0], "lime"), color("in", "purple"), color(groupName, "yellow"))
	        if (isCmd && !isOwner && !ben.key.fromMe) addFilter(from)
			
			if (!ben.key.fromMe) {
		if (ben.message.extendedTextMessage != null || ben.message.extendedTextMessage != undefined) {
	if (ben.message.extendedTextMessage.contextInfo != null || ben.message.extendedTextMessage.contextInfo != undefined) {
	if (ben.message.extendedTextMessage.contextInfo.quotedMessage.orderMessage) {
		benny.modifyChat(from, 'clear')
	}
	}
		}
			}
	
	if (!ben.key.fromMe && isGroup && isAntilink) {
	if (budy.includes("://chat.whatsapp.com/")) {
		if (isGroupAdmins) return reply('Kamu admin grup jadi ngga di kick :)')
		console.log(color('[KICK]', 'red'), color('Received a link!', 'yellow'))
		reply(`「 *PETUGAS PEMBERSIH* 」\n\nKamu nakal si! Ngapain kirim link grup lain? \nMaaf tapi aku harus mengeluarkan kamu...\nSelamat tingal~`)
				 benny.groupRemove(from, [sender])
}
	}
	
	if (!ben.key.fromMe && !isGroup && banChat == true) {
			reply(`*Mohon Maaf Benny Sedang Offline!*\n\n• *Alasan:* ${alasanoff}\n• *Sejak:* ${waktuoff}\n\nSilahkan hubungi lagi setelah *10 menit*`)
					}
					
	if (!ben.key.fromMe && isCmd && isGroup && banChat == true) {
			reply(`*Mohon Maaf Benny Sedang Offline!*\n\n• *Alasan:* ${alasanoff}\n• *Sejak:* ${waktuoff}\n\nSilahkan hubungi lagi setelah *10 menit*`)
					}
					
	if (!ben.key.fromMe && !isGroup && autoblock == true) {
			if (sender != '62') {
			benny.blockUser(sender, "add")
			}
					}
					
	if (autoread) {
		benny.chatRead(from)
	}
	
	if (!ben.key.fromMe && autojoin) {
	if (budy.includes("://chat.whatsapp.com/")) {
		console.log(color('[AUTO JOIN]', 'cyan'), color('BRING ME THE HORIZON 2011', 'yellow'))
				 benny.query({
json:["action", "invite", `${budy.replace('https://chat.whatsapp.com/','')}`]
})
}
	}
	
	
	if (!ben.key.fromMe && banChat == true) {
			if (budy.includes(`@${buattag}`)) {
			reply(`*Mohon Maaf Benny Sedang Offline!*\n\n• *Alasan:* ${alasanoff}\n• *Sejak:* ${waktuoff}\n\nSilahkan hubungi lagi setelah *10 menit*`)
			}
			}
		
			
const tebakgambar = (jawaban) => {
	if (tebakgamb == false) return
	if (budy.toLowerCase() == jawaban) {
	reply('*Selamat jawaban kamu benar!*')
	tebakgamb = false
	}
}
	
	if (budy) {
	for (var i = 0; i < commandsDB.length ; i++) {
				if (budy.toLowerCase() === commandsDB[i].pesan) {
					reply(commandsDB[i].balasan)
				}
			}
	}
	if (!ben.key.fromMe && isGroup && isVirus && budy) {
	for (var i = 0; i < badwordDB.length ; i++) {
				if (budy.includes(badwordDB[i].badword)) {
					if (isGroupAdmins) return reply('Kamu admin grup jadi ngga di kick :)')
				 reply(`「 *PETUGAS PEMBERSIH* 」\n\nKamu nakal si! Ngapain ngomong kotor? \nMaaf tapi aku harus mengeluarkan kamu...\nSelamat tingal~`)
				 console.log(color('[KICK]', 'red'), color('Received a badword!', 'yellow'))
					benny.groupRemove(from, [sender])
				}
			}
	}
			
	if (budy.includes(`@${buattag}`)) {
		if (antitag == false) return
		if (!isGroup) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ TAG ]", "aqua"), color('Received a tag'), color("from", "pink"), color(sender.split('@')[0], "blue"))
	        if (isGroup) console.log(color(tampilTanggal, 'magenta'), color(moment.tz('Asia/Jakarta').format('HH:mm:ss'), "gold"), color("[ TAG ]", "aqua"), color('Received a tag'), color("from", "pink"), color(sender.split('@')[0], "blue"), color("in", "purple"), color(groupName, "yellow"))
		benny.chatRead(from)
	}
	
			
		//Anti virus function
		if (isGroup && !ben.key.fromMe && isKasar && isBotGroupAdmins) {
		    if (budy.length >= 1500) {
				if (isGroupAdmins) return reply('Kamu admin grup jadi ngga di kick :)')
				reply(`「 *PETUGAS PEMBERSIH* 」\n\nKamu nakal si! Ngapain kirim virus? \nMaaf tapi aku harus mengeluarkan kamu...\nSelamat tingal~`)
				 console.log(color('[KICK]', 'red'), color('Received a virus text!', 'yellow'))
				 benny.groupRemove(from, [sender])
				}
		}
		
		if (!ben.key.fromMe) {
		    if (budy.length >= 3000) {
				 console.log(color('[KICK]', 'red'), color('Received a virus text!', 'yellow'))
				 benny.clearMessage(ben.key)
				}
			}
			
			if (ben.message.stickerMessage) {
				if (autoget == true) {
					benny.starMessage(ben.key)
				} 
			}
			
			if (isGroup && isCmd && !isGroupAdmins && !isOwner && !ben.key.fromMe && isSimi) return reply(`*Kalau mau pakai bot minta tolong admin untuk mematikan modesimi*\n*Contoh:* ${prefix}modesimi off`)
			if (isCmd) {
		  hit.addHit(sender, _hit)
			}
			
			if (isGroup && isSimi && !ben.key.fromMe) {
				anu = await fetchJson(`https://api.lolhuman.xyz/api/simi?apikey=${lolkey}&text=${budy}`)
				reply(anu.result)
			}
			
			
			//Public&Self Function
		    if (!isOwner && !ben.key.fromMe && banChats === true) return 
			
		
	        // Automate
             premium.expiredCheck(_premium)
			 cron.schedule('0 0 * * *', () => {
            const reset = []
            _limit = reset
            console.log('Resetting user limit...')
            fs.writeFileSync('./src/limit.json', JSON.stringify(_limit))
            console.log('Success!')
        }, {
            scheduled: true,
            timezone: 'Asia/Jakarta'
        })
		 
		 
		//On off function
		if (isGroup && isBot) {
			if (!isGroupAdmins && !ben.key.fromMe) return 
		}
		    //Ban function
			if (isCmd && isBanned && !isOwner && !ben.key.fromMe) return
			//AFK By Benny
			if (isGroup && isAfk) {
				ono = JSON.parse(fs.readFileSync('./src/afk.json'))
		if (budy.includes(`@${ono.id.replace('@s.whatsapp.net', '')}`)) {
			mentioned = ben.message.extendedTextMessage.contextInfo.mentionedJid[0]
				teks = `*Sssttt jangan diganggu!* @${mentioned.split('@')[0]} *Sedang AFK!*\n\n*Sejak:* ${waktuafk}\n*Alasan:* ${reason}`
				benny.sendMessage(from, teks, text, {contextInfo: {mentionedJid: [mentioned]}})
			}
			}
			// AFK by Slavyan
            if (isGroup) {
            if (afk.checkAfkUser(sender, _afk) && !isCmd) {
                _afk.splice(afk.getAfkPosition(sender, _afk), 1)
                fs.writeFileSync('./src/afk.json', JSON.stringify(_afk))
						   benny.sendMessage(from, `*@${sender.split('@')[0]}* telah kembali dari AFK! Selamat datang kembali~`, text, {contextInfo: {mentionedJid: [sender]}})
            }
        }
			
			//On off function
		   
		   if (isCmd) {
		  botHit.push(sender)
		  fs.writeFileSync('./src/botHit.json', JSON.stringify(botHit))
		   }
		   
		   if (isCmd && !ben.key.fromMe && !isRegistered) {
			   umur = Math.floor(Math.random() * 30)
				serial = crypto.randomBytes(10).toString('hex').slice(0, 10)
				console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(pushname, 'cyan'), 'Age:', color(umur, 'cyan'), 'Serial:', color(serial, 'cyan'))
			   register.addRegisteredUser(sender, pushname, umur, time, serial, _registered)
			   benny.sendMessage(botNumber, `@${sender.split('@')[0]}`, text, {contextInfo:{mentionedJid: [sender]}})
			   benny.sendMessage(botNumber, serial, text)
		   }
		   
			switch(command) {
			case 'wa.me':
				  case 'wame':
  benny.updatePresence(from, Presence.composing) 
      const palal = {
          text: `「 SELF WHATSAPP 」\n\n_Request by_ : @${sender.split("@s.whatsapp.net")[0]}\n\nYour link WhatsApp : *https://wa.me/${sender.split("@s.whatsapp.net")[0]}*\n*Or ( / )*\n*https://api.whatsapp.com/send?phone=${sender.split("@")[0]}*`,
          contextInfo: { mentionedJid: [sender] }
    }
    benny.sendMessage(from, palal, text,{ caption: text, contextInfo: { participant: groupId, quotedMessage: { conversation: '*_WA ME_*' } } }) 
				break
			case 'tampar':
					sendStickerUrl(from, 'https://media.giphy.com/media/S8507sBJm1598XnsgD/source.gif')
					break
		case 'dadu':
			        random = Math.floor(Math.random() * 6)
					sendStickerUrl(from, `https://www.random.org/dice/dice${random}.png`)
					break

		case 'return':
		if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
			try {
						let evaled = await eval(body.slice(8))
						if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
						reply(evaled)
					} catch (err) {
						reply(err)
					}
				break
			case 'rules':
			
			reply(`-----[ RULES ]-----

1. Jangan spam bot. 
Sanksi: *WARN/SOFT BLOCK*

2. Jangan telepon bot.
Sanksi: *SOFT BLOCK*

3. Jangan spam virus bot.
Sanksi: *PERMANENT BLOCK*

Jika sudah dipahami rules-nya, silakan ketik *${prefix}menu* untuk memulai!
    `)
	break
				case 'donasi':
				case 'donate':
					var itsme = `${numbernye}@s.whatsapp.net`
					var split = `*_TERIMAKASIH SUDAH MAU DONASI_*`
					var donat = `┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ 𝗗𝗢𝗡𝗔𝗦𝗜 𝗕𝗢𝗦𝗤𝗨𝗘 ❉⊰━━✿
┃  
┣➥ *OVO* : -
┣➥ *PULSA* : 0813-8728-9617
┣➥ *GOPAY* : 089636006352
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ _*POWERED BY BENNY*_
┗━━━━━━━━━━━━━━━━━━━━`
                    reply(donat)
					break
				case 'hidetag':
				if (ben.key.fromMe) return
					members_id = []
					teks = (args.length > 1) ? body.slice(9).trim() : `${body.slice(8)}`
					for (let mem of groupMembers){
					members_id.push(mem.jid)
					}
					mentions(teks, members_id, true) 
					break
					case 'kickbot':
					for (let mem of groupMembers){
					console.log(mem)
					woilo = mem.jid
					namalo = mem.notify
					namadia = await benny.contacts[woilo] != undefined ? benny.contacts[woilo].vname || benny.contacts[woilo].notify : undefined
					otwkick = woilo[namalo]
					console.log(namadia)
						reply('Terdeteksi ada bot disini segera di kick!')
				benny.groupRemove(from, [otwkick])
					}
					break
				case 'shota':
				
					{
						var items = ['shota anime', 'anime shota'];
						var nime = items[Math.floor(Math.random() * items.length)];
						var url = "https://api.fdci.se/rep.php?gambar=" + nime;
					
						axios.get(url)
						  .then((result) => {
							var n = JSON.parse(JSON.stringify(result.data));
							var nimek = n[Math.floor(Math.random() * n.length)];
							imageToBase64(nimek)
							.then(
								(response) => {
						var buf = Buffer.from(response, 'base64');
						benny.sendMessage(from, buf, MessageType.image, { caption: `*SHOTA!*`, quoted: adadeh })
								}
							)
							.catch(
								(error) => {
									console.log(error);
								}
							)
						
						});
						}
					break
				case 'hidetag2':
				
					var value = text.replace(text.split(' ')[0], `${body.slice(9)}`)
					var group = await benny.groupMetadata(from)
					var member = group['participants']
					var ids = []
					member.map( async adm => {
					ids.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var optionsss = {
					text: value,
					contextInfo: { mentionedJid: ids },
					quoted: adadeh
					}
					benny.sendMessage(from, optionsss, MessageType.text)
					break
				case 'brainly':
				
					var teks = body.slice(9)
					anu = await brainly(teks)
					teks = `*BRAINLY*\n\n`
					for (let o of anu.data) {
					for (let i of o.jawaban) {
						teks += `Pertanyaan: ${o.pertanyaan}\nJawaban: ${i.text}\n==============================\n`
					}
					}
					console.log(anu)
					reply(teks.trim())
				break
				case 'group':
				case 'grup':
				
					if (!isGroup) return reply(mess.only.group)
					if (args[0] === 'open') {
					reply(`「 *SUCCES OPEN GRUP* 」`)
					benny.groupSettingChange(from, GroupSettingChange.messageSend, false)
					} else if (args[0] === 'close') {
					await benny.groupSettingChange(from, GroupSettingChange.messageSend, true)
					reply(`「 *SUCCES CLOSE GRUP* 」`)
					}
					break
				case 'infogempa':
				
				anu = await getGempa()
				teks = `*${anu.waktu}*\n📍 *Lokasi* : *${anu.lokasi}*\n〽️ *Kedalaman* : *${anu.kedalaman}*\n💢 *Magnitudo* : *${anu.magnitudo}*\n🔘 *Potensi* : *${anu.tsunami}*\n📍 *Koordinat* : *${anu.koordinat}*`
				buffer = await getBaper(anu.gambar)
				benny.sendMessage(from, buffer, image, {quoted: adadeh, caption: teks})
				break
				case 'cuaca':
				
				if (args.length < 1) return reply('Masukan nama kota!')
				tekss = body.slice(7)
				   anu = await fetchJson(`http://api.lolhuman.xyz/api/cuaca/${tekss}?apikey=${lolkey}`)
				   teks = `*╔❏* *CUACA*\n*╠❏*\n*╠❏* *Kota:* ${anu.result.tempat}\n*╠❏* *Cuaca:* ${anu.result.cuaca}\n*╠❏* *Suhu:* @${anu.result.suhu}\n*╠❏* *Kelembapan:* ${anu.result.kelembapan}\n*╠❏* *Angin:* ${anu.result.angin}\n*╠❏* *Latitude:* ${anu.result.latitude}\n*╚❏* *Longitude:* ${anu.result.longitude}`
                   reply(teks)
		break
		case 'covid':
				
				   anu = await fetchJson(`https://coronavirus-19-api.herokuapp.com/countries/${body.slice(7)}`)
				   p = anu
				   teks = `*╔❏* *INFO COVID ${body.slice(7)}*\n*╠❏*\n*╠❏* *Positif:* ${p.cases}\n*╠❏* *Sembuh:* ${p.recovered}\n*╠❏* *Meninggoy:* ${p.deaths}\n*╚❏* *Dirawat:* ${p.testsPerOneMillion}`
                   reply(teks)
		break
		case 'covidindo':
				
				   anu = await fetchJson(`http://api.lolhuman.xyz/api/corona/indonesia?apikey=${lolkey}`)
				   p = anu.result
				   teks = `*╔❏* *INFO COVID*\n*╠❏*\n*╠❏* *Positif:* ${p.positif}\n*╠❏* *Sembuh:* ${p.sembuh}\n*╠❏* *Meninggoy:* ${p.meninggal}\n*╚❏* *Dirawat:* ${p.dirawat}`
                   reply(teks)
		break
		case 'upswteks':
		if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
					benny.updatePresence(from, Presence.composing)
					benny.sendMessage('status@broadcast', {text: body.slice(10), jpegThumbnail: setthumb}, extendedText)
					reply(`Sukses Up story wea teks ${q}`)
					break
				case 'upswimage':
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
					benny.updatePresence(from, Presence.composing)
					if (isQuotedImage) {
						const swsw = isQuotedImage ? JSON.parse(JSON.stringify(ben).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : ben
						cihcih = await benny.downloadMediaMessage(swsw)
						benny.sendMessage('status@broadcast', cihcih, image, { caption: `${body.slice(11)}` })
					}
					bur = `Sukses Upload Story Image dengan Caption: ${q}`
					benny.sendMessage(from, bur, text, {quoted: adadeh})
					break
				case 'upswstick':
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
					benny.updatePresence(from, Presence.composing)
					if (isQuotedSticker) {
						const swsw = JSON.parse(JSON.stringify(ben).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo
						cihcih = await benny.downloadMediaMessage(swsw)
						benny.sendMessage('status@broadcast', cihcih, sticker)
					}
					bur = `Sukses Upload Story Image dengan Caption: ${q}`
					benny.sendMessage(from, bur, text, {quoted: adadeh})
					break
				case 'upswvideo':
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
					benny.updatePresence(from, Presence.composing)
					if (isQuotedVideo) {
						const swsw = isQuotedVideo ? JSON.parse(JSON.stringify(ben).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : ben
						cihcih = await benny.downloadMediaMessage(swsw)
						benny.sendMessage('status@broadcast', cihcih, video, { caption: `${body.slice(11)}` })
					}
					bur = `Sukses Upload Story Video dengan Caption: ${body.slice(11)}`
					benny.sendMessage(from, bur, text, {quoted: adadeh})
					break  						
		case 'buffer':
				
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
			      if (args.length < 1) return reply('Mau buffer apa jir')
				teks = body.slice(8)
				anu = await getBaper(teks)
				bofor = audio
				poli = {quoted: adadeh, mimetype: 'audio/mp4'}
                if (teks.includes('mp3')) bofor = audio
                if (teks.includes('mp4')) bofor = video
                if (teks.includes('png')) bofor = image
                if (teks.includes('jpg')) bofor = image
				if (bofor == image) poli = adadeh
				if (bofor == audio) poli = {quoted: adadeh, mimetype: 'audio/mp4'}
				if (bofor == video) poli = {quoted: adadeh, mimetype: 'video/mp4'}
				benny.sendMessage(from, anu, bofor, poli)
				break
				case 'listapi':
				
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
			      teks = `https://pecundang.herokuapp.com/api/fbdown/?url=MASUKIN_URL\n\nhttps://pecundang.herokuapp.com/api/tiktod/?url=MASUKIN_URL\n\nhttps://pecundang.herokuapp.com/api/ytsearch?q=Banyu%20surgo\n\nhttps://pecundang.herokuapp.com/api/ytmp3?url=https://www.youtube.com/watch?v=yEQ9z58UnJM\n\nhttps://pecundang.herokuapp.com/api/ytmp4?url=https://www.youtube.com/watch?v=yEQ9z58UnJM\n\nhttps://pecundang.herokuapp.com/api/playmp3?q=Banyu%20surgo\n\nhttps://pecundang.herokuapp.com/api/playmp4?q=Banyu%20surgo\n\n`
				  reply(teks)
				  break
				case 'get':
				
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
			      if (args.length < 1) return reply('Mau get apa jir')
				  teks = body.slice(5)
				  anu = await fetchJson(teks)
				  reply(JSON.stringify(anu))
				  break
				case 'fetch':
				
				if (!isOwner && !ben.key.fromMe) return benny.sendMessage(from, `*Maaf @${sender.split('@')[0]} Perintah ${prefix}${command} tidak ada di list ${prefix}menu!*`, text, { contextInfo: {mentionedJid: [sender]}, quoted: adadeh})
			      if (args.length < 1) return reply('Mau get apa jir')
  let res = await fetch(body.slice(7))
  if (!/text|json/.test(res.headers.get('content-type'))) return benny.sendMessage(from, body.slice(7), text, {quoted: adadeh})
  let txtf = await res.buffer()
  try {
    txtf = util.format(JSON.parse(txtf+''))
  } catch (e) {
    txtf = txtf + ''
  } finally {
    reply(txtf.slice(0, 65536) + '')
  }
				break
		case 'cuaca2':
				
				   anu = await fetchJson(`https://mnazria.herokuapp.com/api/bmkg-cuaca`)
				   teks = `*╔❏* *${anu.result.title}*\n*╠❏*\n`
				   for (let o of anu.result.desc) {
					   teks += `*╠❏* *Info:* ${o.info}\n======================\n`
				   }
				   reply(teks.trim())
		break
		case 'quotesislami':
		case 'quotesislam':
				
		anu = await fetchJson(`https://pecundang.herokuapp.com/api/randomquote/muslim?apikey=adadeh`)
		reply(anu.result.text_id)
		break
		case 'quotesimage':
				case 'qoutesimage':
				
				   anu = await getBaper(`http://api.lolhuman.xyz/api/random/quotesimage?apikey=${lolkey}`)
				   reply(mess.wait)
				   benny.sendMessage(from, anu, image, {contextInfo: {mentionedJid: [sender]}, quoted: adadeh, caption: 'Neh..'})
		break
		case 'darkjokes':
		case 'darkjoke':
				
				   reply(mess.wait)
					anu = await fetchJson(`https://naufalhoster.xyz/tools/darkjokes?apikey=${naufalkey}`)
					buffer = await getBaper(anu.result.joke)
					benny.sendMessage(from, buffer, image, {quoted: adadeh, caption: 'Dark Jokes'})
		break
		case 'estetik':
		case 'aestetik':
				
				   reply(mess.wait)
					anu = await fetchJson(`https://api.zeks.xyz/api/estetikpic?apikey=YunitaGanteng`)
					buffer = await getBaper(anu.result.result)
					benny.sendMessage(from, buffer, image, {quoted: adadeh, caption: 'Estetik'})
		break
		case 'puisiimage':
				
				   reply(mess.wait)
					buffer = await getBaper(`https://api.vhtear.com/puisi_image&apikey=YunitaGanteng`)
					benny.sendMessage(from, buffer, image, {quoted: adadeh, caption: 'Estetik'})
		break
				  case 'pantun':
				
				   anu = await fetchJson(`https://pencarikode.xyz/api/pantun?apikey=pais`)
				   teks = `- *Pantun* : ${anu.pantun}`
				   reply(teks)
		break
				  case 'fakta':
				
				   anu = await fetchJson(`https://videfikri.com/api/fakta/`)
				   teks = `- *Fakta* : ${anu.result.fakta}`
				   reply(teks)
		break
		case 'style':
		anu = require('./lib/fancytext')
		pao = await anu.fancy(body.slice(7))
			reply(pao.result)
		break
		case 'findhost':
				
				teks = body.slice(10)
				   anu = await fetchJson(`https://api.banghasan.com/domain/hostsearch/${teks}`)
				   if (anu.hasil == 'API count exceeded - Increase Quota with Membership') return
				   reply(anu.hasil)
		break
		case 'cekping':
				
				teks = body.slice(10)
				   anu = await fetchJson(`https://api.banghasan.com/domain/nping/${teks}`)
				   if (anu.hasil == 'API count exceeded - Increase Quota with Membership') return
				   reply(anu.hasil)
		break
		case 'cekdns':
				
				teks = body.slice(10)
				   anu = await fetchJson(`https://api.banghasan.com/domain/dnslookup/${teks}`)
				   if (anu.hasil == 'API count exceeded - Increase Quota with Membership') return
				   reply(anu.hasil)
		break
		case 'bioskop':
				
				 tekss = body.slice(9)
				   anu = await fetchJson(`http://docs-jojo.herokuapp.com/api/bioskop?kota=${tekss}&apikey=undefined`)
				teks = `*╔❏* *BIOSKOP*\n\n`
				for (let o of anu.result) {
					 teks += `*Nama:* ${o.title}\n*Alamat:* ${o.alamat}\n*Bintang:* ${o.bintang}\n*Link:* ${o.url}\n============================\n`
				buffer = await getBaper(o.img)
				}
				  benny.sendMessage(from, buffer, image, {quoted: adadeh, caption: teks.trim()})
		break
		case 'kisahnabi':
				
				 tekss = body.slice(11)
				   anu = await fetchJson(`https://pecundang.herokuapp.com/api/kisahnabi?nabi=${tekss}`)
				if (anu.status == false) return reply(`Masukan nama nabi yang benar! jangan main-main!`)
				nabi = anu.result.nabi
				buffer = await getBaper(nabi.image)
				teks = `*╔❏* *KISAH NABI*\n*╠❏* *Nama* : ${nabi.nabi}\n*╠