## Cara Install Di Termux
```cmd
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> git clone https://github.com/fazonetea/FznSelfWa.git
> cd FznSelfWa
> npm i
> node start
> isi nama session (terserah)
> scan QR and Enjoyy
```

## Cara Install Di Windows
* [`Download Node JS`](https://nodejs.org/en/download/)
```cmd
> git clone https://github.com/fazonetea/FznSelfWa.git
> cd FznSelfWa
> npm i
> node start
> isi nama session (terserah)
> scan QR and Enjoyy
```

## Jalankan Bot
```cmd
> npm start
> masukan nama session nya
```

## FITURNYA MASIH DIKIT :)

### Owner
* `Setfake`
* `Upswteks`
* `Upswimage`
* `Upswvideo`
* `Runtime`
* `Ping`
* `Self`
* `Public`

### Maker
* `Sticker`
* `Removebg Sticker`
* `Circle Sticker`

### Downloader
* `IG Download`
* `FB Download`
* `YT Play`

### Grup
* `Hidetag`

### Photo Editor
* `Circle`
* `Amazingtypo`
* `3dblock`
* `Flameup`
* `Rosepetals`
* `Lovelyframe`
* `Valentine`
* `Pipframe`
* `Violetframe`
* `Brilliant`
* `Beautiful`
* `Mintframe`	

## Note:
* Fiturnya Masih Sedikit Silahkan tambahin sendiri terimakasih :).

# Special Thanks To :
* [`Baileys`](https://github.com/adiwajshing/Baileys)
* [`MhankBarBar`](https://github.com/MhankBarBar)
* [`Lindow`](https://github.com/lindow666)
* [`Hexagonz`](https://github.com/Hexagonz)
