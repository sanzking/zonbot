(async () => {
			switch(command){ 
		case 'tebakkata':
		//fzn.tebakkata
		//gambargame.push(from)
		timeout = 120000
         jidnye = from
		  if (jidnye in fzn.tebakkata) {
			return reply('Masih ada soal belum terjawab di chat ini')
		  }
		  gas = await getJson('http://fazone-app.tk/tebakkata.php')
		  teksna = `
*「 TEBAK KATA 」*\n\n
${gas.pertanyaan}

Silahkan Reply Pesan ini Dengan Mengetik jawabannya
Ketik ${prefix}teka untuk bantuan
    `.trim()
  fzn.tebakkata[jidnye] = [
    await fzn.sendMessage(from, teksna, text, { quoted: msg }),
    gas,
    setTimeout(() => {
      if (fzn.tebakkata[jidnye]) reply(`Waktu habis!\nJawabannya adalah *${gas.jawaban}*`)
		//gambargame.splice(from, 1)
      delete fzn.tebakkata[jidnye]
    }, timeout)
  ]
        break
		case 'teka':
		json = fzn.tebakkata[from][1]
		reply('```' + json.jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_') + '```')
        break
			}
			
		})();		
//Textmaker BY Fazone
