(async () => {
			switch(command){ 
        case 'buatcase':
			if (!q) return reply('Silahkan Ketik .buatcase & nama Pluginnya kak')
			if (!q.endsWith('.js')) return reply('Pastikan Ketik Anda beserta extensi yaitu dengan akhiran .js')
			if(deteksiFile.includes(q)) return reply('Nama Plugin Sudah Tersedia Mohon Buat Nama Plugin Yang Berbeda!!!!')	
			go = 'Silahkan Reply Pesan Ini Hanya Dengan Memasukan Text Case Saja!!!'
			fzn.sendMessage(from, go, text, {quoted: msg, messageId: q})
		break
			}
			
		})();		
//Textmaker BY Fazone
