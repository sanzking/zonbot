(async () => {
	const bufferen = async (url, options) => {
			try {
				options ? options : {}
				const res = await axios({
					method: "get",
					url,
					headers: {
						'DNT': 1,
						'Upgrade-Insecure-Request': 1
					},
					...options,
					responseType: 'arraybuffer'
				})
				return res.data
			} catch (e) {
				console.log(`Error : ${e}`)
			}
		}
		
			switch(command){ 
		case 'tebaklagu':
		const getRandom = () => {
			return `${Math.floor(Math.random() * 10000)}`
		}
		//fzn.tebaklagu
		//gambargame.push(from)
		timeout = 120000
         jidnye = from
		  if (jidnye in fzn.tebaklagu) {
			return reply('Masih ada soal belum terjawab di chat ini')
		  }
		  gas = await getJson('http://fazone-app.tk/tebaklagu.php')
		  if(gas.preview === null) return reply('Server Error Ulangi Lagi')
		  let caption = `
*「 TEBAK LAGU 」*\n\nTimeout *${(timeout / 1000).toFixed(2)} detik*
Silahkan Reply Pesan ini/Audionya
Dengan Mengetik teks judul lagu
Ketik ${prefix}cek untuk bantuan
    `.trim()
  fzn.tebaklagu[jidnye] = [
    await fzn.sendMessage(from, caption, text, { quoted: msg }),
    gas,
    setTimeout(() => {
      if (fzn.tebaklagu[jidnye]) reply(`Waktu habis!\nJawabannya adalah *${gas.judul}*`)
		//gambargame.splice(from, 1)
      delete fzn.tebaklagu[jidnye]
    }, timeout)
  ]
   fzn.sendMessage(from, await bufferen(gas.preview), audio, {quoted: msg, mimetype: 'audio/mp4', messageId:'BYFAZONE' + randomfzn()})
        break
		case 'cek':
		let json = fzn.tebaklagu[from][1]
		reply('```' + json.judul.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_') + '```')
        break
			}
			
		})();		
//Textmaker BY Fazone
