(async () => {
			switch(command){ 
        case 'totext':
					if (!isQuotedAudio) return reply('reply audionya kak :v')
					konver = getRandom('.mp3')
					const getbuff = JSON.parse(JSON.stringify(msg).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					const dlfile = await fzn.downloadMediaMessage(getbuff)
					fs.writeFileSync('./libpy/'+ konver, dlfile)
					exec(`python stt.py ${konver}`,{cwd: path.join(process.cwd(), 'libpy')}, async (err, stdout, stderr) => {
					hasil = '*Berhasil Mengkonversi Voice To Text Kata Ditemukan* : ' + stdout.split("Transcript:  ")[1]
					reply(hasil);
					fs.unlinkSync('./libpy/'+ konver)
					fs.unlinkSync('./libpy/'+ konver + '.wav')
					});
				break
				case 'byfzn':
				const buttons = [{
        buttonId: 'id1',
        buttonText: {
          displayText: 'Menu'
        },
        type: 1
      },
        {
          buttonId: 'id2',
          buttonText: {
            displayText: 'creator'
          },
          type: 1
        }]
      const buttonsMessage = {
        contentText: "FZN-BOT\n\nSilahkan Klik Menu Di Bawah Ini Untuk Menampilkan List Fitur",
        footerText: 'FZN-SELF',
        buttons: buttons,
        headerType: 1
      }
      const sendMsg = await fzn.prepareMessageFromContent(from, {
        buttonsMessage
      }, {})

      fzn.relayWAMessage(sendMsg)
	  break
			}
		})();		
//Textmaker BY Fazone
