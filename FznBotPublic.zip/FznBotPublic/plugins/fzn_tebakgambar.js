(async () => {
			switch(command){ 
        case 'tebakgambar':
		//fzn.tebakgambar
		//gambargame.push(from)
		timeout = 120000
         jidnye = from
		  if (jidnye in fzn.tebakgambar) {
			return fazone.sendMessage('Masih ada soal belum terjawab di chat ini', MessageType.text, {quoted: fzn.tebakgambar[from][0]})
		  }
		  gas = await getJson('https://docs-api-zahirrr.herokuapp.com/api/quote?type=tebakgambar')
		  caption = `
*「 TEBAK GAMBAR 」*\n\nTimeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${prefix}hint untuk hint
    `.trim()
  fzn.tebakgambar[jidnye] = [
    await fzn.sendMessage(from, await getBuffer(gas.images), image, { quoted: msg, caption: caption }),
    gas,
    setTimeout(() => {
      if (fzn.tebakgambar[jidnye]) fazone.sendMessage(`Waktu habis!\nJawabannya adalah *${gas.jawaban}*`, MessageType.text, {quoted: fzn.tebakgambar[from][0]})
		//gambargame.splice(from, 1)
      delete fzn.tebakgambar[jidnye]
    }, timeout)
  ]
        break
		case 'hint':
		json = fzn.tebakgambar[from][1]
		reply('```' + json.jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_') + '```')
        break
			}
			
		})();		
//Textmaker BY Fazone
