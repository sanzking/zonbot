(async () => {
			switch(command){
/////////////XTEAM PHOTOOXY //////////////////////////
		case 'photooxy':
			if(budy){	
				menus = `*「 PHOTOOXY 」*

${prefix}wolfmetal [ teks ]
${prefix}underwebmatrix [ teks ]
${prefix}multimaterial [ teks ]
${prefix}underwaterocean [ teks ]
${prefix}smoke [ teks ]
${prefix}typography [ teks ]
${prefix}wolflogogalaxy [ teks ]
${prefix}neonlight [ teks ]
${prefix}google [ teks ]
${prefix}rainbowshine [ teks ]
${prefix}camuflage [ teks ]
${prefix}3dglowing [ teks ]
${prefix}vintage [ teks ]
${prefix}candy [ teks ]
${prefix}gradientavatar [ teks ]
${prefix}glowingrainbow [ teks ]
${prefix}stars [ teks ]
${prefix}fur [ teks ]
${prefix}flaming [ teks ]
${prefix}crispchrome [ teks ]
${prefix}kueultah [ teks ]
${prefix}rainbowbg [ teks ]
${prefix}metalicglow [ teks ]
${prefix}striking3d [ teks ]
${prefix}watermelon [ teks ]
${prefix}harrypotter [ teks ]
${prefix}luxuryroyal [ teks ]
${prefix}gerbang [ teks ]
${prefix}woodblock [ teks ]
${prefix}smoketypography [ teks ]
${prefix}sweetcandy [ teks ]
${prefix}silk [ teks ]
${prefix}bevel [ teks ]
${prefix}partyneon [ teks ]
${prefix}greenleaves [ teks ]
${prefix}modernmetal [ teks ]
${prefix}lolcover [ teks ]
${prefix}warface [ teks ]
${prefix}pentakill [ teks ]
${prefix}aov [ teks ]
${prefix}avatarlol [ teks ]
${prefix}pokemon [ teks ]
${prefix}lolavatarglitch [ teks ]
${prefix}shinebannerlol [ teks ]
${prefix}mastery7lol [ teks ]
${prefix}dota2avatar [ teks ]
${prefix}lol [ teks ]
${prefix}crossfire [ teks ]
${prefix}glowpentakill [ teks ]
${prefix}warfacecover [ teks ]
${prefix}coveroverwatch [ teks ]
${prefix}lolcover2 [ teks ]
${prefix}scgo [ teks ]
${prefix}lolpentakill [ teks ]`

		Kirim.FakeGroup(from, menus, fakenya)
		} else if(btnid) {
				
			var urutan2 = []
			var cmdphotooxy = ['wolfmetal',	'underwebmatrix',	'multimaterial',	'underwaterocean',	'smoke',	'neonlight',	'rainbowshine',	'camuflage',	'3dglowing',	'vintage',	'candy',	'gradientavatar',	'glowingrainbow',	'stars',	'fur',	'flaming',	'crispchrome',	'kueultah',	'rainbowbg',	'metalicglow',	'striking3d',	'watermelon',	'harrypotter',	'luxuryroyal',	'gerbang',	'woodblock',	'smoketypography',	'sweetcandy',	'silk',	'bevel',	'partyneon',	'greenleaves',	'modernmetal',	'lolcover',	'warface',	'pentakill',	'aov',	'avatarlol',	'pokemon',	'lolavatarglitch',	'shinebannerlol',	'mastery7lol',	'dota2avatar',	'lol',	'crossfire',	'glowpentakill',	'warfacecover',	'coveroverwatch',	'lolcover2',	'scgo',	'lolpentakill']
			var menuphotooxy = ['Wolf Metal',	'Under Web Matrix',	'Multi Material',	'Under Water Ocean',	'Smoke Text',	'Neon Light',	'Rainbow Shine',	'Camu Flage',	'3D Glowing',	'Vintage Text',	'Candy Text',	'Gradient Avatar',	'Glowing Rainbow',	'Stars Text',	'Fur Text',	'Flaming Text',	'Crisp Chrome',	'Kue Ultah',	'Rainbow Bg',	'Metalic Glow',	'Striking 3D',	'Water Melon',	'Harry Potter',	'Luxury Royal',	'Gerbang',	'Wood Block',	'Smoke Typo Graphy',	'Sweet Candy',	'Silk Text',	'Bevel Text',	'Party Neon',	'Green Leaves',	'Modern Metal',	'Lol Cover',	'Warface Text',	'Penta Kill',	'Aov Text',	'Avatar Lol',	'Pokemon Text',	'Lol Avatar Glitch',	'Shine Banner Lol',	'Mastery 7 Lol',	'Dota2 Avatar',	'Lol Text',	'Cross Fire',	'Glow Penta Kill',	'Warface Cover',	'Cover Over Watch',	'Lol Cover 2',	'Scgo Text',	'Lol Penta Kill']
			let ngetang2 = 1
			let pilihane2 = 0
			for(let gege1 of cmdphotooxy){
				const titel1 = menuphotooxy[pilihane2++]
				const gayana1 = {
					title: `╭────────────── ${ngetang2++} ─────────────╮`,
					rows:[
						{
							title: titel1,
							description: null,
							rowId: prefix + gege1		
						}
					]
				}
				urutan2.push(gayana1)
			}
			SendlistMSG(from, '*PHOTOOXY TEXT MAKER*', 'Silahkan Pilih Sesuai Selera :)', urutan2)
		}
		break

			case 'wolfmetal':
			case 'underwebmatrix':
			case 'multimaterial':
			case 'underwaterocean':
			case 'smoke':
			case 'typography':
			case 'wolflogogalaxy':
			case 'neonlight':
			case 'google':
			case 'rainbowshine':
			case 'camuflage':
			case '3dglowing':
			case 'vintage':
			case 'candy':
			case 'gradientavatar':
			case 'glowingrainbow':
			case 'stars':
			case 'fur':
			case 'flaming':
			case 'crispchrome':
			case 'kueultah':
			case 'rainbowbg':
			case 'metalicglow':
			case 'striking3d':
			case 'watermelon':
			case 'harrypotter':
			case 'luxuryroyal':
			case 'gerbang':
			case 'woodblock':
			case 'smoketypography':
			case 'sweetcandy':
			case 'silk':
			case 'bevel':
			case 'partyneon':
			case 'greenleaves':
			case 'modernmetal':
			case 'lolcover':
			case 'warface':
			case 'pentakill':
			case 'aov':
			case 'avatarlol':
			case 'pokemon':
			case 'lolavatarglitch':
			case 'shinebannerlol':
			case 'mastery7lol':
			case 'dota2avatar':
			case 'lol':
			case 'crossfire':
			case 'glowpentakill':
			case 'warfacecover':
			case 'coveroverwatch':
			case 'lolcover2':
			case 'scgo':
			case 'lolpentakill':
					if(budy){	
                    if (!q) return reply(`Example: ${prefix + command} Adul Alhy`)
					reply(warn.mess.wait)
                    getBuffer(`https://api.xteam.xyz/photooxy/${command}?text=${q}&APIKEY=${xteamkey}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v' })
                    })
					}else if(idlistmsg){
						captina = `*${titlelist} Maker*\n\nBalas Pesan Ini Lalu Masukan Teks Untuk Membuat Tema Seperti Ini`
						gambar = await getBuffer(`https://api.xteam.xyz/photooxy/${command}?text=Example&APIKEY=${xteamkey}`)
						fzn.sendMessage(from, gambar, image, { quoted: msg, caption: captina, messageId: command+'PHOTOOXY '+randomfzn() })
					}
					break

///====================================================================================================================================>				
		case 'ephoto':
			if(budy){	
				menus = `*「 EPHOTO 」*

${prefix}wetglass [teks ]
${prefix}multicolor3d [teks ]
${prefix}watercolor [teks ]
${prefix}luxurygold [teks ]
${prefix}galaxywallpaper [teks ]
${prefix}lighttext [teks ]
${prefix}beautifulflower [teks ]
${prefix}puppycute [teks ]
${prefix}royaltext [teks ]
${prefix}heartshaped [teks ]
${prefix}birthdaycake [teks ]
${prefix}galaxystyle [teks ]
${prefix}hologram3d [teks ]
${prefix}greenneon [teks ]
${prefix}glossychrome [teks ]
${prefix}greenbush [teks ]
${prefix}metallogo [teks ]
${prefix}noeltext [teks ]
${prefix}glittergold [teks ]
${prefix}textcake [teks ]
${prefix}starsnight [teks ]
${prefix}wooden3d [teks ]
${prefix}textbyname [teks ]
${prefix}writegalacy [teks ]
${prefix}galaxybat [teks ]
${prefix}snow3d [teks ]
${prefix}birthdayday [teks ]
${prefix}goldplaybutton [teks ]
${prefix}silverplaybutton [teks ]
${prefix}freefire [teks ]`

		Kirim.FakeGroup(from, menus, fakenya)
		} else if(btnid) {
				
			var urutan = []
			var cmdephoto = ['wetglass','multicolor3d','watercolor','luxurygold','galaxywallpaper','lighttext','beautifulflower','puppycute','royaltext','heartshaped','birthdaycake','galaxystyle','hologram3d','greenneon','glossychrome','greenbush','metallogo','noeltext','glittergold','textcake','starsnight','wooden3d','textbyname','writegalacy','galaxybat','snow3d','birthdayday','goldplaybutton','silverplaybutton','freefire']			
			var menuephoto = ['Wet Glass','Multi Color 3D','Water Color','Luxury Gold','Galaxy Wallpaper','Light Text','Beautiful Flower','Puppy Cute','Royal Text','Heart Shaped','Birthday Cake','Galaxy Style','Hologram 3D','Green Neon','Glossy Chrome','Green Bush','Metal Logo','Noel Text','Glitter Gold','Text Cake','Star Snight','Wooden 3D','Text By Name','Write Galacy','Galaxy Bat','Snow 3D','Birthday Day','Gold Play Button','Silver Play Button','Free Fire']
			let ngetang = 1
			let pilihane = 0
			for(let gege of cmdephoto){
				const titel = menuephoto[pilihane++]
				const gayana = {
					title: `╭────────────── ${ngetang++} ─────────────╮`,
					rows:[
						{
							title: titel,
							description: null,
							rowId: prefix + gege		
						}
					]
				}
				urutan.push(gayana)
			}
			SendlistMSG(from, '*EPHOTO TEXT MAKER*', 'Silahkan Pilih Sesuai Selera :)', urutan)
		}
		break
        case 'tahta':
          if (!q) return reply('Teksnya mana kak?')
          req = `https://fazone-api.herokuapp.com/api/hartatahta?text=${q}&apikey=${apikey}`
          Kirim.FileDariUrl(from, req, msg, 'Ini kak :v')
        break
                case 'glitch':
					reply(warn.mess.wait)
				 if (args.length == 0) return reply(`Example: ${prefix + command} Adul Alhy`)
                    txt1 = args[0]
                    txt2 = args[1]
                    req = `https://fazone-api.herokuapp.com/api/photooxy/glitch?text=${txt1}&text2=${txt2}&apikey=${apikey}`
                       Kirim.FileDariUrl(from, req, msg, 'Ini kak :v')
        break
                    break
                case 'arcade8bit':
                case 'battlefield4':
                case 'pubg':
					reply(warn.mess.wait)
                    if (args.length == 0) return reply(`Example: ${prefix + command} Adul Alhy`)
                    txt1 = args[0]
                    txt2 = args[1]
                    getBuffer(`https://api.lolhuman.xyz/api/photooxy2/${command}?apikey=${LolApi}&text1=${txt1}&text2=${txt2}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg })
                    })
                    break
          case 'wetglass':
                case 'multicolor3d':
                case 'watercolor':
                case 'luxurygold':
                case 'galaxywallpaper':
                case 'lighttext':
                case 'beautifulflower':
                case 'puppycute':
                case 'royaltext':
                case 'heartshaped':
                case 'birthdaycake':
                case 'galaxystyle':
                case 'hologram3d':
                case 'greenneon':
                case 'glossychrome':
                case 'greenbush':
                case 'metallogo':
                case 'noeltext':
                case 'glittergold':
                case 'textcake':
                case 'starsnight':
                case 'wooden3d':
                case 'textbyname':
                case 'writegalacy':
                case 'galaxybat':
                case 'snow3d':
                case 'birthdayday':
                case 'goldplaybutton':
                case 'silverplaybutton':
                case 'freefire':
					if(budy){	
                    if (!q) return reply(`Example: ${prefix + command} Adul Alhy`)
					reply(warn.mess.wait)
                    getBuffer(`https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${LolApi}&text=${q}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v' })
                    })
					}else if(idlistmsg){
						captina = `*${titlelist} Maker*\n\nBalas Pesan Ini Lalu Masukan Teks Untuk Membuat Tema Seperti Ini`
						gambar = await getBuffer(`https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${LolApi}&text=Example`)
						fzn.sendMessage(from, gambar, image, { quoted: msg, caption: captina, messageId: command+'TEXTMAKER '+randomfzn() })
					}
                    break
					/////////////XTEAM TEXTPRO //////////////////////////
		case 'textpro':
			if(budy){	
				menus = `*「 TEXTPRO 」*

${prefix}neon [ teks ]
${prefix}snowtext [ teks ]
${prefix}cloudtext [ teks ]
${prefix}3dluxury [ teks ]
${prefix}3dgradient [ teks ]
${prefix}blackpink [ teks ]
${prefix}realisticcloud [ teks ]
${prefix}cloudsky [ teks ]
${prefix}sandsummerbeach [ teks ]
${prefix}sandwriting [ teks ]
${prefix}sandengraved [ teks ]
${prefix}summerysandwriting [ teks ]
${prefix}balloontext [ teks ]
${prefix}3dglue [ teks ]
${prefix}balloontext [ teks ]
${prefix}metaldarkgold [ teks ]
${prefix}neongalaxy [ teks ]
${prefix}1917 [ teks ]
${prefix}minion3d [ teks ]
${prefix}holographic3d [ teks ]
${prefix}metalpurpledual [ teks ]
${prefix}deluxesilver [ teks ]
${prefix}glossybluemetal [ teks ]
${prefix}deluxegold [ teks ]
${prefix}glossycarbon [ teks ]
${prefix}fabric [ teks ]
${prefix}happnewyearfirework [ teks ]
${prefix}newyear3d [ teks ]
${prefix}neontext [ teks ]
${prefix}metaldarkgoldeffect [ teks ]
${prefix}helloweenfire [ teks ]
${prefix}bloodontheroastedglass [ teks ]
${prefix}xmas3d [ teks ]
${prefix}jokerlogo [ teks ]
${prefix}wicker [ teks ]
${prefix}naturalleaves [ teks ]
${prefix}fireworksparkle [ teks ]
${prefix}skeleton [ teks ]
${prefix}redfoilballon [ teks ]
${prefix}purplefoilballon [ teks ]
${prefix}pinkfoilballon [ teks ]
${prefix}greenfoilballon [ teks ]
${prefix}cyanfoilballon [ teks ]
${prefix}bluefoilballon [ teks ]
${prefix}goldfoilballon [ teks ]
${prefix}steel [ teks ]
${prefix}ultragloss [ teks ]
${prefix}denim [ teks ]
${prefix}decorategreen [ teks ]
${prefix}decoratepurple [ teks ]
${prefix}peridotstone [ teks ]
${prefix}rock [ teks ]
${prefix}lava [ teks ]
${prefix}yellowglass [ teks ]
${prefix}purpleglass [ teks ]
${prefix}orangeglass [ teks ]
${prefix}greeglass [ teks ]
${prefix}cyanglass [ teks ]
${prefix}blueglass [ teks ]
${prefix}redglass [ teks ]
${prefix}purpleshnyglass [ teks ]
${prefix}captainamerica [ teks ]
${prefix}robotr2d2 [ teks ]
${prefix}toxic [ teks ]
${prefix}rainbowequalizer [ teks ]
${prefix}pinksparklingjewelry [ teks ]
${prefix}bluesparklingjewelry [ teks ]
${prefix}greensparklingjewelry [ teks ]
${prefix}purplesparklingjewelry [ teks ]
${prefix}goldsparklingjewelry [ teks ]
${prefix}redsparklingjewelry [ teks ]
${prefix}cyansparklingjewelry [ teks ]
${prefix}purpleglass2 [ teks ]
${prefix}decorativeglass [ teks ]
${prefix}chocolatecake [ teks ]
${prefix}strawberry [ teks ]
${prefix}koifish [ teks ]
${prefix}bread [ teks ]
${prefix}matrixstyle [ teks ]
${prefix}hororrblood [ teks ]
${prefix}neonlight [ teks ]
${prefix}thunder [ teks ]
${prefix}3dbox [ teks ]
${prefix}neon4 [ teks ]
${prefix}roadwarning [ teks ]
${prefix}3dsteel [ teks ]
${prefix}bokeh [ teks ]
${prefix}greenneon [ teks ]
${prefix}advancedglow [ teks ]
${prefix}dropwater [ teks ]
${prefix}breakwall [ teks ]
${prefix}chrismastgift [ teks ]
${prefix}honey [ teks ]
${prefix}plasticbagdrug [ teks ]
${prefix}horrorgift [ teks ]
${prefix}marbleslabs [ teks ]
${prefix}marble [ teks ]
${prefix}icecold [ teks ]
${prefix}fruitjuice [ teks ]
${prefix}rustymetal [ teks ]
${prefix}abstragold [ teks ]
${prefix}biscuit [ teks ]
${prefix}bagel [ teks ]
${prefix}wood [ teks ]
${prefix}scifi [ teks ]
${prefix}metalrainbow [ teks ]
${prefix}purplegem [ teks ]
${prefix}shinymetal [ teks ]
${prefix}yellowjewelry [ teks ]
${prefix}silverjewelry [ teks ]
${prefix}redjewelry [ teks ]
${prefix}purplejewelry [ teks ]
${prefix}orangejewelry [ teks ]
${prefix}greenjewelry [ teks ]
${prefix}cyanjewelry [ teks ]
${prefix}bluejewelry [ teks ]
${prefix}hotmetal [ teks ]
${prefix}hexagolden [ teks ]
${prefix}blueglitter [ teks ]
${prefix}purpleglitter [ teks ]
${prefix}pinkglitter [ teks ]
${prefix}greenglitter [ teks ]
${prefix}silverglitter [ teks ]
${prefix}goldglitter [ teks ]
${prefix}bronzeglitter [ teks ]
${prefix}erodedmetal [ teks ]
${prefix}carbon [ teks ]
${prefix}pinkcandy [ teks ]
${prefix}bluemetal [ teks ]
${prefix}bluegem [ teks ]
${prefix}blackmetal [ teks ]
${prefix}3dlowingmetal [ teks ]
${prefix}3dchrome [ teks ]
`

		Kirim.FakeGroup(from, menus, fakenya)
		} else if(btnid) {
				
			var urutan3 = []
			var cmdtextpro = ["neon","snowtext","cloudtext","3dluxury","3dgradient","blackpink","realisticcloud","cloudsky","sandsummerbeach","sandwriting","sandengraved","summerysandwriting","balloontext","3dglue","balloontext","metaldarkgold","neongalaxy","1917","minion3d","holographic3d","metalpurpledual","deluxesilver","glossybluemetal","deluxegold","glossycarbon","fabric","happnewyearfirework","newyear3d","neontext","metaldarkgoldeffect","helloweenfire","bloodontheroastedglass","xmas3d","jokerlogo","wicker","naturalleaves","fireworksparkle","skeleton","redfoilballon","purplefoilballon","pinkfoilballon","greenfoilballon","cyanfoilballon","bluefoilballon","goldfoilballon","steel","ultragloss","denim","decorategreen","decoratepurple","peridotstone","rock","lava","yellowglass","purpleglass","orangeglass","greeglass","cyanglass","blueglass","redglass","purpleshnyglass","captainamerica","robotr2d2","toxic","rainbowequalizer","pinksparklingjewelry","bluesparklingjewelry","greensparklingjewelry","purplesparklingjewelry","goldsparklingjewelry","redsparklingjewelry","cyansparklingjewelry","purpleglass2","decorativeglass","chocolatecake","strawberry","koifish","bread","matrixstyle","hororrblood","neonlight","thunder","3dbox","neon4","roadwarning","3dsteel","bokeh","greenneon","advancedglow","dropwater","breakwall","chrismastgift","honey","plasticbagdrug","horrorgift","marbleslabs","marble","icecold","fruitjuice","rustymetal","abstragold","biscuit","bagel","wood","scifi","metalrainbow","purplegem","shinymetal","yellowjewelry","silverjewelry","redjewelry","purplejewelry","orangejewelry","greenjewelry","cyanjewelry","bluejewelry","hotmetal","hexagolden","blueglitter","purpleglitter","pinkglitter","greenglitter","silverglitter","goldglitter","bronzeglitter","erodedmetal","carbon","pinkcandy","bluemetal","bluegem","blackmetal","3dlowingmetal","3dchrome"]
			var menutextpro = ["Neon Light","Snow Text","Cloud Text","3D Luxury","3D Gadient","Blackpink Text","Realistic Cloud","Cloud Sky","Sand Summer Beach","Sand Writing","Sand Engraved","Summery Writing","Ballon Text","3D Glue","Space 3D","Metal Dark Gold","Neon Galaxy","1917 Text","Minion 3D","Holographic 3D","Metal Purple","Deluxe Silver","Blue Metal","Deluxe Gold","Glossy Carbon","Fabric Text","Happy New Year","New Year 3D","Neon Text","Dark Gold Effect","Helloween Fire","Blood Text","Xmas 3D","Joker Logo","Wicker Text","Natural Leaves","Firework Sparkle","Skeleton Text","Red Foil Ballon","Purple Foil Ballon","Pink Foil Ballon","Green Foil Ballon","Cyan Foil Ballon","Blue Foil Ballon","Gold Foil Ballon","Steel Text","Ultra Gloss","Denim Text","Decorate Green","Decorate Purple","Peridot Stone","Rock Text","Lava Text","Yellow Glass","Purple Glass","Orange Glass","Green Glass","Cyan Glass","Blue Glass","Red Glass","Purple Shiny Glass","Capatain America","Robot R2D2","Toxic Text","Rainbow Equalizier","Pink Sparkling Jewelry","Blue Sparkling Jewelry","Green Sparkling Jewelry","Purple Sparkling Jewelry","Gold Sparkling Jewelry","Red Sparkling Jewelry","Cyan Sparkling Jewelry","Purple Glass 2 ","Decorative Glass","Chocolate Cake","Strawberry Text","Koi Fish","Bread Text","Matrix Style","Horror Blood","Neon Light","Thunder","3D Box","Neon 2","Road Warning","3D Steel","Bokeh Text","Green Neon","Advanced Glow","Drop Water","Break Wall","Chrismast Gift","Honey Text","Plastic Bag Drug","Horror Gift","Marble Slabs","Marble Text","Ice Old Text","Fruit Juice","Rusty Metal","Abstra Gold","Biscuit Text","Bagel Text","Wood Text","SCI FI Text","Metal Rainbow","Purple Gem","Shiny Metal","Yellow Jewelry","Silver Jewelry","Red Jewelry","Purple Jewelry","Orange Jewelry","Green Jewelry","Cyan Jewelry","Blue Jewelry","Hot Metal","Hexa Golden","Blue Glitter","Purple Glitter","Pink Glitter","Green Glitter","Silver Glitter","Gold Glitter","Bronze Glitter","Eroded Metal","Carbon Text","Pink Candy","Blue Metal","Blue Gem","Black Metal","3D Lowing Metal","3D Chrome"]
			let ngetang3 = 1
			let pilihane3 = 0
			for(let gege3 of cmdtextpro){
				const titel1 = menutextpro[pilihane3++]
				const gayana1 = {
					title: `╭────────────── ${ngetang3++} ─────────────╮`,
					rows:[
						{
							title: titel1,
							description: null,
							rowId: prefix + gege3		
						}
					]
				}
				urutan3.push(gayana1)
			}
			SendlistMSG(from, '*TEXTPRO TEXT MAKER*', 'Silahkan Pilih Sesuai Selera :)', urutan3)
		}
		break

			case 'neon':
			case 'snowtext':
			case 'cloudtext':
			case '3dluxury':
			case '3dgradient':
			case 'blackpink':
			case 'realisticcloud':
			case 'cloudsky':
			case 'sandsummerbeach':
			case 'sandwriting':
			case 'sandengraved':
			case 'summerysandwriting':
			case 'balloontext':
			case '3dglue':
			case 'balloontext':
			case 'metaldarkgold':
			case 'neongalaxy':
			case '1917':
			case 'minion3d':
			case 'holographic3d':
			case 'metalpurpledual':
			case 'deluxesilver':
			case 'glossybluemetal':
			case 'deluxegold':
			case 'glossycarbon':
			case 'fabric':
			case 'happnewyearfirework':
			case 'newyear3d':
			case 'neontext':
			case 'metaldarkgoldeffect':
			case 'helloweenfire':
			case 'bloodontheroastedglass':
			case 'xmas3d':
			case 'jokerlogo':
			case 'wicker':
			case 'naturalleaves':
			case 'fireworksparkle':
			case 'skeleton':
			case 'redfoilballon':
			case 'purplefoilballon':
			case 'pinkfoilballon':
			case 'greenfoilballon':
			case 'cyanfoilballon':
			case 'bluefoilballon':
			case 'goldfoilballon':
			case 'steel':
			case 'ultragloss':
			case 'denim':
			case 'decorategreen':
			case 'decoratepurple':
			case 'peridotstone':
			case 'rock':
			case 'lava':
			case 'yellowglass':
			case 'purpleglass':
			case 'orangeglass':
			case 'greeglass':
			case 'cyanglass':
			case 'blueglass':
			case 'redglass':
			case 'purpleshnyglass':
			case 'captainamerica':
			case 'robotr2d2':
			case 'toxic':
			case 'rainbowequalizer':
			case 'pinksparklingjewelry':
			case 'bluesparklingjewelry':
			case 'greensparklingjewelry':
			case 'purplesparklingjewelry':
			case 'goldsparklingjewelry':
			case 'redsparklingjewelry':
			case 'cyansparklingjewelry':
			case 'purpleglass2':
			case 'decorativeglass':
			case 'chocolatecake':
			case 'strawberry':
			case 'koifish':
			case 'bread':
			case 'matrixstyle':
			case 'hororrblood':
			case 'neonlight':
			case 'thunder':
			case '3dbox':
			case 'neon4':
			case 'roadwarning':
			case '3dsteel':
			case 'bokeh':
			case 'greenneon':
			case 'advancedglow':
			case 'dropwater':
			case 'breakwall':
			case 'chrismastgift':
			case 'honey':
			case 'plasticbagdrug':
			case 'horrorgift':
			case 'marbleslabs':
			case 'marble':
			case 'icecold':
			case 'fruitjuice':
			case 'rustymetal':
			case 'abstragold':
			case 'biscuit':
			case 'bagel':
			case 'wood':
			case 'scifi':
			case 'metalrainbow':
			case 'purplegem':
			case 'shinymetal':
			case 'yellowjewelry':
			case 'silverjewelry':
			case 'redjewelry':
			case 'purplejewelry':
			case 'orangejewelry':
			case 'greenjewelry':
			case 'cyanjewelry':
			case 'bluejewelry':
			case 'hotmetal':
			case 'hexagolden':
			case 'blueglitter':
			case 'purpleglitter':
			case 'pinkglitter':
			case 'greenglitter':
			case 'silverglitter':
			case 'goldglitter':
			case 'bronzeglitter':
			case 'erodedmetal':
			case 'carbon':
			case 'pinkcandy':
			case 'bluemetal':
			case 'bluegem':
			case 'blackmetal':
			case '3dlowingmetal':
			case '3dchrome':
					if(budy){	
                    if (!q) return reply(`Example: ${prefix + command} Adul Alhy`)
					reply(warn.mess.wait)
                    getBuffer(`https://api.xteam.xyz/textpro/${command}?text=${q}&APIKEY=${xteamkey}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v' })
                    })
					}else if(idlistmsg){
						captina = `*${titlelist} Maker*\n\nBalas Pesan Ini Lalu Masukan Teks Untuk Membuat Tema Seperti Ini`
						gambar = await getBuffer(`https://api.xteam.xyz/textpro/${command}?text=Example&APIKEY=${xteamkey}`)
						fzn.sendMessage(from, gambar, image, { quoted: msg, caption: captina, messageId: command+'TEXTPRO '+randomfzn() })
					}
					break

///====================================================================================================================================>
			}
			
		})();		
//Textmaker BY Fazone
