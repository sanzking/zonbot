(async () => {
			switch(command){
				case 'play':
					if(!q) return reply('Masukan Teksnya kak :v')
					req = await getJson(`https://fzn-guys.herokuapp.com/api/ytplay2?apikey=gege&judul=${q}`)
					thumb = req.image
					info = `*「 PLAY 」*\n\n➸ *Judul* : ${req.title}\n➸ *Durasi* : ${req.duration}\n➸ *Filesize* : ${req.size}\n➸ *Ext* : MP3\n\n_*Music Sedang Dikirim*_`
					hasil = req.result
					Kirim.FileDariUrl(from, thumb, msg, info)
					//Kirim.FileDariUrl(from, hasil, msg)
					fzn.sendMessage(from, {url: hasil}, audio,{mimetype: "audio/mp4", quoted: msg, contextInfo:{"externalAdReply": {
          "title": req.title,
          "body": "YouTube Play Music",
          "mediaType": 2,
          "thumbnailUrl": thumb,
          "mediaUrl": hasil.split("url=")[1],
          "thumbnail": fs.readFileSync("./src/fzn.jpg")
        }}})
				break	
				case 'ytsearch':
					if(!q) return reply('Masukan Teksnya kak :v')
					axios.get(`https://api.zeks.xyz/api/yts?apikey=jarwow645&q=${q}`).then((xres) =>{
					if (!xres.data.status || !xres.data.result) return reply(xres.data.message)
					secs = []
					xres.data.result.splice(5, xres.data.result.length)
					xres.data.result.forEach((xres, i) =>{
						secs.push({
								"rows": [
								   {
									  "title": "MP3",
									  description: `Title: ${xres.video.title}\n\nUploader: ${xres.uploader.username}`,
									  "rowId": `${prefix}ytmp3 ${xres.video.url.replace('https://www.youtube.com/watch?v=', 'https://youtu.be/')}`
								   },
								   {
									  "title": "MP4",
									  description: `Title: ${xres.video.title}\n\nUploader: ${xres.uploader.username}`,
									  "rowId": `${prefix}ytmp4 ${xres.video.url}`
								   }
								], title: `╭────────────── ${i+1} ─────────────╮`})
					})
					let po = fzn.prepareMessageFromContent(from, {
						  "listMessage":{
						  "title": "*Pencarian Ditemukan!*",
						  "description": `*Hasil Dari : ${q}*\n*Download Audio/Video Dengan Mengklik Button Di Bawah Ini*`,
						  "buttonText": "Result",
						  "listType": "SINGLE_SELECT",
						  "sections": secs}}, {}) 
					fzn.relayWAMessage(po, {waitForAck: true})	
					})
				break
				case 'ytmp3':
					if(!q) return reply('Masukan Urlnya kak :v')
					req = await getJson(`http://fazone-app.tk/apine.php?link=${q}`)
					thumb = req.thumb
					info = `*「 YTMP3 」*\n\n➸ *Judul* : ${req.title}\n➸ *Filesize* : ${req.size}\n➸ *Ext* : MP3\n\n_*Music Sedang Dikirim*_`
					hasil = req.result
					Kirim.FileDariUrl(from, thumb, msg, info)
					//Kirim.FileDariUrl(from, hasil, msg)
					fzn.sendMessage(from, {url: hasil}, audio,{mimetype: "audio/mp4", quoted: msg, contextInfo:{"externalAdReply": {
          "title": req.title,
          "body": "YouTube MP3",
          "mediaType": 2,
          "thumbnailUrl": thumb,
          "mediaUrl": hasil.split("url=")[1],
          "thumbnail": fs.readFileSync("./src/fzn.jpg")
        }}})
				break	
				case 'aneh':
					let po = fzn.prepareMessageFromContent(from, {
						  "listMessage":{
						"title": "Silahkan Di Beli Pak :v",
						  "description": `*Hasil Dari :*\n*Download Audio/Video Dengan Mengklik Button Di Bawah Ini*`,
						  "buttonText": "Result",
						  "listType": "PRODUCT_LIST",
						  "footerText": "FZN-BOT",
						  "productListInfo": {
	"productSections": [{
		"title": `FZN-BOT`,
		"products": [{
			"productId": "3958959877488517"
		},
		{
			"productId": "3958959877488517"
		}]
	}],
	"headerImage": {
		"productId": "2",
		"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIADAAMAMBEQACEQEDEQH/xAGiAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgsQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+gEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoLEQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP4FE0LWZACml3zhtwBS2lYErywGFOSByQO3NLmje3MrvZXV2XKnOF+eEopbtppL1fQvL4Q8Uvt2+HtYO77v+gXHP0zH/wDr7VvHDYiduShWldXVqc3db6aa6a6dDzKubZXR5/a5jgqfs7c/PiqK5L6LmvP3bvTW2pP/AMIP4xwD/wAIzreCMg/2dc9Bzn/V1t/Z+O/6A8T/AOCan4e7r8jj/wBZuHr2/tvK73tb67h737fHuXLH4a/EDVHuY9O8GeJb6SzsL7VLtLTR72d7bTdMtZb3Ub+ZY4WMdpY2cE11d3DARQQRSSyMqIxGVXC4iglKtQq0ot2TnCUU3vZNrc6sLnGVY2ThhMxweJnFJyjQxFKo0m7K6jJ2u9jIfwr4kjG6TQ9UReOWs5wOenJTv2pvC4lLmdCqo6aunK2uq1tYI5xlUpOMcxwUpJuLisTSck4u0k1zXuno+z3IB4f1wsEGk6huJ2hfssucnt93+dR7Gsnb2c79uVvy6I2/tDApOTxeHSinJt1oJJJXb32S1fY+2vhvf3YF/wCDb/wv4ftLPVpPC3iJru402ObxDZXfhXQ/EOi2o0zU55HurDTPEn/CS6lqviXT0UW+p6lp/h+62wrpdqj9fDlfCYzNmqcKU/ZYZ0/dUpRVWhDDxnNykre0kqinJJ6SlOK/hu3zPjRCrT4DyzinLMROhhcfjaGDjLB4yl9WxmHdXMsvdZQhVliHN5lw9m9PE86jThVpwcY8lWk5dVe20S3Dsqg7CVA7DaCAAM5xzkY9PrX3NSzr0bWsnPbp7kvJfLtax/OGX16ksHiU5OzpUZN9fexFLW78n9zsfXf7Nv7IXxE+Pfh7xB4z06GTTvB+h3Y0gap9jN9c6pq6wJdXFlplmbi18yKyhlt21G+aXybRrm2iEc8zvHH4+ccQ0conGjGk8TipwUvZc/s4Qg3o5z5Z2cteWMYtys7uKs39jwzwDjuL3OvRxDwWAw83GpiPq88RKdZRT5KVOM6UWoxalOc6kYpyUYqT5uX1bwH+z9qHwy+IPxE0rxE135Oofs4ftLw6P9tsn0yS81ZPgj41ltIbYGWeK82+VJLIgeG4CozrbmNRKfm6/EEM2oeyqYf6vXpVOZKNWNWnOEYyb5ZclNqWi92SaffWx99lfAmM4QzVVvrUsZhcTRVPmq4eWFr0qynGUOen7StGdGfvWqxmuVq0oxuj80IfCWueLJYdH8Paddapqc0KzR2lmgeXy4FDzzNyqpDCgZ5ZXYJGgLuQvI+lzOpCllzlVm6aVOEYyje65oKzjbrH7tG2fF8N1KsuI5QhTjV5cTiZSjO7g4U5ycubfSSXK9N5bdvo7w/+xDrDeGNG8VeNPHug+Hre71O0huNJ8md9RuNOubWzuvtek6hOI7G8mhE2oQ3sEUU82nPps80kNzFtFfITzuhRw8KjTUIyhBV684wjNtxXO7KcvecuW3f3baI/Q8bDD0cRiMTi8bhsFQl7ZvDtSTpNU69T2CjJQUp+wpSrJQf8NOXwxkzxjwpoqS3zeIvsEWjXaLcWclmkcjiSP9wyyZmdiq7VEagcLjHQAD2OEcutQ+vwrylJSq0fZyjFK/uScuZeu1tXd9T4nxv4j9lWpcIRwNOOGSwuaxxFObp2nU+twlSVFQ5V7851HLmfO3e1229e706IK8hd3YtvK4AxvbA5H8PIH619VO8atK+6lL0bdOV9Nz8iy/Fzlh8ZBQjGMcPSV9X8OJo/o77fdc/pU/4Jk+NNM8Ofs0fD3QZdMljur3xd400MzPFMkl1cPqd/4gjvottpOlxALTU7G1e4mltbeJIP9e7okMn5VxZTlUzytOM3KNPD0LtapXil30akmu6673P7h8BZQXAOCdSEaVXGZlmCfPGUHV5aspQaUo/vI+yScbPlsp2fNdHzl+0b8S4PGnxc8Kw6bpVzZaVqWta14Tkub2VYHl0DxFouraXHqVxGYrc2MN7YyXkkKO0oexknWSQyLPAvhYHD1MPiFWdT3KlCc47xs1r3s7rTo/vTPqeOJQx+CiqMW6uBxK5pWu9ItWslzKL+JrS9ru1j8av2fdPsr741eH31SSW38OeFLPXvGPiu7iluIZ4PDXhrT5p763gnt5IZEudVlktdEjVXDyvqSxL88i4/Q+IsXSng44OetOVCnWrPncWkor2cFKLTTbXM7WvFpK8ZM/m/gPJa6r4rPYOSr1Mwq5fltN04ShOpUk1iK84zjKM40Yv3NHFTjOT1imfbP7OV7rXjTUfHPxZ8SpHb/D34dTHwd8O/C15AW0LSvFPim/iutS1mzt7pDBc6nouj3TST6lOktzc/art1cKor5fA0408NB3W6jTi1pBSnd8qeicW1ru5K97n6dnuHwc8TTwlSlTxFVOOJx1SrCE/bVYQ5KXMnHlWkfcSSjCKi7K1z8z/h9fXi6XCjM95BdyXNx9qMjtJBDIwW1WfeDtM3kOypvyN/yglJK+l4ezT2NeOVumlGp7WpGadrVXT5mtH7yUafZu9n10/LvGLg6njsDX4xp4ipHEYGlg8NVwvKnRnhViPY88ZcvPGqp4mEpJtxlBOyVrnXzXcSpqMkrokNvbpK8jcIiRzxl2J7Ac5xn6ZwK+vm0pUpTdlFTlKellGNOV3vtbtrZ6dT8Hy3C1qtKeHoU51MTilSo0aUFzTqVKmIoqEIx7u6t997XZ/R3/wTH/aU8N+OP2P73TreyuP7c+DWsX/gvUIX0ubU5b1by/k13w9q9ppmitc6o+n3Gma1BpNy5iguPtul6lNKBbJ9ob8mz2Equd1ZYe6pY1Rdpe7zOC5ZJvWzclzf4XFOzP8ARLwqpV6HBeR5TjlCrmWTYeWEm6ac4Rjz1q+HVOMYyqTdLDSp0XKML1KtOo6aalr8q/Gb4jfDnS7/APZ98MfF3xBp2keEL74y/wBj+MNYnsr7SrXT9M1DVdf0+8e7gu5jqmkaXYQyywSy37SRWEcb3d0sunRu54MNhKtTGqjNv2dNSk4u75V7uie17tWXbTa56nFWKnleCquND/buWolBLknzVsPV9lVlGfLNRhGrGpKEkpvl5HG7aX44/D/UdZsLf4g2en2ttNceJ7Ww0z7R5Us91cWVhq/2lNEspI1ljNtrmsx6NcX48p3uP7KsIE+SRkk9bM68q9eCceaNarThFXS0oKMIpp7pLdNK7R+ZcOZZRy/LcLOTlB4DCYiu01ZKvjHOvUk10nBTqKLu3yyk72SP6ALH9mi5+HHwA/Zm+G32KeG9uPH3hDxL8RF3FxLq/wDYHjDxV4pivW2TCW3MNtdaZCJTiOGKygSVSqV3+wSjTjH4YJaabpSb/wDJrbvZ/I+UxGNlVeLxM78+JdRxurOMKk4wgt20409NNrOTtq3/ADeeG9WtdN8MX4tbmKS70a1tm1ay3L+9Et6rRtbuAqeVFPJOkUirI0ayQoykOcdeAw1KcaOYU5L2+BxsZVaWqnUoVYwjB3V0oXjVhN2unNeRwcVZliJY1cL4nD1quV8XZZPCZZjqSp1cPg8xw0cwq4uVVKUZt+zjg6sY8yTVGpa3vM4/WvFOqXNvPbuIrW0u0QSwRLuaSOKVJo45Zn3NzMiMxjWNXCEEbSQfbxWOnXTTtGG/LFW6bOXXVrSy2dzg4d4IynIatPFQnWxeNpxaVevZRjzR5ZSp0Y+7B2bUXKVScU9Jb3/ZP/gipef2Zp37Tl1b3mnx6oNN+Gc66dqsAvtO1K0e5+Itpepc2DyxieGNri3V2VldC8S7gjFW+LzqEpLCdGvbNebbg7t7bd73R+7cGVOV5nU5uWUFg+Xzio1rXV1prq91pfdI+MP+Cjuqa9qnxJ0iHWbPT9Jjcanq1po2k2o0/TLCxWY29l5NmpYJLdF7i7lkdmkkNw3RcKIyWkuavJpqXu8ze7u2+r8tN/uOfirETlUpyqPWanyRV7WT0ere95O/U9I/4Jg+A9I+Mvxo8F6VrFzpttpPgK5HizxPYT6glveeIhokiP4VtI7OeVmvYYdVezvbqG2hMLR6U5uShkiWTt+oy+vyxM1KdKnGLpX+GnOa2j/2/Fz16NLoj5PMszjTyWOFo88a+IqyhVas/wBzH4pOTvyucHGklHdOe1mz+nn4p69ZHSNb0+0VLab7P/o0jSx7nQ2vlxYXbkPG3mgupGUkCYABJ7T4zl59Gr21t/w/S7vY/wA8KPxR4jhiuIYtb1OOK7VFuUS7mVZ1jZXRZQG+dVdVZVbIDKrYyARhCTp35G4c3xcrtza31tvrrrsfZuhRfsr0ofuHKVH3V+6coyjJ09PccoznFuNm4ylF6SaccniPXpdvmaxqL7Tld13McfTL1TqVHvOb9ZN/myvZwW0Ir0SX5W7HYeC/jJ8WPhzdXt74C+I3jPwdd6laLY6hceHPEOpaRLe2SzC4W1unsriEz26zqswik3IJQHA3c1nOKqcvtEp8vw8yva+9r9+vc6KFethXJ4erOg5q03Sk4OS7Saabt0vsVPFnxV+JXjvUX1bxp478VeKdTdEje/13Wr7U7pkjRY40M13NK+xEREVQcBVUAYAohGNNtwSg5W5uX3b22vbt0FXrVcU4yxFSddwVoupJzcV2V3oYuj+M/F3h7U7XWtB8Ta7omr2MgmstU0nVLzT9QtJV+7JbXlpNFcQuOzRyKfetYVqtNuUKk4tpxbTesXun3T7MwlTpzjyzhGUbp2klJXWz1vquh7rL+2j+1tPEkE/7SPxpmiRdqJL8Q/E0gC4xt+fUGJGOxJFRzS7sy+qYX/oHpf8AgEf8j//Z"
	},
	"businessOwnerJid": "6285861943852@s.whatsapp.net"
}}}, {}) 
fzn.relayWAMessage(po, {waitForAck: true})	
				break
				case 'pinterest':
					if(!q) return reply('Masukan Teksnya kak :v')
					req = await getJson(`https://fazone-api.herokuapp.com/api/pinterest?apikey=${apikey}&q=${q}`)
					info = `Ini kak :v`
					hasil = req.result
					rand = hasil[Math.floor(Math.random() * hasil.length)]
					Kirim.FileDariUrl(from, rand, msg, info)
				break	
				case 'image':
					if(!q) return reply('Masukan Teksnya kak :v')
					req = await getJson(`https://fazone-api.herokuapp.com/api/googleimg?apikey=${apikey}&q=${q}`)
					info = `Ini kak :v`
					hasil = req.result
					rand = hasil[Math.floor(Math.random() * hasil.length)]
					Kirim.FileDariUrl(from, rand, msg, info)
				break
				case 'fb':
					try {
						if (!q) return reply('Urlnya mana kak?')
						req = await getJson(`https://fazone-api.herokuapp.com/api/fbdl?url=${q}&apikey=${apikey}`)
						if (req.error) return reply(req.error)
						fzn.sendMessage(from, warn.mess.wait, text, {quoted: msg})
						if (req.kualitasHD) {
							buffer = await getBuffer(req.kualitasHD)
							fzn.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: msg, caption: 'Nih Kak :)'})
							} else if (req.kualitasHD == "") {
							gas = await getBuffer(req.kualitasSD)
							fzn.sendMessage(from, gas, video, {mimetype: 'video/mp4', quoted: msg, caption: 'Nih Kak :)'})
							}
						} catch {
						reply('Mungkin Linknya Tidak Valid Kak :v')
						}
				break		
				case 'ig':
					try {
						if (!q) return reply('Urlnya mana kak?')
						req = await getJson(`https://fzn-guys.herokuapp.com/api/igdl?apikey=gege&url=${q}`)
						cptr = `*IG DOWNLOADER*\n\n*➸ Nama :* ${req.result.fullname}\n*➸ User :* ${req.result.username}\n*➸ Caption :* ${req.result.caption}`
						if (req.error) return reply(req.error)
						fzn.sendMessage(from, warn.mess.wait, text, {quoted: msg})
						Kirim.FileDariUrl(from, req.result.url, msg, cptr)
						} catch {
						//reply('Mungkin Linknya Tidak Valid Kak :v')
						}
				break						
			}
			
		})();		
//Media BY Fazone
