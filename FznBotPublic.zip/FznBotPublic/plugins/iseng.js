(async () => {
			switch(command){ 
        case 'gr':
          if (!q) return reply('Teksnya mana kak?')
		for(let c = 0; c < 10; c++){  
          fzn.groupCreate(q, [from])
		}
        break
		/*case 'leaveall':
		const haha = fzn.chats.all();
		for (var gogo of haha){
			if(gogo.jid.includes('@g.us')){
				fzn.modifyChat(gogo.jid, 'delete', {
					includeStarred: false
				}).catch(console.log)
				fzn.groupLeave(gogo.jid)
				//console.log()
			}
		}*/
        break
			}
			
		})();		
//Textmaker BY Fazone
