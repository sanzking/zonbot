const
	{
		WAConnection,
		MessageType,
		Presence,
		MessageOptions,
		Mimetype,
		WALocationMessage,
		WA_MESSAGE_STUB_TYPES,
		WA_DEFAULT_EPHEMERAL,
		ReconnectMode,
		ProxyAgent,
		GroupSettingChange,
		waChatKey,
		mentionedJid,
		processTime,
		BaileysError
	} = require("@adiwajshing/baileys")
const { pesane, fznNEW } = require('./lib/msgcustom')	
const { getJson, getBuffer } = require("./lib/getdata");
const moment = require("moment-timezone")
const chalk = require('chalk')
const fs = require('fs-extra')
const { spawn, exec, execSync, spawnSync } = require("child_process")
const speed = require('performance-now')
const request = require("request");
const axios = require('axios')
const FormData = require('form-data')
const { Readable, Duplex } = require('stream');
const path = require('path')
const os = require('os')
const { isLimit, limitAdd, getLimit, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = require("./lib/limit");
const { serialize, fetchText, runtime } = require("./lib/myfunc");
const _prem = require("./lib/premium");
const qrcode = require("qrcode");
//const ms = require("pretty-ms");
const ms = require('@shreyash21/ms');
const toMS = require("humanize-ms");
const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
const ffmpeg = require('fluent-ffmpeg');
ffmpeg.setFfmpegPath(ffmpegPath);
const kripton = require('crypto')
const fetch = require("node-fetch");
const util = require("util")
const pino = require('pino')
const logger = pino({
	prettyPrint: { levelFirst: true, ignore: 'hostname', translateTime: true },  prettifier: require('pino-pretty')
})
const logna = logger.child({ Dev: 'FAZONE' })

let ngulik = JSON.parse(fs.readFileSync('./database/ngulik.json'))
let hitna = JSON.parse(fs.readFileSync('./database/hit.json'))
let pendaftar = JSON.parse(fs.readFileSync('./database/user.json'))
let setting = JSON.parse(fs.readFileSync('./config.json'));
let limit = JSON.parse(fs.readFileSync('./database/limit.json'));
let glimit = JSON.parse(fs.readFileSync('./database/glimit.json'));
let balance = JSON.parse(fs.readFileSync('./database/balance.json'));
let bangrup = JSON.parse(fs.readFileSync('./database/bangrup.json'));
let bancmd = JSON.parse(fs.readFileSync('./database/bancmd.json'));
let premium = JSON.parse(fs.readFileSync('./database/premium.json'));
let sewa = JSON.parse(fs.readFileSync('./database/sewa.json'));
let ban = JSON.parse(fs.readFileSync('./database/ban.json'));
let antilink = JSON.parse(fs.readFileSync('./database/antilink.json'));
let autosticker = JSON.parse(fs.readFileSync('./database/autosticker.json'));
let antinsfw = JSON.parse(fs.readFileSync('./database/antinsfw.json'));
let nsfw = JSON.parse(fs.readFileSync('./database/nsfw.json'));
let antivirtex = JSON.parse(fs.readFileSync('./database/antivirtex.json'));
let badword = JSON.parse(fs.readFileSync('./database/badword.json'));
let grupbadword = JSON.parse(fs.readFileSync('./database/grupbadword.json'));
let senbadword = JSON.parse(fs.readFileSync('./database/senbadword.json'));
let mute = JSON.parse(fs.readFileSync('./database/mute.json'));
let _leveling = JSON.parse(fs.readFileSync('./database/leveling.json'))
let _level = JSON.parse(fs.readFileSync('./database/level.json'))
let _registered = JSON.parse(fs.readFileSync('./database/registered.json'))
let _respon = JSON.parse(fs.readFileSync('./database/respon.json'))
let _stick = JSON.parse(fs.readFileSync('./database/sticker.json'))
let _vn = JSON.parse(fs.readFileSync('./database/vn.json'))
let _update = JSON.parse(fs.readFileSync('./database/update.json'))
let _image = JSON.parse(fs.readFileSync('./database/image.json'))
let _video = JSON.parse(fs.readFileSync('./database/video.json'))
let _document = JSON.parse(fs.readFileSync('./database/document.json'))
let _scommand = JSON.parse(fs.readFileSync('./database/scommand.json'))
let _claim = JSON.parse(fs.readFileSync('./database/claim.json'))


// COLOR
const color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text)
}

///Function batrai
const baterai = {
	battery: "" || "Tidak terdeteksi",
isCharge: "" || false
}

const getGroupAdmins = (participants) => {
			admins = []
			for (let i of participants) {
			i.isAdmin ? admins.push(i.jid) : ''
			}
			return admins
		}

///Function
selfna = false
fakenya = 'FAZONE'

let {
    ownerNumber,
    limitCount,
    lolkey,
    vhkey,
    zekskey,
    xteamkey,
    fznkey,
    gamewaktu
} = setting

nopref = false
//pemberitahuan = false
gambargame = []
let sae = []
//var akgasss = ''
const getRandom = (ext) => {
	return `${Math.floor(Math.random() * 10000) + ext}`
}
//

if (global.conns instanceof Array) console.log()
else global.conns = []

setInterval(function() { //FUNCTION JADWAL
		var jamna = new Date().toLocaleTimeString('en-US', { timeZone: "Asia/Jakarta" });
		hasilnes = jamna.split(':')[0] < 10 ? '0' + jamna : jamna
         // hasilnes Kalo mau Jam 00 jadi 12:00:00 AM
	  if(hasilnes === '12:00:00 AM'){
			// reset hit
			hitna.hit.hitday = 0
			hitna['hit'] = hitna.hit
			fs.writeFileSync('./database/hit.json', JSON.stringify(hitna))
			//resetlimit & claim
			var ob = []
			  var rest = limit.indexOf()
			  limit.splice(rest)
			  fs.writeFileSync('./database/limit.json', JSON.stringify(ob));
			  _claim.splice(_claim.indexOf())
			  fs.writeFileSync('./database/limit.json', JSON.stringify(ob));
				console.log("Reset limit!");	
			}
    }, 1000); 
	
            // Leveling
            const getLevelingXp = (userId) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].jid === userId) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].xp
               }
            }

            const getLevelingLevel = (userId) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].jid === userId) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].level
                }
            }

            const getLevelingId = (userId) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].jid === userId) {
                    position = i
                }
            })
            if (position !== false) {
                return _level[position].jid
                }
             }

            const addLevelingXp = (userId, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].jid === userId) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].xp += amount
                fs.writeFileSync('./database/level.json', JSON.stringify(_level))
                }
            }

            const addLevelingLevel = (userId, amount) => {
            let position = false
            Object.keys(_level).forEach((i) => {
                if (_level[i].jid === userId) {
                    position = i
                }
            })
            if (position !== false) {
                _level[position].level += amount
                fs.writeFileSync('./database/level.json', JSON.stringify(_level))
                }
            }

            const addLevelingId = (userId) => {
            const obj = {jid: userId, xp: 1, level: 1}
            _level.push(obj)
            fs.writeFileSync('./database/level.json', JSON.stringify(_level))
            }

            const getUserRank = (userId) => {
    let position = null
    let found = false
    _level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
    Object.keys(_level).forEach((i) => {
        if (_level[i].id === userId) {
            position = i
            found = true
        }
    })
    if (found === false && position === null) {
        const obj = { id: userId, xp: 0, level: 1 }
        _level.push(obj)
        fs.writeFileSync('./database/level.json', JSON.stringify(_level))
        return 99
    } else {
        return position + 1
    }
}

const xpGain = new Set()

const isGained = (userId) => {
    return !!xpGain.has(userId)
}

const addCooldown = (userId) => {
    xpGain.add(userId)
    setTimeout(() => {
        return xpGain.delete(userId)
    }, 60000) // Each minute
}

	
module.exports = fzn = async (fzn, msg) => {
	try {
        if (!msg.hasNewMessage) return
        msg = msg.messages.all()[0]
		if (!msg.message) return
		if (msg.key && msg.key.remoteJid == 'status@broadcast') return
        msg.message = (Object.keys(msg.message)[0] === 'ephemeralMessage') ? msg.message.ephemeralMessage.message : msg.message
        const content = JSON.stringify(msg.message)
		const from = msg.key.remoteJid
		fzn.updatePresence(from, Presence.unavailable)
		const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
		const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
        const type = Object.keys(msg.message)[0]        
		//const isQuotedMsg = type == "extendedTextMessage" && content.includes("contextInfo") && content.includes("quotedMessage") && content.includes("imageMessage") && content.includes("caption")
        const cmd = (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type == 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type == 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type == 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : ''.slice(1).trim().split(/ +/).shift().toLowerCase()	
		const fazone = new pesane(fzn, msg)
		const Kirim = new fznNEW(fzn)
		const prefix = /^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+@,;]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+,;]/gi) : '-'          	
        const idlistmsg = type === "listResponseMessage" ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : ""	
		const btnid = type === "buttonsResponseMessage" ? msg.message.buttonsResponseMessage.selectedButtonId : ""	
		const STIKReply = type === "imageMessage" ? msg.message.imageMessage.contextInfo.stanzaId : ""	
		const stcna2 = STIKReply ? STIKReply.includes('STICKERNA') : false
		const Pngirim2 = type == "imageMessage" && msg.message.imageMessage.contextInfo != null ? msg.message.imageMessage.contextInfo.participant || "" : ""
		fromAeng2 = Pngirim2 === (fzn.user && fzn.user.jid)
		
		const GRUPReply = type === "extendedTextMessage" ? msg.message.extendedTextMessage.contextInfo.stanzaId : ""	
		const GRP2 = GRUPReply ? GRUPReply.includes('GRUP') : false
		const Pngirim3 = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.participant || "" : ""
		fromAeng3 = Pngirim3 === (fzn.user && fzn.user.jid)
		
		//FUNCTION BARU
		if(fromAeng2){
		if(stcna2){
			var hayuslah = STIKReply.split('STICKERNA')[0]
		}
		}
		
		if(fromAeng3){
		if(GRP2){
			var gruplah = GRUPReply.split('GRUP')[0]
		}
		}
		
		
		filterna = (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type == 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type == 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type == 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : ''
		var replycmd = `${prefix + gruplah} ${filterna}`
		if(replycmd.includes(undefined)){
			replycmd = ''
		}
		var body = (type === 'conversation' && msg.message.conversation.startsWith(prefix)) ? msg.message.conversation : (type == 'imageMessage') && msg.message.imageMessage.caption.startsWith(prefix) ? msg.message.imageMessage.caption : (type == 'videoMessage') && msg.message.videoMessage.caption.startsWith(prefix) ? msg.message.videoMessage.caption : (type == 'extendedTextMessage') && msg.message.extendedTextMessage.text.startsWith(prefix) ? msg.message.extendedTextMessage.text : '' || idlistmsg || btnid || replycmd
		budy = (type === 'conversation') ? msg.message.conversation : (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text : ''
		var command = body.slice(1).trim().split(/ +/).shift().toLowerCase() || hayuslah
		const idbtn = type === "buttonsResponseMessage" ? msg.message.buttonsResponseMessage.selectedDisplayText : ""	
		const komun = idbtn.toLowerCase()	
		const titlelist = type === "listResponseMessage" ? msg.message.listResponseMessage.title : ""		
		const args = body.trim().split(/ +/).slice(1)
		const isCmd = body.startsWith(prefix)
		const q = args.join(' ')
		const jid = msg.key.remoteJid	
		const botNumber = fzn.user.jid
		const isGroup = from.endsWith('@g.us')
		let sender = isGroup ? msg.participant : msg.key.fromMe ? fzn.user.jid : msg.key.remoteJid
		const isOwner = ownerNumber.includes(sender)
		var isPremium = _prem.checkPremiumUser(sender, premium)
		var Limitnya = getLimit(sender, limitCount, limit)
		if (isPremium) {
		  cekExp = ms(_prem.getPremiumExpired(sender, premium) - Date.now())	
		  Limitnya = `*UNLIMITED*\nExpired : ${cekExp.days} Hari ${cekExp.hours} Jam ${cekExp.minutes} Menit`
		} else if (isOwner) {
			Limitnya = '*UNLIMITED*'
		} 
		
		if(isOwner){
		  isPremium = ownerNumber.includes(sender)
		}
		const isWelcome = isGroup ? global.welkom.includes(from) : false
		const isClaimOn = _claim.includes(sender)
		const totalchat = await fzn.chats.all()
		const groupMetadata = isGroup ? await fzn.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
        const myname = msg.key.fromMe ? fzn.user.jid : fzn.contacts[sender] || { notify: jid.replace(/@.+/, '') }
        const pushname = msg.key.fromMe ? fzn.user.name : myname.notify || myname.vname || myname.name || '-'
		const isMedia = (type === 'imageMessage' || type === 'videoMessage')
		const isQuotedImageBycapt = type === 'extendedTextMessage' && content.includes('caption')
		const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
		const isQuotedPesan = type === 'extendedTextMessage' && content.includes('conversation')
		const isQuotedMessage = type === 'extendedTextMessage'
		const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
		const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
		const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
		const detstick = type === 'stickerMessage' && msg.message.stickerMessage.contextInfo != null ? msg.message.stickerMessage.contextInfo.participant || "" : ""
		const pushnamena  = await fzn.contacts[sender] != undefined ? await fzn.contacts[sender].vname || fzn.contacts[sender].notify : undefined
		const isUser = pendaftar.includes(sender)
		const isLevelingOn = isGroup ? _leveling.includes(from) : false
		
		const randomfzn = () => {
			return kripton.randomBytes(4).toString('hex').toUpperCase()
		}
			
		function monospace(string) {
            return '```' + string + '```'
        }
		
		function randomNomor(angka){
            return Math.floor(Math.random() * angka) + 1
        }
		
		const nebal = (angka) => {
            return Math.floor(angka)
        }
		
		async function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
		
		if(budy.includes('resett')){
			ngulik[sender] = ngulik[sender] ? ngulik[sender] : { user: 'gada'}
			ngulik[sender].user = command
			fs.writeFileSync('./database/ngulik.json', JSON.stringify(ngulik))
		}
		
		if(selfna) {
			var statna = 'Public'
		}else{
			statna = 'Private'
		}
		fzn.modena = selfna ? 'SELF': 'PUBLIC'
		//const detrol = type === 'extendedTextMessage' && msg.message.extendedTextMessage.contextInfo.quotedMessage.orderMessage != null ? msg.message.extendedTextMessage.contextInfo.quotedMessage.orderMessage || "" : ""
		try{
			var detrol = msg.message.extendedTextMessage.contextInfo.quotedMessage.orderMessage
		} catch {
			
		}
		
		// Check Premium
        _prem.expiredCheck(premium)
		
		// auto regis
		 if (isCmd && !isUser){
			pendaftar.push(sender)
			fs.writeFileSync('./database/user.json', JSON.stringify(pendaftar))
        } 
		if (filterna.startsWith(prefix)){
			hitna.hit.totalhit += 1
			hitna.hit.hitday += 1
			hitna['hit'] = hitna.hit
			fs.writeFileSync('./database/hit.json', JSON.stringify(hitna))
        } 
		
		
		// rank level
		 var levelRole = getLevelingLevel(sender)
        var role = 'Copper V'
        if (levelRole <= 5) {
            role = 'Copper IV'
        } else if (levelRole <= 10) {
            role = 'Copper III'
        } else if (levelRole <= 15) {
            role = 'Copper II'
        } else if (levelRole <= 20) {
            role = 'Copper I'
        } else if (levelRole <= 25) {
            role = 'Silver V'
        } else if (levelRole <= 30) {
            role = 'Silver IV'
        } else if (levelRole <= 35) {
            role = 'Silver III'
        } else if (levelRole <= 40) {
            role = 'Silver II'
        } else if (levelRole <= 45) {
            role = 'Silver I'
        } else if (levelRole <= 50) {
            role = 'Gold V'
        } else if (levelRole <= 55) {
            role = 'Gold IV'
        } else if (levelRole <= 60) {
            role = 'Gold III'
        } else if (levelRole <= 65) {
            role = 'Gold II'
        } else if (levelRole <= 70) {
            role = 'Gold I'
        } else if (levelRole <= 75) {
            role = 'Platinum V'
        } else if (levelRole <= 80) {
            role = 'Platinum IV'
        } else if (levelRole <= 85) {
            role = 'Platinum III'
        } else if (levelRole <= 90) {
            role = 'Platinum II'
        } else if (levelRole <= 95) {
            role = 'Platinum I'
        } else if (levelRole < 100) {
            role = 'Exterminator'
        }

        var levelRoles = getLevelingLevel(sender)
        var roles = 'Cop V'
        if (levelRoles <= 5) {
            roles = 'Cop IV'
        } else if (levelRoles <= 10) {
            roles = 'Cop III'
        } else if (levelRoles <= 15) {
            roles = 'Cop II'
        } else if (levelRoles <= 20) {
            roles = 'Cop I'
        } else if (levelRoles <= 25) {
            roles = 'Sil V'
        } else if (levelRoles <= 30) {
            roles = 'Sil IV'
        } else if (levelRoles <= 35) {
            roles = 'Sil III'
        } else if (levelRoles <= 40) {
            roles = 'Sil II'
        } else if (levelRoles <= 45) {
            roles = 'Sil I'
        } else if (levelRoles <= 50) {
            roles = 'Gol V'
        } else if (levelRoles <= 55) {
            roles = 'Gol IV'
        } else if (levelRoles <= 60) {
            roles = 'Gol III'
        } else if (levelRoles <= 65) {
            roles = 'Gol II'
        } else if (levelRoles <= 70) {
            roles = 'Gol I'
        } else if (levelRoles <= 75) {
            roles = 'Plat V'
        } else if (levelRoles <= 80) {
            roles = 'Plat IV'
        } else if (levelRoles <= 85) {
            roles = 'Plat III'
        } else if (levelRoles <= 90) {
            roles = 'Plat II'
        } else if (levelRoles <= 95) {
            roles = 'Plati I'
        } else if (levelRoles < 100) {
            roles = 'Exter'
        }
		
		
		if (msg.message.hasOwnProperty('extendedTextMessage') &&
					msg.message.extendedTextMessage.hasOwnProperty('contextInfo') === true && 
					msg.message.extendedTextMessage.contextInfo.hasOwnProperty('quotedMessage') === true &&
					msg.message.extendedTextMessage.contextInfo.quotedMessage.hasOwnProperty('imageMessage') === true && 
					msg.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage.hasOwnProperty('caption')) {
						var captebak = msg.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage.caption
					} else {
						captebak = 'Gada';
					}
					
		if (msg.message.hasOwnProperty('extendedTextMessage') &&
					msg.message.extendedTextMessage.hasOwnProperty('contextInfo') === true && 
					msg.message.extendedTextMessage.contextInfo.hasOwnProperty('quotedMessage') === true &&
					msg.message.extendedTextMessage.contextInfo.quotedMessage.hasOwnProperty('conversation')) {
						var captxt = msg.message.extendedTextMessage.contextInfo.quotedMessage.conversation
					} else {
						captxt = 'Gada';
					}			
			//console.log(captebak)
			
		function waktune(seconds){
		function pad(s){
			return (s < 10 ? '0' : '') + s;
		}
		var hours = Math.floor(seconds / (60*60));
		var minutes = Math.floor(seconds % (60*60) / 60);
		var seconds = Math.floor(seconds % 60);
		return `${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik`
		}
		const waktos = process.uptime()
		const cts = waktune(waktos) 
		function secondsToHms(d) {
			d = Number(d);
			var h = Math.floor(d / 3600);
			var m = Math.floor(d % 3600 / 60);
			var s = Math.floor(d % 3600 % 60);

			var hDisplay = h > 0 ? h + (h == 1 ? " " + " Jam" + ", " : " " + " Jam" + ", ") : "";
			var mDisplay = m > 0 ? m + (m == 1 ? " " + " Menit" + ", " : " " + " Menit" + ", ") : "";
			var sDisplay = s > 0 ? s + (s == 1 ? " " + " Detik" : " " + " Detik") : "";
			return hDisplay + mDisplay + sDisplay; 
		}		
		
		const reply = async (teknya) => {
			var ids = teknya.includes('@') ? teknya.split('@') : []
			let pikirantag = [];
			for(var con of ids){
			  pikirantag.push(con.split(' ')[0]+'@s.whatsapp.net')
			}
			return fzn.sendMessage(from, teknya, MessageType.text, {quoted: fazone.data, contextInfo: {"mentionedJid": pikirantag}})
		}	
		
		const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? fzn.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : fzn.sendMessage(from, teks.trim(), extendedText, {quoted: msg, contextInfo: {"mentionedJid": memberr}})
			}
		
		const textImg = (teks) => {
            return fzn.sendMessage(from, teks, text, {quoted: msg, contextInfo: {"mentionedJid": [sender, "0@s.whatsapp.net"]},thumbnail: fs.readFileSync(setting.pathImg)})
        }
		
		function GetName(data){
			return fzn.contacts[data] != undefined ? fzn.contacts[data].vname || fzn.contacts[data].notify : '-'
		}

		
		/*const SendbtnMSG = async (buferimg, idna1, teks1, idna2, teks2, idna3, teks3, deskrip, watemak) => {
			const gblg = await fzn.prepareMessageMedia(await getFile(buferimg), image)
				const buttons = [{
					buttonId: idna1,
					buttonText: {
					  displayText: teks1
					},
					type: 1
				  },
					{
					  buttonId: idna2,
					  buttonText: {
						displayText: teks2
					  },
					  type: 1
					},
					{
					  buttonId: idna3,
					  buttonText: {
						displayText: teks3
					  },
					  type: 1
					}]
				  const buttonsMessage = {
					imageMessage: gblg.imageMessage,
					contentText: deskrip,
					footerText: watemak,
					buttons: buttons,
					headerType: 'IMAGE'
				  }
				  const sendMsg = await fzn.prepareMessageFromContent(from, {
					buttonsMessage
				  }, {quoted: msg})

				  fzn.relayWAMessage(sendMsg, {waitForAck: true})
			}*/
			
		fzn.answers = fzn.answers ? fzn.answers : {}
			if (filterna.startsWith(prefix) && !isOwner) {
			  fzn.answers[sender] = fzn.answers[sender] ? fzn.answers[sender] : { count: 0, isMute: false}
			  fzn.answers[sender].count += 1
			  /*if (fzn.answers[sender].count >= 3 && fzn.answers[sender].count < 6) {
				reply(`Peringatan Jangan Di Spam Command Karena Bot Ini Memilii Sistem Cooldown!!!`)
			  } else*/ 
			  if (fzn.answers[sender].count >= 5 && !fzn.answers[sender].isMute) {
				fzn.answers[sender].isMute = true
				if(command){ 
					return reply(`Anda Telah Menspam Bot! Tunggu 5 detik agar bisa menggunakan bot lagi`)
				//if(command)
				}
			  }
			 /* } else if (fzn.answers[sender].count <= 2) {
				return reply('ini answer biasa')
			  }*/
			  if (fzn.answers[sender].isMute) {
				command = null
				setTimeout(function() {
				  delete fzn.answers[sender]
				}, 5000);
			  }
			}
		

		const SendbtnMSG = async (buferimg, idna1, teks1, idna2, teks2, idna3, teks3, deskrip, watemak) => {
			if(buferimg.startsWith('https')||buferimg.startsWith('http')){
				var loaders = await getBuffer(buferimg)
			}else{
				loaders = fs.readFileSync(buferimg)
			}
			const gblg = await fzn.prepareMessageMedia(loaders, image)
				 var sendMsg = await fzn.prepareMessageFromContent(from, {
					"buttonsMessage": {
						"imageMessage": gblg.imageMessage,
						"contentText": deskrip,
						"footerText": watemak,
						"buttons": [
							{
								"buttonId": idna1,
								"buttonText": {
									"displayText": teks1
								},
								"type": "RESPONSE"
							},
							{
								"buttonId": idna2,
								"buttonText": {
									"displayText": teks2
								},
								"type": "RESPONSE"
							},
							{
								"buttonId": idna3,
								"buttonText": {
									"displayText": teks3
								},
								"type": "RESPONSE"
							}
						],
						"headerType": "IMAGE"
					}
				}, {})

         await fzn.relayWAMessage(sendMsg, {
            waitForAck: true
          })
			}
			
		const SendlistMSG = (from, title, desc, list) => { // Buat List Message
            let po = fzn.prepareMessageFromContent(from, {"listMessage": {"title": title,"description": desc,"buttonText": "Klik Disini","listType": "SINGLE_SELECT","sections": list,"footerText":'FZN-BOT'}}, {})
            return fzn.relayWAMessage(po, {waitForAck: true})
        }

		warn = {
			errorne: {
				wFormat: 'Format Salah!!!, Silahkan Cek Kembali...',
				onGroup: 'Khusus Di Grup!!!',
				onSelf: 'Only Self!!!'
			},
			mess: {
				"wait": "*Tunggu permintaan anda sedang diproses*",
				"error": {
					"Iv": "Link yang kamu berikan tidak valid",
					"api": "Maaf terjadi kesalahan"
				},
				"OnlyGrup": "Perintah ini hanya bisa digunakan di grup",
				"public": 'Bot Dalam Private Harap Menunggu Owner Mempublikasikan',
				"OnlyPM": "Perintah ini hanya bisa digunakan di private message",
				"GrupAdmin": "Perintah ini hanya bisa digunakan oleh Admin Grup",
				"BotAdmin": "Bot Harus menjadi admin",
				"OnlyOwner": "Perintah ini hanya dapat digunakan oleh owner bot",
				"OnlyPrem": "Perintah ini khusus member premium"
			}
		}
		
		warna = {
			grey: '\x1b[90m',
			red: '\x1b[91m',
			green: '\x1b[92m',
			yellow: '\x1b[93m',
			blue: '\x1b[94m',
			purple: '\x1b[95m',
			cyan: '\x1b[96m',
			white: '\x1b[37m',
			flag: '\x1b[47;30m',
			off: '\x1b[m',
			bgblack: "\x1b[40m",
			bgred: "\x1b[41m",
			bggreen: "\x1b[42m",
			bgyellow: "\x1b[43m",
			bgblue: "\x1b[44m",
			bgmagenta: "\x1b[45m",
			bgcyan: "\x1b[46m",
			bgwhite: "\x1b[47m"
		}
		
		fzn.tebakgambar = fzn.tebakgambar ? fzn.tebakgambar : {}
		fzn.tebaklagu = fzn.tebaklagu ? fzn.tebaklagu : {}
		fzn.tebakkata = fzn.tebakkata ? fzn.tebakkata : {}
		
		
		const ByReply = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.stanzaId || "" : ""
		const Pngirim = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.participant || "" : ""
		const fromBot = ByReply ? ByReply.startsWith('3EB0') && ByReply.length === 12 : false
		const fromFzn = ByReply ? ByReply.startsWith('BYFAZONE') : false
		const HARTA = ByReply ? ByReply.startsWith('HARTA') : false
		const txtMaker = ByReply ? ByReply.includes('TEXTMAKER') : false
		const photooxy = ByReply ? ByReply.includes('PHOTOOXY') : false
		const txtpro = ByReply ? ByReply.includes('TEXTPRO') : false
		const premi = ByReply ? ByReply.includes('PREMIUM') : false
		const stcna = ByReply ? ByReply.includes('STICKER') : false
		const makePlugin = ByReply ? ByReply.endsWith('.js') : false
		fromAeng = Pngirim === (fzn.user && fzn.user.jid)
		//console.log(fazone.mention)
		if(!msg.key.fromMe && !isOwner && selfna && command) return reply(warn.mess.public)
			
		if(selfna){
			if(!msg.key.fromMe){
				if(!isOwner && command||!isOwner && fromAeng||!isOwner && budy.toLowerCase() === 'bot') return reply(warn.mess.public)
			}
		}
		
		//FUNCTION BARU
		/*if(fromAeng){
		if(stcna){
			/*gazz = captebak.split('Maker')[0]
			hayus = gazz.replace('*','').replace(/ /g,'').toLowerCase()
			hayus = ByReply.split('STICKER')[0]
			command = prefix + hayus
		}
		}*/
		
		if(fromAeng){
		if(premi){
			/*gazz = captebak.split('Maker')[0]
			hayus = gazz.replace('*','').replace(/ /g,'').toLowerCase()*/
			hayus = ByReply.split('PREMIUM')[0]
			if(hayus === 'addprem'){
			console.log(hayus)
			if(!isOwner) return reply(warn.mess.OnlyOwner)
			if(fazone.mention !== false){
			if (_prem.getPremiumExpired(fazone.mention[0], premium)) return reply('Sudah premium kak :v')    	
				_prem.addPremiumUser(fazone.mention[0], "30d" , premium)
				fzn.sendMessage(from, `*「 PREMIUM ADD 」*\n*Name* : ${fazone.tagname}\n*Expired* : 30 DAY\n*thank for order premium*`, text, {quoted: msg})
				}else{
					reply('Format Salah!!!, Pastikan tag untuk membuat premium user')
				}
			}else if(hayus === 'delprem'){
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				if(fazone.mention !== false){
				if(!_prem.getPremiumExpired(fazone.mention[0], premium)) return reply('Dia Bukan premium kak :v')    	
				premium.splice(_prem.getPremiumPosition(fazone.mention[0], premium), 1)
				fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
				fzn.sendMessage(from, `*DONE BOS*`, text, {quoted: msg})
				}else{
					reply('Format Salah!!!, Pastikan tag untuk menghapus premium user')
				}
			}else if(hayus === 'clone'){
				try{
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Clone!!!')
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid[0]
				namanya = fzn.contacts[mentag] != undefined ? fzn.contacts[mentag].vname || fzn.contacts[mentag].notify : undefined			
				resultpp = await fzn.getProfilePicture(mentag)
				bufferna = await getBuffer(resultpp)
				fzn.updateProfilePicture(fzn.user.jid, bufferna)	
				fzn.updateProfileName(namanya)	
				reply(`Done\nTelah Mengclone user @${mentag.split('@')[0]}`)
				}catch{
					reply('ppnya gak ada kak :v')
				}
			}else if(hayus === 'kick'){
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins)return reply(warn.mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				if(fazone.mention !== false){
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Kick')
				reply(warn.mess.wait)	
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid
				if(mentag.includes(ownerNumber)) return reply(`Njirrr Masa Bosku Di Kick :(`)	
					if (mentag.length > 1) {
						teks = 'Berhasil Telah Mengeluarkan :\n'
						for (let _ of mentag) {
							teks += `@${_.split('@')[0]}\n`
						}
						setTimeout( () => {
						mentions(teks, mentag, true)
						}, 4000)
						setTimeout( () => {
			        fzn.groupRemove(from, mentag).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					} else {
						setTimeout( () => {
							fzn.sendMessage(from, `Berhasil Telah Mengeluarkan @${mentag[0].split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [mentag]}})
						}, 4000)
						setTimeout( () => {
			        fzn.groupRemove(from, [mentag[0]]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					}
				}else{
					reply('Format Salah!!!, Pastikan tag untuk mengkick!!!')
				}
			}else if(hayus === 'promote'){
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins)return reply(warn.mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				if(fazone.mention !== false){
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Kick')
				reply(warn.mess.wait)	
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentag.length > 1) {
						teks = 'Berhasil Menjadikan Admin :\n'
						for (let _ of mentag) {
							teks += `@${_.split('@')[0]}\n`
						}
						setTimeout( () => {
						mentions(teks, mentag, true)
						}, 4000)
						setTimeout( () => {
			        fzn.groupMakeAdmin(from, mentag).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					} else {
						setTimeout( () => {
							fzn.sendMessage(from, `Sakarang Kamu Jadi Admin @${mentag[0].split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [mentag]}})
						}, 4000)
						setTimeout( () => {
			        fzn.groupMakeAdmin(from, [mentag[0]]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					}
				}else{
					reply('Format Salah!!!, Pastikan tag/reply untuk mengkick!!!')
				}
			}else if(hayus === 'demote'){
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins)return reply(warn.mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				 if(fazone.mention !== false){
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Kick')
				reply(warn.mess.wait)	
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentag.length > 1) {
						teks = 'Berhasil Un Admin :\n'
						for (let _ of mentag) {
							teks += `@${_.split('@')[0]}\n`
						}
						setTimeout( () => {
						mentions(teks, mentag, true)
						}, 4000)
						setTimeout( () => {
			        fzn.groupDemoteAdmin(from, mentag).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					} else {
						setTimeout( () => {
							fzn.sendMessage(from, `Sakarang Kamu Tidak Jadi Admin Lagi @${mentag[0].split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [mentag]}})
						}, 4000)
						setTimeout( () => {
			        fzn.groupDemoteAdmin(from, [mentag[0]]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					}
				}else{
					reply('Format Salah!!!, Pastikan tag/reply untuk mengkick!!!')
				}
			}else if(hayus === 'ytsearch'){
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					axios.get(`https://api.zeks.xyz/api/yts?apikey=${zekskey}&q=${filterna}`).then((xres) =>{
					if (!xres.data.status || !xres.data.result) return reply(xres.data.message)
					const hasilv = xres.data.result	
					let	sabaraha = 1	
					secs = []
					for (let i = 0; i < hasilv.length; i++) {
						secs.push({
								"rows": [
								   {
									  "title": "MP3",
									  description: `Title: ${hasilv[i].video.title}\n\nUploader: ${hasilv[i].uploader.username}`,
									  "rowId": `${prefix}ytmp3 ${hasilv[i].video.url.replace('https://www.youtube.com/watch?v=', 'https://youtu.be/')}`
								   },
								   {
									  "title": "MP4",
									  description: `Title: ${hasilv[i].video.title}\n\nUploader: ${hasilv[i].uploader.username}`,
									  "rowId": `${prefix}ytmp4 ${hasilv[i].video.url}`
								   }
								], title: `╭────────────── ${sabaraha++} ─────────────╮`})
					}
					let po = fzn.prepareMessageFromContent(from, {
						  "listMessage":{
						  "title": "*Pencarian Ditemukan!*",
						  "description": `*Hasil Dari : ${filterna}*\n*Download Audio/Video Dengan Mengklik Button Di Bawah Ini*`,
						  "buttonText": "Klik Disini",
						  "listType": "SINGLE_SELECT",
						  "sections": secs}}, {}) 
					fzn.relayWAMessage(po, {waitForAck: true})
					})
			}
		}
		}
		
		if(fromAeng){
		if(txtMaker && captebak.includes('Maker')){
			/*gazz = captebak.split('Maker')[0]
			hayus = gazz.replace('*','').replace(/ /g,'').toLowerCase()*/
			if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
			limitAdd(sender, limit)	
			hayus = ByReply.split('TEXTMAKER')[0]
			console.log(hayus)
			reply(warn.mess.wait)
			getBuffer(`https://api.lolhuman.xyz/api/ephoto1/${hayus}?apikey=${LolApi}&text=${filterna}`).then((gambar) => {
                fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v'})
            })
		}
		}
		
		if(fromAeng){
		if(photooxy && captebak.includes('Maker')){
			/*gazz = captebak.split('Maker')[0]
			hayus = gazz.replace('*','').replace(/ /g,'').toLowerCase()*/
			if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
			limitAdd(sender, limit)	
			hayus = ByReply.split('PHOTOOXY')[0]
			console.log(hayus)
			reply(warn.mess.wait)
			getBuffer(`https://api.xteam.xyz/photooxy/${hayus}?text=${filterna}&APIKEY=${xteamkey}`).then((gambar) => {
                fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v'})
            })
		}
		}
		
		if(fromAeng){
		if(txtpro && captebak.includes('Maker')){
			/*gazz = captebak.split('Maker')[0]
			hayus = gazz.replace('*','').replace(/ /g,'').toLowerCase()*/
			if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
			limitAdd(sender, limit)	
			hayus = ByReply.split('TEXTPRO')[0]
			console.log(hayus)
			reply(warn.mess.wait)
			getBuffer(`https://api.xteam.xyz/textpro/${hayus}?text=${filterna}&APIKEY=${xteamkey}`).then((gambar) => {
                fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v'})
            })
		}
		}
		//
		//
		/*if(!filterna.startsWith(prefix)) {
		if(fromAeng){
		if(HARTA){
		  reply(warn.mess.wait)
		  req = `https://fazone-api.herokuapp.com/api/hartatahta?text=${filterna}&apikey=${fznkey}`
          Kirim.FileDariUrl(from, req, msg, 'Ini kak :v')
		}
		}
		}*/
		//TEBAK Kata
		if(!(filterna == prefix+'teka')) {
		if(filterna === 'Masih ada soal belum terjawab di chat ini' && msg.key.fromMe) throw false
		if(filterna.includes('Waktu habis!\nJawabannya adalah') && msg.key.fromMe) throw false	
		if(fromAeng){
		if(fromBot && captxt.includes('*「 TEBAK KATA 」*')){
		if (!(from in fzn.tebakkata)) return reply('Soal itu telah berakhir')
		if(ByReply == fzn.tebakkata[from][0].key.id) {
		json = JSON.parse(JSON.stringify(fzn.tebakkata[from][1]))
		if (filterna.toLowerCase() == json.jawaban.toLowerCase()) {
		  var htgmls = randomNomor(100)
            addBalance(sender, htgmls, balance)
		  reply(`*Jawaban Anda Benar!\n*Hadiah :* ${htgmls}*`)
		  clearTimeout(fzn.tebakkata[from][2])
		  //gambargame.splice(from, 1)
		  delete fzn.tebakkata[from]
		} else if (filterna.toLowerCase().endsWith(json.jawaban.split` `[1])) reply(`*Jawaban Anda Sedikit Lagi Benar!*`)
		//if(command) throw false 
	else reply(`*Jawaban Anda Salah!*`)
	  }
		}
		}
		}
		
		//TEBAK LAGU
		if(!(filterna == prefix+'cek')) {
		if(filterna === 'Masih ada soal belum terjawab di chat ini' && msg.key.fromMe) throw false
		if(filterna.includes('Waktu habis!\nJawabannya adalah') && msg.key.fromMe) throw false
		if(fromAeng){
		if(fromBot && captxt.includes('*「 TEBAK LAGU 」*') || fromFzn){
		if (!(from in fzn.tebaklagu)) return reply('Soal itu telah berakhir')
		if(ByReply == fzn.tebaklagu[from][0].key.id || fromFzn) {
		json = JSON.parse(JSON.stringify(fzn.tebaklagu[from][1]))
		if (filterna.toLowerCase() == json.judul.toLowerCase()) {
			var htgml = randomNomor(100)
            addBalance(sender, htgml, balance)
		  reply(`*Jawaban Anda Benar!\n*Hadiah :* ${htgml}*`)
		  clearTimeout(fzn.tebaklagu[from][2])
		  //gambargame.splice(from, 1)
		  delete fzn.tebaklagu[from]
		} else if (filterna.toLowerCase().endsWith(json.judul.split` `[1])) reply(`*Jawaban Anda Sedikit Lagi Benar!*`)
		//if(command) throw false 
	else reply(`*Jawaban Anda Salah!*`)
	  }
		}
		}
		}
		//if(gambargame.includes(from)){
		if(!(filterna == prefix+'hint')) {
		if(filterna === 'Masih ada soal belum terjawab di chat ini' && msg.key.fromMe) throw false
		if(filterna.includes('Waktu habis!\nJawabannya adalah') && msg.key.fromMe) throw false
		if(fromAeng){
		if(fromBot && captebak.includes('*「 TEBAK GAMBAR 」*')){
		if (!(from in fzn.tebakgambar)) return reply('Soal itu telah berakhir')
		if(ByReply == fzn.tebakgambar[from][0].key.id) {
		json = JSON.parse(JSON.stringify(fzn.tebakgambar[from][1]))
		if (filterna.toLowerCase() == json.jawaban.toLowerCase()) {
			var htgm = randomNomor(100)
            addBalance(sender, htgm, balance)
		  reply(`*Jawaban Anda Benar!\n*Hadiah :* ${htgm}*`)
		  clearTimeout(fzn.tebakgambar[from][2])
		  //gambargame.splice(from, 1)
		  delete fzn.tebakgambar[from]
		} else if (filterna.toLowerCase().endsWith(json.jawaban.split` `[1])) reply(`*Jawaban Anda Sedikit Lagi Benar!*`)
		//if(command) throw false 
	else reply(`*Jawaban Anda Salah!*`)
	  }
		}
		}
		}
		
		if(detrol){
				//reply('Troli PPK!!!')
				fzn.clearMessage(msg.key);
				//reply('Troli PPK!!!')
				/*fzn.modifyChat(from, 'delete', {
            includeStarred: false
        }).catch(console.log)*/
			}
			
		
		//function leveling
                        if (!msg.key.fromMe && isGroup && isLevelingOn && isUser && !selfna  && !isGained(sender)) {
                                const currentLevel = getLevelingLevel(sender)
                                const checkId = getLevelingId(sender)
                                try {
                                        addCooldown(sender)
                                        if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
                                        const amountXp = Math.floor(Math.random() * 10) + 150
                                        const requiredXp = 200 * (Math.pow(2, currentLevel) - 1)
                                        const getLevel = getLevelingLevel(sender)
                                        addLevelingXp(sender, amountXp)
                                        if (requiredXp <= getLevelingXp(sender)) {
                                        addLevelingLevel(sender, 1)
                                        await textImg(`*──「 LEVEL UP 」──*\n\n❑ *Name*: @${sender.split('@')[0]}\n❑ *XP*: ${getLevelingXp(sender)}\n❑ *Level*: ${getLevel} -> ${getLevelingLevel(sender)}\n❑ *Role*: ${role} \n\nCongrats!! 🎉`)
                                }
                        } catch (err) {
                                console.error(err)
                        }
                }
		// CMD
        if (isCmd && !isGroup) {
            addBalance(sender, randomNomor(20), balance)
			logna.info(`${warna.flag}${warna.bggreen}${warna.yellow}[CMD]${warna.off}|${warna.flag}${warna.bgmagenta}${warna.white} ${moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss')} ${warna.off}|${warna.flag}${warna.bgred}${warna.cyan} ${command} [${args.length}] ${warna.off}`)			
			//console.log(color('[CMD]', 'yellow'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`))
			//fzn.logger.info(`${command} [${args.length}]`)
		}
        if (isCmd && isGroup) {
            addBalance(sender, randomNomor(20), balance)
			logna.info(`${warna.flag}${warna.bggreen}${warna.yellow}[CMD]${warna.off}|${warna.flag}${warna.bgmagenta}${warna.white} ${moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss')} ${warna.off}|${warna.flag}${warna.bgred}${warna.cyan} ${command} [${args.length}] ${warna.off}|${warna.flag}${warna.bgwhite}${warna.red} From: ${pushname} ${warna.off}|${warna.flag}${warna.bgblue}${warna.white} In: ${groupName} ${warna.off}`)	
			//console.log(color('[CMD]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(groupName))
        }		
				
		//if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
     	//if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
		if(budy.toLowerCase() === 'bot'){
			SendbtnMSG('./src/fzn.jpg', prefix+statna, '⚙️ '+statna, prefix+'ping', '📶 Ping', prefix+'menu', '📂 Main Menu', `                       *𝐅𝐙𝐍-𝐁𝐎𝐓*\n\nHalo Kak ${pushname}\n\nSilahkan Klik Menu Di Bawah Ini Untuk Menampilkan List Fitur`, 'MODE: ' + fzn.modena)
		}
		
	fzn.on("CB:action,,battery", json => {
	  const battery  = json[2][0][1].value
	  const persenbat = parseInt(battery)
	  baterai.battery = `${persenbat}%`
	  baterai.isCharge = json[2][0][1].live
	  baterai.powersave = json[2][0][1].powersave
})

        batrenya = baterai.isCharge ? 'C H A R G I N G' : 'N O T  C H A R G I N G'
        casnya = baterai.powersave ? 'O N' : 'O F F'
		
		
		if (ownerNumber.includes(sender)){
            if (budy.startsWith("> ")){
                console.log(color('[EVAL]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner`))
                try {
                    let evaled = await eval(budy.slice(2))
                    //if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                    textImg(util.format(JSON.stringify(evaled,null,3)))
                } catch (err) {
                    textImg(`${err}`)
                }
            } else if (budy.startsWith("$ ")){
                console.log(color('[EXEC]'), color(moment(msg.messageTimestamp * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`Dari Owner`))
                exec(budy.slice(2), (err, stdout) => {
					if (err) return textImg(`${err}`)
					if (stdout) textImg(`${stdout}`)
				})
            }
        }
		
		
	switch(command){
		case 'menu':
case 'help':
if(budy){
try {
    var pic = await fzn.getProfilePicture(sender)
} catch {
    pic = 'https://trimelive.com/wp-content/uploads/2020/12/gambar-Wa-1.png'
   }	
const jumlahUser = pendaftar.length
const levelMenu = getLevelingLevel(sender)
const xpMenu = getLevelingXp(sender)  
const reqXp  = 200 * (Math.pow(2, getLevelingLevel(sender)) - 1)
const uangku = getBalance(sender, balance) 
const sendMenu = async(from) => {
const gblg = await fzn.prepareMessageMedia(await getBuffer(pic), image)
  var buttons = [{
    buttonId: prefix+'rules',
    buttonText: {
      displayText: '➡️ Rules'
    },
    type: 1
  },
  {
    buttonId: prefix+'menu',
    buttonText: {
      displayText: '➡️ Button Menu'
    },
    type: 1
  }]
  var buttonsMessage = {
	imageMessage: gblg.imageMessage,
    contentText: `「 *INFO USER* 」
❉──────────────────❉  
*Prefix* : 「MULTI」
*Nama* : ${pushname}
*Your API* : *https://wa.me/${sender.split('@')[0]}*
*Limit* : *${Limitnya}*
*Level: ${levelMenu}*
*XP: ${xpMenu} / ${reqXp}*
*Role: ${role}*
*Balance: ${uangku}*

*❏ Main Menu*
━━━━━━━━━━━━━━━━━━━━━━━━━━

*| ◪ ${prefix}menuowner* 
*| ◪ ${prefix}menustiker* 
*| ◪ ${prefix}menumedia* 
*| ◪ ${prefix}menudownloader* 
*| ◪ ${prefix}menuphotomaker* 
*| ◪ ${prefix}menutextmaker* 
*| ◪ ${prefix}menugame* 
*| ◪ ${prefix}menugrup* 
*| ◪ ${prefix}menuother*

❉──────────────────❉ 

「 *INFO BOT* 」

*Runtime* : ${cts}

*Hit Today* : ${hitna.hit.hitday}

*Total Hit* : ${hitna.hit.totalhit}
`,
    footerText: 'Made With By Fazone',
    buttons: buttons,
    headerType: 'IMAGE'
  }
  var sendMsg = await fzn.prepareMessageFromContent(from, {
    buttonsMessage
  }, {contextInfo: { 					
			forwardingScore: 99999,		
			isForwarded: true,
			externalAdReply: {
				title: `FZN-BOT`,
				body: `Version: 2.1.0\nMade By Fazone`,
				mediaType: 2,
				thumbnail: fs.readFileSync('./src/fzn.jpg'),
				sourceUrl: "https://fazone-api.herokuapp.com/"
			}
		},
                quoted: {
                    key: {
                        fromMe: false,
                        participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {})
                    },
                    message: {
                        "imageMessage": {
                            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
                            "mimetype": "image/jpeg",
                            "caption": 'Fazone',
                            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
                            "fileLength": "28777",
                            "height": 1080,
                            "width": 1079,
                            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
                            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
                            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
                            "mediaKeyTimestamp": "1610993486",
                            "jpegThumbnail": fs.readFileSync('./src/fzn.jpg'),
                            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
                        }
                    }
                }})
  fzn.relayWAMessage(sendMsg, {
    waitForAck: true
  })
}
sendMenu(from)
}else if(btnid) {
				
			var urutanmenu = []
			var cmdmain = ['menuowner', 'menustiker', 'menumedia', 'menudownloader', 'menuphotomaker', 'menutextmaker', 'menugame', 'menugrup', 'menuother']
			var menumain = ['Owner Menu', 'Stiker Menu', 'Media Menu', 'Downloader Menu', 'Photo Maker Menu', 'Text Maker Menu', 'Game Menu', 'Grup Menu', 'Other Menu']
			let ngetangmenu = 1
			let pilihanemenu = 0
			for(let judulne of cmdmain){
				const titelmain = menumain[pilihanemenu++]
				const gayanamenu = {
					title: `╭────────────── ${ngetangmenu++} ─────────────╮`,
					rows:[
						{
							title: titelmain,
							description: null,
							rowId: prefix + judulne		
						}
					]
				}
				urutanmenu.push(gayanamenu)
			}
			SendlistMSG(from, '*「 MAIN MENU 」*', 'Silahkan Klik Untuk Melihat List Menu :)', urutanmenu)
		}
 break
 case 'menuowner':
 if(budy){
menu = `*「 OWNER MENU 」*
*| ◪ ${prefix}runtime* 
*| ◪ ${prefix}ping* 
*| ◪ ${prefix}private* 
*| ◪ ${prefix}public*
*| ◪ ${prefix}clone [ tag ]*
*| ◪ ${prefix}leave*
*| ◪ ${prefix}addprem [ tag ]*
*| ◪ ${prefix}delprem [ tag ]*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
				
			var urutanowner = []
			var cmdowner = ['runtime', 'ping', 'private', 'public', 'clone', 'leave', 'addprem', 'delprem']
			var menuowner = ['Runtime Bot', 'Ping Device', 'Private Bot', 'Public Bot', 'Clone User', 'Leave Group', 'Add Premium User', 'Del Premium User']
			let ngetangowner = 1
			let pilihanowner = 0
			for(let judulowner of cmdowner){
				const titelowner = menuowner[pilihanowner++]
				const gayanaowner = {
					title: `╭────────────── ${ngetangowner++} ─────────────╮`,
					rows:[
						{
							title: titelowner,
							description: null,
							rowId: prefix + judulowner		
						}
					]
				}
				urutanowner.push(gayanaowner)
			}
			SendlistMSG(from, '*「 OWNER MENU 」*', 'Silahkan Klik Ini Khusus Owner Bot :)', urutanowner)
		}
 break
 case 'menustiker':
 if(budy){
menu = `*「 STIKER MENU 」*

*| ◪ ${prefix}sticker [ reply ]*
*| ◪ ${prefix}snobg [ reply ]*
*| ◪ ${prefix}scircle [ reply ]* 
*| ◪ ${prefix}sfirewm [ reply ]* 
*| ◪ ${prefix}trigger [ reply ]* 
*| ◪ ${prefix}wanted [ reply ]* 
*| ◪ ${prefix}wasted [ reply ]* 
*| ◪ ${prefix}rain [ reply ]*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
	 var urutanstiker = []
			var cmdstiker = ['sticker', 'snobg', 'scircle', 'sfirewm', 'trigger', 'wanted', 'wasted', 'rain']
			var menustiker = ['Sticker Maker', 'Sticker No Background', 'Sticker Circle', 'Sticker Fire', 'Sticker Trigger', 'Sticker Wanted', 'Sticker Wasted', 'Sticker Rain']
			let ngetangstiker = 1
			let pilihanstiker = 0
			for(let judulstiker of cmdstiker){
				const titelstiker = menustiker[pilihanstiker++]
				const gayanastiker = {
					title: `╭────────────── ${ngetangstiker++} ─────────────╮`,
					rows:[
						{
							title: titelstiker,
							description: null,
							rowId: prefix + judulstiker		
						}
					]
				}
				urutanstiker.push(gayanastiker)
			}
			SendlistMSG(from, '*「 STICKER MENU 」*', 'Silahkan Klik Ini Untuk Membuat Sticker :)', urutanstiker)
 }
 break
 case 'menumedia':
 if(budy){
menu = `*「 MEDIA MENU 」*

*| ◪ ${prefix}play [ query ]*
*| ◪ ${prefix}pinterest [ query ]*
*| ◪ ${prefix}image [ query ]*
*| ◪ ${prefix}ytsearch [ query ]*
*| ◪ ${prefix}sfile [ query ]*
*| ◪ ${prefix}ssweb [ link ]*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
	 var urutanmedia = []
			var cmdmedia = ['play', 'pinterest', 'image', 'ytsearch', 'sfile', 'ssweb']
			var menumedia = ['Play Music', 'Pinterest Image', 'Google Image', 'Youtube Search', 'Sfile Search', 'Screenshot Web']
			let ngetangmedia = 1
			let pilihanmedia = 0
			for(let judulmedia of cmdmedia){
				const titelmedia = menumedia[pilihanmedia++]
				const gayanamedia = {
					title: `╭────────────── ${ngetangmedia++} ─────────────╮`,
					rows:[
						{
							title: titelmedia,
							description: null,
							rowId: prefix + judulmedia		
						}
					]
				}
				urutanmedia.push(gayanamedia)
			}
			SendlistMSG(from, '*「 MEDIA MENU 」*', 'Silahkan Klik Ini Untuk Memilih Seputar Tentang Media :)', urutanmedia)
 }
 break  
 case 'menudownloader':
 if(budy){
menu = `*「 DOWNLOADER MENU 」*

*| ◪ ${prefix}ig [ link ]*
*| ◪ ${prefix}fb [ link ]*
*| ◪ ${prefix}tiktok [ link ]*
*| ◪ ${prefix}ytmp3 [ link ]*
*| ◪ ${prefix}ytmp4 [ link ]*
*| ◪ ${prefix}sfiledl [ link ]*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
  var urutandownloader = []
			var cmddownloader = ['ig', 'fb', 'tiktok', 'ytmp3', 'ytmp4', 'sfiledl']
			var menudownloader = ['Instagram Downloader', 'Facebook Downloader', 'Tiktok Downloader', 'Youtube MP3 Downloader', 'Youtube MP4 Downloader', 'Sfile Downloader']
			let ngetangdownloader = 1
			let pilihandownloader = 0
			for(let juduldownloader of cmddownloader){
				const titeldownloader = menudownloader[pilihandownloader++]
				const gayanadownloader = {
					title: `╭────────────── ${ngetangdownloader++} ─────────────╮`,
					rows:[
						{
							title: titeldownloader,
							description: null,
							rowId: prefix + juduldownloader		
						}
					]
				}
				urutandownloader.push(gayanadownloader)
			}
			SendlistMSG(from, '*「 DOWNLOADER MENU 」*', 'Silahkan Klik Ini Untuk Mendownload File :)', urutandownloader)
 }
 break 
 case 'menuphotomaker':
 if(budy){
menu = `*「 PHOTO MAKER MENU 」*

*| ◪ ${prefix}circle [ reply foto ]*
*| ◪ ${prefix}amazingtypo [ reply foto ]*
*| ◪ ${prefix}3dblock [ reply foto ]*
*| ◪ ${prefix}flameup [ reply foto ]*
*| ◪ ${prefix}rosepetals [ reply foto ]*
*| ◪ ${prefix}lovelyframe [ reply foto ]*
*| ◪ ${prefix}valentine [ reply foto ]*
*| ◪ ${prefix}pipframe [ reply foto ]*
*| ◪ ${prefix}violetframe [ reply foto ]*
*| ◪ ${prefix}brilliant [ reply foto ]*
*| ◪ ${prefix}beautiful [ reply foto ]*
*| ◪ ${prefix}mintframe [ reply foto ]*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
 var urutanefek = []
			var cmdefek = ['circle', 'amazingtypo', '3dblock', 'flameup', 'rosepetals', 'lovelyframe', 'valentine', 'pipframe', 'violetframe', 'brilliant', 'beautiful', 'mintframe']
			var menuefek = ['Circle Maker', 'Amazing Typo Maker', '3D Block Maker', 'Flame Up Maker', 'Rosepetals Maker', 'Lovely Frame Maker', 'Valentine Maker', 'Pip Frame Maker', 'Violet Frame Maker', 'Brilliant Maker', 'Beautiful Maker', 'Mint Frame Maker']		
			let ngetangefek = 1
			let pilihanefek = 0
			for(let judulefek of cmdefek){
				const titelefek = menuefek[pilihanefek++]
				const gayaefek = {
					title: `╭────────────── ${ngetangefek++} ─────────────╮`,
					rows:[
						{
							title: titelefek,
							description: null,
							rowId: prefix + judulefek		
						}
					]
				}
				urutanefek.push(gayaefek)
			}
			SendlistMSG(from, '*「 PHOTO MAKER MENU 」*', 'Silahkan Klik Untuk Melihat List Photo Maker Menu :)', urutanefek)
}
 break
 case 'menutextmaker':
 if(budy){
menu = `*「 TEXT MAKER MENU 」*

*| ◪ ${prefix}ephoto [ list ]*
*| ◪ ${prefix}photooxy [ list ]*
*| ◪ ${prefix}textpro [ list ]*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
	SendbtnMSG('./src/fzn.jpg', prefix+'ephoto', 'Ephoto Maker', prefix+'photooxy', 'Photo Oxy Maker', prefix+'textpro', 'Text Pro Maker', `*「 TEXT MAKER MENU 」*\nSilahkan Klik Tipe Untuk Membuat Text Maker :)`, 'FZN-BOT')
 }
 break 
 case 'menugame':
 if(budy){
menu = `*「 GAME MENU 」*

*| ◪ ${prefix}tebakgambar*
*| ◪ ${prefix}tebaklagu*
*| ◪ ${prefix}tebakkata*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
	SendbtnMSG('./src/fzn.jpg', prefix+'tebakgambar', 'Tebak Gambar', prefix+'tebaklagu', 'Tebak Lagu', prefix+'tebakkata', 'Tebak Kata', `*「 GAME MENU 」*\nSilahkan Klik Tipe Untuk Memainkan Gamenya :)`, 'FZN-BOT')
 }
 break 
 case 'menugrup':
 if(budy){
menu = `*「 GRUP MENU 」*

*| ◪ ${prefix}hidetag [ query ]*
*| ◪ ${prefix}kick [ reply/tag ]*
*| ◪ ${prefix}welcome [ on/off ]*
*| ◪ ${prefix}grup [ buka/tutup ]*
*| ◪ ${prefix}promote [ reply/tag ]*
*| ◪ ${prefix}demote [ reply/tag ]*
*| ◪ ${prefix}setname [ query ]*
*| ◪ ${prefix}setdesc [ query ]*
*| ◪ ${prefix}getsider [ reply ]*
*| ◪ ${prefix}listadmin*
*| ◪ ${prefix}linkgc*
`
Kirim.FakeStatus(from, menu, fakenya)
 }else if(idlistmsg){
	  var urutangrup = []
			var cmdgrup = ['grup', 'hidetag', 'kick', 'welcome', 'promote', 'demote', 'listadmin', 'setname', 'setdesc', 'getsider','linkgc']
			var menugrup = ['Grup Buka/Tutup', 'Kick User', 'Welcome on/off', 'Promote User', 'Demote User', 'List Admin', 'Set Name Group', 'Set Description Group', 'Get Sider','Link Group']
			let ngetanggrup = 1
			let pilihangrup = 0
			for(let judulgrup of cmdgrup){
				const titelgrup = menugrup[pilihangrup++]
				const gayanagrup = {
					title: `╭────────────── ${ngetanggrup++} ─────────────╮`,
					rows:[
						{
							title: titelgrup,
							description: null,
							rowId: prefix + judulgrup		
						}
					]
				}
				urutangrup.push(gayanagrup)
			}
			SendlistMSG(from, '*「 GRUP MENU 」*', 'Silahkan Klik Ini Untuk Menseting Grup :)', urutangrup)
 }
 break 
case 'menuother':
if(budy){
menu = `*「 OTHER MENU 」*

*| ◪ ${prefix}report [ query ]*
*| ◪ ${prefix}listprem*
*| ◪ ${prefix}cekprem*
*| ◪ ${prefix}buylimit [ amount ]*
*| ◪ ${prefix}claim*
*| ◪ ${prefix}jadibot*
*| ◪ ${prefix}listbot*
*| ◪ ${prefix}getcode*
*| ◪ ${prefix}stopjadibot*
`
Kirim.FakeStatus(from, menu, fakenya)
}else if(idlistmsg){
 var urutanother = []
			var cmdother = ['report', 'listprem', 'cekprem', 'buylimit', 'claim', 'jadibot', 'listbot', 'getcode', 'stopjadibot']
			var menuother = ['Report Bug', 'List Premium User', 'Cek Premium User', 'Buy Limit', 'Claim Day', 'Jadi Bot', 'List Bot', 'Get Code Bot', 'Stop Jadi Bot']
			let ngetangother = 1
			let pilihanother = 0
			for(let judulother of cmdother){
				const titelother = menuother[pilihanother++]
				const gayanaother = {
					title: `╭────────────── ${ngetangother++} ─────────────╮`,
					rows:[
						{
							title: titelother,
							description: null,
							rowId: prefix + judulother		
						}
					]
				}
				urutanother.push(gayanaother)
			}
			SendlistMSG(from, '*「 OTHER MENU 」*', 'Silahkan Klik Ini Untuk Melihat Menu Lainnya :)', urutanother)
}
 break
 
 //===========================STIKER MENU===============================//
 case 'stiker':
				case 'sticker':
				case 's':
					if(idlistmsg){
						txtna = `*「 STICKER MAKER 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat sticker`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
					if (isMedia && !msg.message.videoMessage || isQuotedImage){
					reply(warn.mess.wait)	
					const getbuff = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM','m')).message.extendedTextMessage.contextInfo : msg
					const dlfile = await fzn.downloadMediaMessage(getbuff)
					const bas64 = `data:image/jpeg;base64,${dlfile.toString('base64')}`
					Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'BOT'})
					} else if ((isMedia && msg.message.videoMessage.seconds < 11 || isQuotedVideo && msg.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11)){
					const getbuff = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM','m')).message.extendedTextMessage.contextInfo : msg
					const dlfile = await fzn.downloadMediaMessage(getbuff)
					const bas64 = `data:video/mp4;base64,${dlfile.toString('base64')}`
					Kirim.VideoJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'BOT'})	 
					} else {
					reply(`Kirim gambar/video dengan caption ${prefix}sticker atau tag gambar/video yang sudah dikirim\nNote : Durasi video maximal 10 detik`)
					}
					}
				break
				case 'snobg':
					if(idlistmsg){
						txtna = `*「 STICKER NO BACKGROUND 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat stickernobg`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					} else {
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fzn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/removebg?apikey=${fznkey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fzn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
							fs.unlinkSync(file_fzn)
                            gas = new Buffer.from(body, 'binary')
							bas64 = `data:image/jpeg;base64,${gas.toString('base64')}`
							Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'BOT'})
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}		
                break
				case 'scircle':
					if(idlistmsg){
						txtna = `*「 STICKER CIRCLE 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat stiker bulat`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
						limitAdd(sender, limit)
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fzn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/circle?apikey=${fznkey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fzn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
							fs.unlinkSync(file_fzn)
                            gas = new Buffer.from(body, 'binary')
							bas64 = `data:image/jpeg;base64,${gas.toString('base64')}`
							Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'BOT'})
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                break					
		case 'sfirewm': //By Fazone
					if(idlistmsg){
						txtna = `*「 STICKER FIRE 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat stiker fire`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
						limitAdd(sender, limit)
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fzn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/photofunia/burningfire?apikey=${fznkey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fzn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
                           fs.unlinkSync(file_fzn)
                            gas = new Buffer.from(body, 'binary')
							bas64 = `data:image/jpeg;base64,${gas.toString('base64')}`
							Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'BOT'})
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                    break
					case 'trigger': //By Fazone
				case 'triggered':
				if(idlistmsg){
						txtna = `*「 STICKER TRIGGER 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat stiker trigger`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fznn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/trigerv2?apikey=${apikey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fznn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
                            gas = fs.writeFileSync('trigerB.gif',body,'binary')
							ffmpeg('trigerB.gif')
                             .outputOptions(["-y", "-vcodec libwebp", "-lossless 1", "-qscale 1", "-preset default", "-loop 0", "-an", "-vsync 0", "-s 600x600"])
                             .videoFilters('scale=600:600:flags=lanczos:force_original_aspect_ratio=decrease,format=rgba,pad=600:600:(ow-iw)/2:(oh-ih)/2:color=#00000000,setsar=1')
                             .save('trigerA.webp')
            .                on('end', async () => {
                              fzn.sendMessage(from, fs.readFileSync('trigerA.webp'), sticker, {quoted: msg})
                              });
                        });
                    } else if ((isMedia && !msg.message.videoMessage || isQuotedSticker)) {
                        const encmedia = isQuotedSticker ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fznn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/trigerv2?apikey=${apikey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fznn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
                            gas = fs.writeFileSync('trigerB.gif',body,'binary')
							ffmpeg('trigerB.gif')
                             .outputOptions(["-y", "-vcodec libwebp", "-lossless 1", "-qscale 1", "-preset default", "-loop 0", "-an", "-vsync 0", "-s 600x600"])
                             .videoFilters('scale=600:600:flags=lanczos:force_original_aspect_ratio=decrease,format=rgba,pad=600:600:(ow-iw)/2:(oh-ih)/2:color=#00000000,setsar=1')
                             .save('trigerA.webp')
            .                on('end', async () => {
                              fzn.sendMessage(from, fs.readFileSync('trigerA.webp'), sticker, {quoted: msg})
                              });
                        });
                    } else {
                        reply(`Kirim gambar/stiker dengan caption ${prefix + command} atau tag gambar/stiker yang sudah dikirim`)
                    }
					}
                    break
					case 'wntd': //By Fazone
				case 'wanted':
					if(idlistmsg){
						txtna = `*「 STICKER WANTED 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat sticker wanted`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
						limitAdd(sender, limit)
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fznn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/wantedv2?apikey=${apikey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fznn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
                            fs.unlinkSync(file_fzn)
                            gas = new Buffer.from(body, 'binary')
							bas64 = `data:image/jpeg;base64,${gas.toString('base64')}`
							Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'SELF'})
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                    break
				case 'wstd': //By Fazone
				case 'wasted':
					if(idlistmsg){
						txtna = `*「 STICKER WASTED 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat sticker wasted`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
						limitAdd(sender, limit)
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fznn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/wastedv2?apikey=${apikey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fznn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
                            fs.unlinkSync(file_fzn)
                            gas = new Buffer.from(body, 'binary')
							bas64 = `data:image/jpeg;base64,${gas.toString('base64')}`
							Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'SELF'})
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                    break
					case 'rain': //By Fazone
					if(idlistmsg){
						txtna = `*「 STICKER RAIN 」*\nSilahkan Balas pesan ini lalu masukan foto/video untuk membuat sticker rain`
						fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'STICKERNA '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
						limitAdd(sender, limit)
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fzn = await fzn.downloadAndSaveMediaMessage(encmedia);
                        request({
							url: `https://fazone-api.herokuapp.com/api/rain?apikey=${apikey}`,
							method: 'POST',
							formData: {
								"img": fs.createReadStream(file_fzn),
							},
                            encoding: "binary"
                        }, async function(error, response, body) {
                            fs.unlinkSync(file_fzn)
                            gas = new Buffer.from(body, 'binary')
							bas64 = `data:image/jpeg;base64,${gas.toString('base64')}`
							Kirim.GambarJadiStiker(from, bas64, msg, {author: 'Fazone', pack: 'SELF'})
                        });
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                    break	
//====================================END==========================//
 
			case 'runtime':
				Kirim.FakeGroup(from, cts, fakenya)
            break
			case 'readme':
			case 'rules':
				baca = `
*RULES BAGI PENGGUNA T-BOT*
    
➤ Tolong Gunakan Delay Jangan Spam Saat Menggunakan Bot, Mentang Mentang Gratis Diborong semua.
➤ Call/VC Bot Auto Block.
➤ Jangan Call/VC Bot Kalau Tidak aktif.
➤ Bot tidak aktif 24 jam, jadi tergantung kalau ownernya lagi ada waktu botnya juga on.

*Konsekuensi Bila Melanggar Rules*
Bot Akan Memblokir Kamu Atau Keluar Dari Grup Yang Kamu Kelola.
━━━━━━━[ *PENTING!* ]━━━━━━━━
*➤ Kami tidak pernah meminta anda untuk* berdonasi! ingin donasi chat owner
*➤ Kami tidak menyimpan gambar, video,  audio, dan dokumen yang anda kirim*
*➤ Kami tidak akan pernah meminta anda untukmemberikan informasi pribadi*
*➤ Jika menemukan Bug/Error silahkan langsung lapor ke Owner bot*
*➤  Jika kamu menelpon bot Dan di block,Owner Tidak Bertanggung Jawab*
*➤ Apapun yang anda perintah pada bot ini , KAMI TIDAK AKAN BERTANGGUNG JAWAB*
━━━━━━━━━━━━━━━━━━━━━━━━`
				Kirim.FakeGroup(from, baca, fakenya)
            break
			case 'ping':
				const timestamp = speed();
                const latensi = speed() - timestamp 
                child =` \`\`\`Loaded Message\`\`\`             
\`\`\` - [ ${fzn.user.phone.device_manufacturer} ] HANDPHONE\`\`\`
\`\`\` - [ ${fzn.user.phone.wa_version} ] WA Version\`\`\`
\`\`\` - [ Baterai ]  ${baterai.battery} ${batrenya}\`\`\`
\`\`\` - [ Powersave ] ${casnya}\`\`\`
\`\`\` - [ Baileys ] Server\`\`\`
\`\`\` - [ ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB ] RAM\`\`\`
\`\`\`Speed : ${latensi.toFixed(4)} Second\`\`\``
				//console.log(child)
				Kirim.FakeGroup(from, child, fakenya)
            break   
			case 'private':
			if (!isOwner || !msg.key.fromMe) return reply(warn.mess.OnlyOwner)
			if(selfna) return Kirim.FakeStatus(from, 'Ini Sudah Private :v', fakenya) 
				selfna = true
				Kirim.FakeStatus(from, 'Mode Private Aktif!!!', fakenya) 
			break
			case 'public':
			if (!isOwner || !msg.key.fromMe) return reply(warn.mess.OnlyOwner)
			if(!selfna) return Kirim.FakeStatus(from, 'Ini Sudah Public :v', fakenya) 
				selfna = false
				Kirim.FakeStatus(from, 'Mode Public Aktif!!!', fakenya) 
			break
//========================== SYSTEM SESSION ============================//
		case 'stopjadibot':{
				if (!isPremium) return reply(warn.mess.OnlyPrem)
                if (global.fzn.user.jid == fzn.user.jid) fzn.reply(from, 'Kenapa nggk langsung ke terminalnya?', msg)
                else {
                    await fzn.reply(from, 'Bye...', msg).then(() => fzn.close())
                }
            }
                break
		case 'listbot':{
				if (!isPremium) return reply(warn.mess.OnlyPrem)
                let arrayBot = [];
                let tmx = `*List FZN-BOT*\n\n`
                tmx += `=> Nomor : @${global.fzn.user.jid.split("@")[0]}\n`
                arrayBot.push(global.fzn.user.jid)
                for (let i of conns){
                    tmx += `=> Nomor : @${i.user.jid.split("@")[0]}\n`
                    arrayBot.push(i.user.jid)
                }
                tmx += `Total : ${conns.length + 1}`
                mentions(tmx, arrayBot, true)
            }
                break
			case 'getcode':{
                if (global.fzn.user.jid == fzn.user.jid) fzn.reply(from, 'Command ini hanya untuk yang jadi bot', msg)
                else global.fzn.reply(fzn.user.jid, `${prefix}jadibot ${Buffer.from(JSON.stringify(fzn.base64EncodedAuthInfo())).toString('base64')}`, msg)
            }
                break
			case 'jadibot':{
				if(msg.key.fromMe) return
				if (!isPremium) return reply(warn.mess.OnlyPrem)
			let parent = args[0] && args[0] == 'plz' ? fzn : global.fzn
  let auth = false
  if ((args[0] && args[0] == 'plz') || global.fzn.user.jid == fzn.user.jid) {
    let id = global.conns.length
    let conn = new global.fzn.constructor()
    if (args[0] && args[0].length > 200) {
      let json = Buffer.from(args[0], 'base64').toString('utf-8')
      // global.conn.reply(m.isGroup ? m.sender : m.chat, json, m)
      let obj = JSON.parse(json)
      await conn.loadAuthInfo(obj)
      auth = true
    }
    conn.on('qr', async qr => {
	const qrdata =  await qrcode.toDataURL(qr, { scale: 8 })
   const bufferqr = new Buffer.from(qrdata.replace('data:image/png;base64,', ''), 'base64')
      let scan = await parent.sendMessage(from, bufferqr, image, {caption: 'Scan QR ini untuk jadi bot sementara\n\n1. Klik titik tiga di pojok kanan atas\n2. Ketuk WhatsApp Web\n3. Scan QR ini \nQR Expired dalam 20 detik', quoted: msg})
      setTimeout(() => {
        parent.deleteMessage(from, scan.key)
      }, 30000)
    })
    conn.regenerateQRIntervalMs = null
    conn.connect().then(async ({ user }) => {
      parent.sendMessage(from, 'Berhasil tersambung dengan WhatsApp - mu.\n*NOTE: Ini cuma numpang*\n' + JSON.stringify(user, null, 2), text, {quoted: msg})
      if (auth) return
      await parent.sendMessage(user.jid, `Kamu bisa login tanpa qr dengan pesan dibawah ini. untuk mendapatkan kode lengkapnya, silahkan kirim *${prefix}getcode* untuk mendapatkan kode yang akurat`, MessageType.extendedText)
      parent.sendMessage(user.jid, `${prefix + command} ${Buffer.from(JSON.stringify(conn.base64EncodedAuthInfo())).toString('base64')}`, MessageType.extendedText)
    })
	conn.on('chat-update', async (message) => {  
        //let _0xb6ddd3 = serialize(conn, message);
        module.exports(conn, message);
    })
    setTimeout(() => {
      if (conn.user) return
      conn.close()
      let i = global.conns.indexOf(conn)
      if (i < 0) return
      delete global.conns[i]
      global.conns.splice(i, 1)
    }, 60000)
    conn.on('close', () => {
      setTimeout(async () => {
        try {
          if (conn.state != 'close') return
          if (conn.user && conn.user.jid)
            parent.sendMessage(conn.user.jid, `Koneksi terputus...`, MessageType.extendedText)
          let i = global.conns.indexOf(conn)
          if (i < 0) return
          delete global.conns[i]
          global.conns.splice(i, 1)
        } catch (e) { conn.logger.error(e) }
      }, 30000)
    })
    global.conns.push(conn)
  } else reply('Tidak bisa membuat bot didalam bot!\n\nhttps://wa.me/' + global.conn.user.jid.split`@`[0] + '?text=.jadibot')
			}
  break
			//================================== MENU GRUP ==================================///
			case 'welcome':
			case 'welkom':
				if (!isGroup) return reply(warn.mess.OnlyGrup)
                if (!isGroupAdmins) return reply(warn.mess.GrupAdmin)
				if(idlistmsg === prefix+'welcome'){
					//if(!)
						let po = fzn.prepareMessageFromContent(from, {
					"listMessage":{
                  "title": "*OPSI WELCOME*",
                  "description": "pilh on/off",
                  "buttonText": "Klik Disini",
                  "listType": "SINGLE_SELECT",
                  "sections": [
                     {
                        "rows": [
                           {
                              "title": "buka",
                              "rowId": `${prefix}${command} on`
                           },
						   {
                              "title": "tutup",
                              "rowId": `${prefix}${command} off`
                           }
                        ]
                     }]}}, {}) 
            fzn.relayWAMessage(po, {waitForAck: true})
				}else{
                if (!q) return reply(`Pilih on atau off`)
                if (args[0].toLowerCase() === 'on'){
                    if (isWelcome) return reply(`Udah aktif`)
                    global.welkom.push(from)
					fs.writeFileSync('./database/welcome.json', JSON.stringify(global.welkom))
					reply('Welcome aktif')
                } else if (args[0].toLowerCase() === 'off'){
                    let anu = global.welkom.indexOf(from)
                    global.welkom.splice(anu, 1)
                    fs.writeFileSync('./database/welcome.json', JSON.stringify(global.welkom))
                    reply('Welcome nonaktif')
                } else {
                    reply(`Pilih on atau off`)
                }
				}
                break
			case 'grup':
			case 'group':
                if (!isGroup) return reply(warn.mess.OnlyGrup)
                if (!isGroupAdmins) return reply(warn.mess.GrupAdmin)
				if(idlistmsg === prefix+'grup'){
					//if(!)
						let po = fzn.prepareMessageFromContent(from, {
					"listMessage":{
                  "title": "*OPSI GRUP*",
                  "description": "pilh buka/tutup",
                  "buttonText": "Klik Disini",
                  "listType": "SINGLE_SELECT",
                  "sections": [
                     {
                        "rows": [
                           {
                              "title": "buka",
                              "rowId": `${prefix}${command} buka`
                           },
						   {
                              "title": "tutup",
                              "rowId": `${prefix}${command} tutup`
                           }
                        ]
                     }]}}, {}) 
            fzn.relayWAMessage(po, {waitForAck: true})	
				}else{
                if (!q) return reply(`Pilih buka atau tutup`)
                if (args[0].toLowerCase() === 'buka'){
                   reply('Berhasil membuka group, sekarang semua member bisa mengirim pesan')
					fzn.groupSettingChange(from, GroupSettingChange.messageSend, false)
                } else if (args[0].toLowerCase() === 'tutup'){
                    reply('Berhasil menutup group, hanya admin yang dapat mengirim pesan')
					fzn.groupSettingChange(from, GroupSettingChange.messageSend, true)
                } else {
                    reply(`Pilih buka atau tutup`)
                }
				}
                break
			case 'hidetag':
					if(!isGroup) return reply(warn.mess.OnlyGrup)
					if (!isGroupAdmins) return reply(warn.mess.GrupAdmin)	
					if(idlistmsg){
					txtna = `*「 HIDETAG GROUP 」*\nSilahkan Balas pesan ini lalu masukan teksnya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
					var value = q
					var group = await fzn.groupMetadata(from)
					var member = group['participants']
					var mem = []
					member.map( async adm => {
					mem.push(adm.id.replace('c.us', 's.whatsapp.net'))
					})
					var options = {
					text: value,
					contextInfo: { mentionedJid: mem },
					quoted: msg
					}
					fzn.sendMessage(from, options, text)
				}
			break		
		case 'clone':
				if(budy){
				try{
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Clone!!!')
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid[0]
				namanya = fzn.contacts[mentag] != undefined ? fzn.contacts[mentag].vname || fzn.contacts[mentag].notify : undefined			
				resultpp = await fzn.getProfilePicture(mentag)
				bufferna = await getBuffer(resultpp)
				fzn.updateProfilePicture(fzn.user.jid, bufferna)	
				fzn.updateProfileName(namanya)	
				reply(`Done\nTelah Mengclone user @${mentag.split('@')[0]}`)
				} catch {
				 reply('ppnya gak ada kak!!!')
				}
			}else if(idlistmsg){
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				txtna = `*「 CLONE USER 」*\nSilahkan Balas pesan ini lalu tag user yang ingin menjadi premium`
				fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
				}
			break
			case 'kick':
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins)return reply(warn.mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				if(idlistmsg){
					txtna = `*「 KICK USER 」*\nSilahkan Balas pesan ini lalu tag user yang ingin anda kick`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
				}else{
				if (fazone.reply_message !== false) {
				if(fazone.reply_message.data.participant === ownerNumber) return reply(`Njirrr Masa Bosku Di Kick :(`)	
				reply(warn.mess.wait)	
				setTimeout( () => {
			        fzn.sendMessage(from, `Berhasil Telah Mengeluarkan @${fazone.reply_message.data.participant.split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [fazone.reply_message.data.participant]}})
		        }, 4000)
				setTimeout( () => {
			        fzn.groupRemove(from, [fazone.reply_message.data.participant]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
				}else if(fazone.reply_message === false && fazone.mention !== false){
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Kick')
				reply(warn.mess.wait)	
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid
				if(mentag.includes(ownerNumber)) return reply(`Njirrr Masa Bosku Di Kick :(`)	
					if (mentag.length > 1) {
						teks = 'Berhasil Telah Mengeluarkan :\n'
						for (let _ of mentag) {
							teks += `@${_.split('@')[0]}\n`
						}
						setTimeout( () => {
						mentions(teks, mentag, true)
						}, 4000)
						setTimeout( () => {
			        fzn.groupRemove(from, mentag).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					} else {
						setTimeout( () => {
							fzn.sendMessage(from, `Berhasil Telah Mengeluarkan @${mentag[0].split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [mentag]}})
						}, 4000)
						setTimeout( () => {
			        fzn.groupRemove(from, [mentag[0]]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					}
				}else{
					reply('Format Salah!!!, Pastikan tag/reply untuk mengkick!!!')
				}
				}
			break
			case 'promote':	
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins)return reply(warn.mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				if(idlistmsg){
					txtna = `*「 PROMOTE USER 」*\nSilahkan Balas pesan ini lalu tag user yang ingin anda promote`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
				}else{	
				if (fazone.reply_message !== false) {	
				reply(warn.mess.wait)	
				setTimeout( () => {
			        fzn.sendMessage(from, `Sakarang Kamu Jadi Admin @${fazone.reply_message.data.participant.split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [fazone.reply_message.data.participant]}})
		        }, 4000)
				setTimeout( () => {
			        fzn.groupMakeAdmin(from, [fazone.reply_message.data.participant]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
				}else if(fazone.reply_message === false && fazone.mention !== false){
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Kick')
				reply(warn.mess.wait)	
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentag.length > 1) {
						teks = 'Berhasil Menjadikan Admin :\n'
						for (let _ of mentag) {
							teks += `@${_.split('@')[0]}\n`
						}
						setTimeout( () => {
						mentions(teks, mentag, true)
						}, 4000)
						setTimeout( () => {
			        fzn.groupMakeAdmin(from, mentag).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					} else {
						setTimeout( () => {
							fzn.sendMessage(from, `Sakarang Kamu Jadi Admin @${mentag[0].split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [mentag]}})
						}, 4000)
						setTimeout( () => {
			        fzn.groupMakeAdmin(from, [mentag[0]]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					}
				}else{
					reply('Format Salah!!!, Pastikan tag/reply untuk mengkick!!!')
				}
				}
			break
			case 'demote':	
				if(!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins)return reply(warn.mess.GrupAdmin)
                if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				if(idlistmsg){
					txtna = `*「 DEMOTE USER 」*\nSilahkan Balas pesan ini lalu tag user yang ingin anda demote`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
				}else{	
				if (fazone.reply_message !== false) {	
				reply(warn.mess.wait)	
				setTimeout( () => {
			        fzn.sendMessage(from, `Sakarang Kamu Tidak Jadi Admin Lagi @${fazone.reply_message.data.participant.split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [fazone.reply_message.data.participant]}})
		        }, 4000)
				setTimeout( () => {
			        fzn.groupDemoteAdmin(from, [fazone.reply_message.data.participant]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
				}else if(fazone.reply_message === false && fazone.mention !== false){
				if (msg.message.extendedTextMessage === undefined || msg.message.extendedTextMessage === null) return reply('Tag Target Yang Ingin Di Kick')
				reply(warn.mess.wait)	
				mentag = msg.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentag.length > 1) {
						teks = 'Berhasil Un Admin :\n'
						for (let _ of mentag) {
							teks += `@${_.split('@')[0]}\n`
						}
						setTimeout( () => {
						mentions(teks, mentag, true)
						}, 4000)
						setTimeout( () => {
			        fzn.groupDemoteAdmin(from, mentag).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					} else {
						setTimeout( () => {
							fzn.sendMessage(from, `Sakarang Kamu Tidak Jadi Admin Lagi @${mentag[0].split('@')[0]}`, text, {quoted: msg, contextInfo: {mentionedJid: [mentag]}})
						}, 4000)
						setTimeout( () => {
			        fzn.groupDemoteAdmin(from, [mentag[0]]).catch((e)=>{return reply(`*BOT INI HARUS JADI ADMIN*`)})
		        }, 3000)
					}
				}else{
					reply('Format Salah!!!, Pastikan tag/reply untuk mengkick!!!')
				}
				}
			break
			case 'listadmins': 
			case 'listadmin':
					if (!isGroup) return reply(warn.mess.OnlyGrup)
					teks = `List admin of group *${groupMetadata.subject}*\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `${no.toString()}. @${admon.split('@')[0]}\n`
					}
					teks += `\nTotal : ${groupAdmins.length}`
					reply(teks)
					break
			  case 'linkgroup':
			  case 'linkgrup':
			  case 'linkgc':
				if (!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins) return reply(warn.mess.GrupAdmin)
				if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
				linkgc = await fzn.groupInviteCode(from)
				reply('https://chat.whatsapp.com/'+linkgc)
                    break
			 case 'leave':
				if (!isGroup) return reply(warn.mess.OnlyGrup)
				if (isOwner) {
					fzn.groupLeave(from)
				   } else {
					reply(warn.mess.OnlyOwner)
						  }
			break
			case 'sider': 
			case 'getsider':
				if(idlistmsg){
					txtna = `*「 GET SIDER 」*\nSilahkan Balas pesan ini untuk melihat info`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{	
				if(!fazone.reply_message) return reply('Reply pesan bot!')
			  if(!isGroup) return reply(warn.mess.OnlyGrup)
				try {
				infom = await fzn.messageInfo(from, msg.message.extendedTextMessage.contextInfo.stanzaId)
				tagg = []
				teks = `*• Dibaca oleh:*\n\n`
				for(let i of infom.reads){
				teks += '@' + i.jid.split('@')[0] + '\n'
				teks += `> ` + moment(`${i.t}` * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss') + '\n\n'
				tagg.push(i.jid)
				}
				teks += `*• Tersampaikan pada:*\n\n`
				for(let i of infom.deliveries){
				teks += '@' + i.jid.split('@')[0] + '\n'
				teks += `> ` + moment(`${i.t}` * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss') + '\n\n'
				tagg.push(i.jid)
				}
				mentions(teks, tagg, true)
				} catch (e) {
				  console.log(color(e))
					reply('Reply pesan bot!')
				}
				}
			break
			case 'setname':
				if(idlistmsg){
					txtna = `*「 SET NAME GROUP 」*\nSilahkan Balas pesan ini lalu ketik untuk ubah nama grup`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{	
				if (!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins) return reply(warn.mess.GrupAdmin)
				if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
                fzn.groupUpdateSubject(from, `${q}`)
                fzn.sendMessage(from, 'Succes, Ganti Nama Grup', text, {quoted: msg})
				}
					break
                case 'setdesc':
				if(idlistmsg){
					txtna = `*「 SET DESCRIPTIONS GRUP 」*\nSilahkan Balas pesan ini lalu ketik untuk ubah deskripsi grup`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{	
                if (!isGroup) return reply(warn.mess.OnlyGrup)
				if (!isGroupAdmins) return reply(warn.mess.GrupAdmin)
				if (!isBotGroupAdmins) return reply(warn.mess.BotAdmin)
                fzn.groupUpdateDescription(from, `${q}`)
                fzn.sendMessage(from, 'Succes, Ganti Deskripsi Grup', text, {quoted: msg})
				}
					break
			//================================END =======================//
			
//=================================admin owner================================//
			 case 'report':
					if(idlistmsg){
					txtna = `*「 REPORT 」*\nSilahkan Balas pesan ini lalu ketik bug/masalah`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{	
					if (q.length > 300) return fzn.sendMessage(from, 'Maaf Teks Terlalu Panjang, Maksimal 300 Teks', text, {quoted: msg})
                    teks1 = `*[REPORT]*\nNomor : @${sender.split("@s.whatsapp.net")[0]}\nPesan : ${pesan}`
                    fzn.sendMessage(`${ownerNumber}`, teks1, text, {quoted: msg, contextInfo: {mentionedJid: [sender]}})
                    reply('Masalah telah di laporkan ke owner Bot, laporan palsu/main2 tidak akan ditanggapi.')
					}
                    break
			case 'addpremium':
			case 'addprem':
				if(budy){
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				if(fazone.mention !== false){
				if (_prem.getPremiumExpired(fazone.mention[0], premium)) return reply('Sudah premium kak :v')    	
				_prem.addPremiumUser(fazone.mention[0], "30d" , premium)
				fzn.sendMessage(from, `*「 PREMIUM ADD 」*\n*Name* : ${fazone.tagname}\n*Expired* : 30 DAY\n*thank for order premium*`, text, {quoted: msg})
				}else{
					reply('Format Salah!!!, Pastikan tag untuk membuat premium user')
				}
			}else if(idlistmsg){
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				txtna = `*「 PREMIUM ADD 」*\nSilahkan Balas pesan ini lalu tag user yang ingin menjadi premium`
				fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
				}
			break
			case 'delpremium':
			case 'delprem':
				if(budy){
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				if(fazone.mention !== false){
				if(!_prem.getPremiumExpired(fazone.mention[0], premium)) return reply('Dia Bukan premium kak :v')    	
				premium.splice(_prem.getPremiumPosition(fazone.mention[0], premium), 1)
				fs.writeFileSync('./database/premium.json', JSON.stringify(premium))
				fzn.sendMessage(from, `*DONE BOS*`, text, {quoted: msg})
				}else{
					reply('Format Salah!!!, Pastikan tag untuk menghapus premium user')
				}
			}else if(idlistmsg){
				if(!isOwner) return reply(warn.mess.OnlyOwner)
				txtna = `*「 PREMIUM DEL 」*\nSilahkan Balas pesan ini lalu tag user yang ingin Menghapus premium`
				fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
				}
			break
			case 'cekpremium':
			case 'cekprem':
				if (isOwner) return reply(`*「 PREMIUM EXPIRED 」*\n\n➸ *Nama*: ${fazone.pushname}\n➸ *Masa Premium*: UNLIMITED`) 
				if (!isPremium) return reply('Maaf Anda Bukan User Premium Silahkan Order Owner!')
				const expnya = ms(_prem.getPremiumExpired(sender, premium) - Date.now())
				reply(`*「 PREMIUM EXPIRED 」*\n\n➸ *Nama*: ${fazone.pushname}\n➸ *Masa Premium*: ${expnya.days} Hari ${expnya.hours} Jam ${expnya.minutes} Menit`)
			break
			case 'listpremium':
			case 'listprem':
				if (!isPremium) return reply(warn.mess.OnlyPrem)
				let listPremi = '「 *PREMIUM USER LIST* 」\n\n'
				let nomorList = 0
				const deret = _prem.getAllPremiumUser(premium)
				const arrayPremi = []
				for (let i = 0; i < deret.length; i++) {
				  const cekExp = ms(_prem.getPremiumExpired(deret[i],premium) - Date.now())
				  arrayPremi.push(_prem.getAllPremiumUser(premium)[i])
				  nomorList++
				  listPremi += `*${nomorList}.* ` + '*' + GetName(_prem.getAllPremiumUser(premium)[i].split("@")[0] + '@s.whatsapp.net') + '*' + `\n➸ *Masa Premium*: ${cekExp.days} Hari ${cekExp.hours} Jam ${cekExp.minutes} Menit\n\n`
				}
				fzn.sendMessage(from, listPremi + '*Jumlah User Premium* : '+ premium.length, MessageType.text, {quoted: msg})
			break
//===============================User dll ====================================//
			case 'buylimit':
				if(idlistmsg){
					txtna = `*「 BUY LIMIT 」*\nSilahkan Balas pesan ini lalu ketik jumlah balance untuk membeli limit`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{	
                if (!q) return reply(`Kirim perintah *${prefix}buylimit* jumlah limit yang ingin dibeli\n\nHarga 1 limit = $25 balance`)
                if (args[0].includes('-')) return reply(`Jangan menggunakan -`)
                if (isNaN(args[0])) return reply(`Harus berupa angka`)
                let ane = Number(nebal(args[0]) * 25)
                if (getBalance(sender, balance) < ane) return reply(`Balance kamu tidak mencukupi untuk pembelian ini`)
                kurangBalance(sender, ane, balance)
                giveLimit(sender, nebal(args[0]), limit)
                reply(monospace(`Pembeliaan limit sebanyak ${args[0]} berhasil\n\nSisa Balance : $${getBalance(sender, balance)}\nSisa Limit : ${getLimit(sender, limitCount, limit)}/${limitCount}`))
				}
			   break
				 case 'claim':
                case 'klaim':
                    if (isClaimOn) return reply(`Kamu sudah melakukan claim sebelumnya, Harap claim lagi di esok hari.`)
                    addLevelingXp(sender, 10000)
                    let hadippp = randomNomor(1000)
                    addBalance(sender, hadippp, balance)
                    _claim.push(sender)
                    fs.writeFileSync('./database/claim.json', JSON.stringify(_claim))
                    reply(`
*── 「 CLAIM  」 ──*

Selamat kamu mendapatkan *10000Xp* dan *${hadippp}* balance
Dari claim harian`)
                    break
/****====================   MENU MEDIA        =====================****/
			case 'play':
					if(idlistmsg){
					txtna = `*「 PLAY MUSIC 」*\nSilahkan Balas pesan ini lalu ketik judul lagu`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(!q) return reply('Masukan Teksnya kak :v')
					req = await getJson(`https://fzn-guys.herokuapp.com/api/ytplay2?apikey=gege&judul=${q}`)
					thumb = req.image
					info = `*「 PLAY 」*\n\n➸ *Judul* : ${req.title}\n➸ *Durasi* : ${req.duration}\n➸ *Filesize* : ${req.size}\n➸ *Ext* : MP3\n\n_*Music Sedang Dikirim*_`
					hasil = req.result
					Kirim.FileDariUrl(from, thumb, msg, info)
					//Kirim.FileDariUrl(from, hasil, msg)
					fzn.sendMessage(from, {url: hasil}, audio,{mimetype: "audio/mp4", quoted: msg, contextInfo:{"externalAdReply": {
					  "title": req.title,
					  "body": "YouTube Play Music",
					  "mediaType": 2,
					  "thumbnailUrl": thumb,
					  "mediaUrl": hasil.split("url=")[1],
					  "thumbnail": fs.readFileSync("./src/fzn.jpg")
					}}})
					}
				break
				case 'pinterest':
				if(idlistmsg){
					txtna = `*「 PINTEREST 」*\nSilahkan Balas pesan ini lalu ketik query nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(!q) return reply('Masukan Teksnya kak :v')
					req = await getJson(`https://fazone-api.herokuapp.com/api/pinterest?apikey=${fznkey}&q=${q}`)
					info = `Ini kak :v`
					hasil = req.result
					rand = hasil[Math.floor(Math.random() * hasil.length)]
					Kirim.FileDariUrl(from, rand, msg, info)
				}
				break	
				case 'image':
				if(idlistmsg){
					txtna = `*「 GOOGLE IMAGE 」*\nSilahkan Balas pesan ini lalu ketik query nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(!q) return reply('Masukan Teksnya kak :v')
					req = await getJson(`https://fazone-api.herokuapp.com/api/googleimg?apikey=${fznkey}&q=${q}`)
					info = `Ini kak :v`
					hasil = req.result
					rand = hasil[Math.floor(Math.random() * hasil.length)]
					Kirim.FileDariUrl(from, rand, msg, info)
				}
				break
				case 'ytsearch':
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(budy){
					if(!q) return reply('Masukan Teksnya kak :v')
					anu = await getJson(`https://api.zeks.xyz/api/yts?q=${q}&apikey=${zekskey}`)
					teks = '*「 YOUTUBE SEARCH 」*'
for (let i of anu.result) {
teks += `Uploader : 
Nama Channel : ${i.uploader.username}
Url Channel : ${i.uploader.url}
Verified : ${i.uploader.verified}
Video :
Nama Video : ${i.video.title}
Url : ${i.video.url}
Durasi : ${i.video.duration}
Deskripsi : ${i.video.snippet}
Tanggal Upload : ${i.video.upload_date}
Views : ${i.video.views}\n\n𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝘀𝗲𝗮𝗿𝗰𝗵
`
}
					fzn.sendMessage(from, {url: 'https://i.ibb.co/XyS1DLw/cdfbdf66f07b.jpg'}, image, {quoted: msg, caption: teks.trim()})
					}else if(idlistmsg){
					txtna = `*「 YOUTUBE SEARCH 」*\nSilahkan Balas pesan ini lalu ketik query nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'PREMIUM '+randomfzn() })
					}
				break
				case 'sfile':	
				if(idlistmsg){
					txtna = `*「 SFILE SEARCH 」*\nSilahkan Balas pesan ini lalu ketik query nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if (!q) return reply('Teksnya mana kak?')
					respo = await getJson(`https://fazone-api.herokuapp.com/api/sfile?apikey=${fznkey}&search=${q}`)
            				result = respo.result
					let pilem = `*「 SFILE SEARCH 」*\n\n*Hasil Pencarian : ${q}*\n\n─────────────────`
					for (let i = 0; i < result.length; i++) {
						pilem += `\n\nTitle : *${result[i].title}*\nLink : *${result[i].link}*`
					}
					Kirim.FakeStatus(from, pilem, fakenya)
				}
				break	 
				case 'ssweb':
				if(idlistmsg){
					txtna = `*「 PINTEREST 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
				}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
				  if (!q) return reply('Urlnya mana kak?')
				  req = `https://fazone-api.herokuapp.com/api/ssweb?url=${q}&apikey=${fznkey}`
				  Kirim.FileDariUrl(from, req, msg, 'Ini kak :v')
				}
				break
/****====================   MENU PHOTOMAKER        =====================****/
				case 'circle':
				case 'amazingtypo':
				case '3dblock':
				case 'flameup':
				case 'lovelyframe':
				case 'rosepetals':
				case 'valentine':
				case 'pipframe':
				case 'violetframe':
				case 'brilliant':
				case 'beautiful':
				if(idlistmsg){
						captina = `*${titlelist}*\n\nBalas Pesan Ini Lalu Masukan Gambar Untuk Membuat Tampilan Seperti Ini`
						 var req = request({
							url: `https://fazone-api.herokuapp.com/api/${command}?apikey=${fznkey}`,
							method: 'POST',
                            encoding: "binary"
                        }, async function(error, response, body) {
                            gas = new Buffer.from(body, 'binary')
							fzn.sendMessage(from, gas, image, { quoted: msg, caption: captina, messageId: command+'STICKERNA '+randomfzn() })
                        });
						let form = req.form();
						form.append('img', fs.createReadStream('./src/fzn.jpg'), 'gas.png')
					}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fzn = await fzn.downloadMediaMessage(encmedia);
                        var req = request({
							url: `https://fazone-api.herokuapp.com/api/${command}?apikey=${fznkey}`,
							method: 'POST',
                            encoding: "binary"
                        }, async function(error, response, body) {
                            gas = new Buffer.from(body, 'binary')
							fzn.sendMessage(from, gas, MessageType.image, {quoted: msg, caption: 'Ini kak :v'})
                        });
						let form = req.form();
						form.append('img', file_fzn, { filename : 'gas.png' })
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                    break	
				case 'mintframe':
					if(idlistmsg){
						captina = `*${titlelist}*\n\nBalas Pesan Ini Lalu Masukan Gambar Untuk Membuat Tampilan Seperti Ini`
						let form = new FormData
						form.append('img', fs.createReadStream('./src/fzn.jpg'), 'gas.png')
						await axios(`https://fazone-api.herokuapp.com/api/photofunia/${command}?apikey=${fznkey}`, {
						method: "POST",
						headers:{
							"accept-encoding": "gzip, deflate, br",
							...form.getHeaders(),
							"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36"		
						},
						data: form,
						responseType: 'arraybuffer'
					})
					.then(async (gaya) => {
						fzn.sendMessage(from, gaya.data, image, { quoted: msg, caption: captina, messageId: command+'STICKERNA '+randomfzn() })
					})
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
                    if ((isMedia && !msg.message.videoMessage || isQuotedImage)) {
                        const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
                        file_fzn = await fzn.downloadMediaMessage(encmedia);
						let form = new FormData
						form.append('img', file_fzn, { filename : 'gas.png' })
						await axios(`https://fazone-api.herokuapp.com/api/photofunia/${command}?apikey=${fznkey}`, {
						method: "POST",
						headers:{
							"accept-encoding": "gzip, deflate, br",
							...form.getHeaders(),
							"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36"		
						},
						data: form,
						responseType: 'arraybuffer'
					})
					.then(async (gaya) => {
						fzn.sendMessage(from, gaya.data, MessageType.image, {quoted: msg, caption: 'Ini kak :v'})
					})
                    } else {
                        reply(`Kirim gambar dengan caption ${prefix + command} atau tag gambar yang sudah dikirim`)
                    }
					}
                    break	
/****====================   MENU TEXTMAKER        =====================****/
case 'photooxy':
			if(budy){	
				menus = `*「 PHOTOOXY 」*

${prefix}wolfmetal [ teks ]
${prefix}underwebmatrix [ teks ]
${prefix}multimaterial [ teks ]
${prefix}underwaterocean [ teks ]
${prefix}smoke [ teks ]
${prefix}typography [ teks ]
${prefix}wolflogogalaxy [ teks ]
${prefix}neonlight [ teks ]
${prefix}google [ teks ]
${prefix}rainbowshine [ teks ]
${prefix}camuflage [ teks ]
${prefix}3dglowing [ teks ]
${prefix}vintage [ teks ]
${prefix}candy [ teks ]
${prefix}gradientavatar [ teks ]
${prefix}glowingrainbow [ teks ]
${prefix}stars [ teks ]
${prefix}fur [ teks ]
${prefix}flaming [ teks ]
${prefix}crispchrome [ teks ]
${prefix}kueultah [ teks ]
${prefix}rainbowbg [ teks ]
${prefix}metalicglow [ teks ]
${prefix}striking3d [ teks ]
${prefix}watermelon [ teks ]
${prefix}harrypotter [ teks ]
${prefix}luxuryroyal [ teks ]
${prefix}gerbang [ teks ]
${prefix}woodblock [ teks ]
${prefix}smoketypography [ teks ]
${prefix}sweetcandy [ teks ]
${prefix}silk [ teks ]
${prefix}bevel [ teks ]
${prefix}partyneon [ teks ]
${prefix}greenleaves [ teks ]
${prefix}modernmetal [ teks ]
${prefix}lolcover [ teks ]
${prefix}warface [ teks ]
${prefix}pentakill [ teks ]
${prefix}aov [ teks ]
${prefix}avatarlol [ teks ]
${prefix}pokemon [ teks ]
${prefix}lolavatarglitch [ teks ]
${prefix}shinebannerlol [ teks ]
${prefix}mastery7lol [ teks ]
${prefix}dota2avatar [ teks ]
${prefix}lol [ teks ]
${prefix}crossfire [ teks ]
${prefix}glowpentakill [ teks ]
${prefix}warfacecover [ teks ]
${prefix}coveroverwatch [ teks ]
${prefix}lolcover2 [ teks ]
${prefix}scgo [ teks ]
${prefix}lolpentakill [ teks ]`

		Kirim.FakeGroup(from, menus, fakenya)
		} else if(btnid) {
				
			var urutan2 = []
			var cmdphotooxy = ['wolfmetal',	'underwebmatrix',	'multimaterial',	'underwaterocean',	'smoke',	'neonlight',	'rainbowshine',	'camuflage',	'3dglowing',	'vintage',	'candy',	'gradientavatar',	'glowingrainbow',	'stars',	'fur',	'flaming',	'crispchrome',	'kueultah',	'rainbowbg',	'metalicglow',	'striking3d',	'watermelon',	'harrypotter',	'luxuryroyal',	'gerbang',	'woodblock',	'smoketypography',	'sweetcandy',	'silk',	'bevel',	'partyneon',	'greenleaves',	'modernmetal',	'lolcover',	'warface',	'pentakill',	'aov',	'avatarlol',	'pokemon',	'lolavatarglitch',	'shinebannerlol',	'mastery7lol',	'dota2avatar',	'lol',	'crossfire',	'glowpentakill',	'warfacecover',	'coveroverwatch',	'lolcover2',	'scgo',	'lolpentakill']
			var menuphotooxy = ['Wolf Metal',	'Under Web Matrix',	'Multi Material',	'Under Water Ocean',	'Smoke Text',	'Neon Light',	'Rainbow Shine',	'Camu Flage',	'3D Glowing',	'Vintage Text',	'Candy Text',	'Gradient Avatar',	'Glowing Rainbow',	'Stars Text',	'Fur Text',	'Flaming Text',	'Crisp Chrome',	'Kue Ultah',	'Rainbow Bg',	'Metalic Glow',	'Striking 3D',	'Water Melon',	'Harry Potter',	'Luxury Royal',	'Gerbang',	'Wood Block',	'Smoke Typo Graphy',	'Sweet Candy',	'Silk Text',	'Bevel Text',	'Party Neon',	'Green Leaves',	'Modern Metal',	'Lol Cover',	'Warface Text',	'Penta Kill',	'Aov Text',	'Avatar Lol',	'Pokemon Text',	'Lol Avatar Glitch',	'Shine Banner Lol',	'Mastery 7 Lol',	'Dota2 Avatar',	'Lol Text',	'Cross Fire',	'Glow Penta Kill',	'Warface Cover',	'Cover Over Watch',	'Lol Cover 2',	'Scgo Text',	'Lol Penta Kill']
			let ngetang2 = 1
			let pilihane2 = 0
			for(let gege1 of cmdphotooxy){
				const titel1 = menuphotooxy[pilihane2++]
				const gayana1 = {
					title: `╭────────────── ${ngetang2++} ─────────────╮`,
					rows:[
						{
							title: titel1,
							description: null,
							rowId: prefix + gege1		
						}
					]
				}
				urutan2.push(gayana1)
			}
			SendlistMSG(from, '*PHOTOOXY TEXT MAKER*', 'Silahkan Pilih Sesuai Selera :)', urutan2)
		}
		break

			case 'wolfmetal':
			case 'underwebmatrix':
			case 'multimaterial':
			case 'underwaterocean':
			case 'smoke':
			case 'typography':
			case 'wolflogogalaxy':
			case 'neonlight':
			case 'google':
			case 'rainbowshine':
			case 'camuflage':
			case '3dglowing':
			case 'vintage':
			case 'candy':
			case 'gradientavatar':
			case 'glowingrainbow':
			case 'stars':
			case 'fur':
			case 'flaming':
			case 'crispchrome':
			case 'kueultah':
			case 'rainbowbg':
			case 'metalicglow':
			case 'striking3d':
			case 'watermelon':
			case 'harrypotter':
			case 'luxuryroyal':
			case 'gerbang':
			case 'woodblock':
			case 'smoketypography':
			case 'sweetcandy':
			case 'silk':
			case 'bevel':
			case 'partyneon':
			case 'greenleaves':
			case 'modernmetal':
			case 'lolcover':
			case 'warface':
			case 'pentakill':
			case 'aov':
			case 'avatarlol':
			case 'pokemon':
			case 'lolavatarglitch':
			case 'shinebannerlol':
			case 'mastery7lol':
			case 'dota2avatar':
			case 'lol':
			case 'crossfire':
			case 'glowpentakill':
			case 'warfacecover':
			case 'coveroverwatch':
			case 'lolcover2':
			case 'scgo':
			case 'lolpentakill':
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(budy){	
                    if (!q) return reply(`Example: ${prefix + command} Adul Alhy`)
					reply(warn.mess.wait)
                    getBuffer(`https://api.xteam.xyz/photooxy/${command}?text=${q}&APIKEY=${xteamkey}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v' })
                    })
					}else if(idlistmsg){
						captina = `*${titlelist} Maker*\n\nBalas Pesan Ini Lalu Masukan Teks Untuk Membuat Tema Seperti Ini`
						gambar = await getBuffer(`https://api.xteam.xyz/photooxy/${command}?text=Example&APIKEY=${xteamkey}`)
						fzn.sendMessage(from, gambar, image, { quoted: msg, caption: captina, messageId: command+'PHOTOOXY '+randomfzn() })
					}
					break

///====================================================================================================================================>				
		case 'ephoto':
			if(budy){	
				menus = `*「 EPHOTO 」*

${prefix}wetglass [teks ]
${prefix}multicolor3d [teks ]
${prefix}watercolor [teks ]
${prefix}luxurygold [teks ]
${prefix}galaxywallpaper [teks ]
${prefix}lighttext [teks ]
${prefix}beautifulflower [teks ]
${prefix}puppycute [teks ]
${prefix}royaltext [teks ]
${prefix}heartshaped [teks ]
${prefix}birthdaycake [teks ]
${prefix}galaxystyle [teks ]
${prefix}hologram3d [teks ]
${prefix}greenneon [teks ]
${prefix}glossychrome [teks ]
${prefix}greenbush [teks ]
${prefix}metallogo [teks ]
${prefix}noeltext [teks ]
${prefix}glittergold [teks ]
${prefix}textcake [teks ]
${prefix}starsnight [teks ]
${prefix}wooden3d [teks ]
${prefix}textbyname [teks ]
${prefix}writegalacy [teks ]
${prefix}galaxybat [teks ]
${prefix}snow3d [teks ]
${prefix}birthdayday [teks ]
${prefix}goldplaybutton [teks ]
${prefix}silverplaybutton [teks ]
${prefix}freefire [teks ]`

		Kirim.FakeGroup(from, menus, fakenya)
		} else if(btnid) {
				
			var urutan = []
			var cmdephoto = ['wetglass','multicolor3d','watercolor','luxurygold','galaxywallpaper','lighttext','beautifulflower','puppycute','royaltext','heartshaped','birthdaycake','galaxystyle','hologram3d','greenneon','glossychrome','greenbush','metallogo','noeltext','glittergold','textcake','starsnight','wooden3d','textbyname','writegalacy','galaxybat','snow3d','birthdayday','goldplaybutton','silverplaybutton','freefire']			
			var menuephoto = ['Wet Glass','Multi Color 3D','Water Color','Luxury Gold','Galaxy Wallpaper','Light Text','Beautiful Flower','Puppy Cute','Royal Text','Heart Shaped','Birthday Cake','Galaxy Style','Hologram 3D','Green Neon','Glossy Chrome','Green Bush','Metal Logo','Noel Text','Glitter Gold','Text Cake','Star Snight','Wooden 3D','Text By Name','Write Galacy','Galaxy Bat','Snow 3D','Birthday Day','Gold Play Button','Silver Play Button','Free Fire']
			let ngetang = 1
			let pilihane = 0
			for(let gege of cmdephoto){
				const titel = menuephoto[pilihane++]
				const gayana = {
					title: `╭────────────── ${ngetang++} ─────────────╮`,
					rows:[
						{
							title: titel,
							description: null,
							rowId: prefix + gege		
						}
					]
				}
				urutan.push(gayana)
			}
			SendlistMSG(from, '*EPHOTO TEXT MAKER*', 'Silahkan Pilih Sesuai Selera :)', urutan)
		}
		break
          case 'wetglass':
                case 'multicolor3d':
                case 'watercolor':
                case 'luxurygold':
                case 'galaxywallpaper':
                case 'lighttext':
                case 'beautifulflower':
                case 'puppycute':
                case 'royaltext':
                case 'heartshaped':
                case 'birthdaycake':
                case 'galaxystyle':
                case 'hologram3d':
                case 'greenneon':
                case 'glossychrome':
                case 'greenbush':
                case 'metallogo':
                case 'noeltext':
                case 'glittergold':
                case 'textcake':
                case 'starsnight':
                case 'wooden3d':
                case 'textbyname':
                case 'writegalacy':
                case 'galaxybat':
                case 'snow3d':
                case 'birthdayday':
                case 'goldplaybutton':
                case 'silverplaybutton':
                case 'freefire':
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(budy){	
                    if (!q) return reply(`Example: ${prefix + command} Adul Alhy`)
					reply(warn.mess.wait)
                    getBuffer(`https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${LolApi}&text=${q}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v' })
                    })
					}else if(idlistmsg){
						captina = `*${titlelist} Maker*\n\nBalas Pesan Ini Lalu Masukan Teks Untuk Membuat Tema Seperti Ini`
						gambar = await getBuffer(`https://api.lolhuman.xyz/api/ephoto1/${command}?apikey=${LolApi}&text=Example`)
						fzn.sendMessage(from, gambar, image, { quoted: msg, caption: captina, messageId: command+'TEXTMAKER '+randomfzn() })
					}
                    break
					/////////////XTEAM TEXTPRO //////////////////////////
		case 'textpro':
			if(budy){	
				menus = `*「 TEXTPRO 」*

${prefix}neon [ teks ]
${prefix}snowtext [ teks ]
${prefix}cloudtext [ teks ]
${prefix}3dluxury [ teks ]
${prefix}3dgradient [ teks ]
${prefix}blackpink [ teks ]
${prefix}realisticcloud [ teks ]
${prefix}cloudsky [ teks ]
${prefix}sandsummerbeach [ teks ]
${prefix}sandwriting [ teks ]
${prefix}sandengraved [ teks ]
${prefix}summerysandwriting [ teks ]
${prefix}balloontext [ teks ]
${prefix}3dglue [ teks ]
${prefix}balloontext [ teks ]
${prefix}metaldarkgold [ teks ]
${prefix}neongalaxy [ teks ]
${prefix}1917 [ teks ]
${prefix}minion3d [ teks ]
${prefix}holographic3d [ teks ]
${prefix}metalpurpledual [ teks ]
${prefix}deluxesilver [ teks ]
${prefix}glossybluemetal [ teks ]
${prefix}deluxegold [ teks ]
${prefix}glossycarbon [ teks ]
${prefix}fabric [ teks ]
${prefix}happnewyearfirework [ teks ]
${prefix}newyear3d [ teks ]
${prefix}neontext [ teks ]
${prefix}metaldarkgoldeffect [ teks ]
${prefix}helloweenfire [ teks ]
${prefix}bloodontheroastedglass [ teks ]
${prefix}xmas3d [ teks ]
${prefix}jokerlogo [ teks ]
${prefix}wicker [ teks ]
${prefix}naturalleaves [ teks ]
${prefix}fireworksparkle [ teks ]
${prefix}skeleton [ teks ]
${prefix}redfoilballon [ teks ]
${prefix}purplefoilballon [ teks ]
${prefix}pinkfoilballon [ teks ]
${prefix}greenfoilballon [ teks ]
${prefix}cyanfoilballon [ teks ]
${prefix}bluefoilballon [ teks ]
${prefix}goldfoilballon [ teks ]
${prefix}steel [ teks ]
${prefix}ultragloss [ teks ]
${prefix}denim [ teks ]
${prefix}decorategreen [ teks ]
${prefix}decoratepurple [ teks ]
${prefix}peridotstone [ teks ]
${prefix}rock [ teks ]
${prefix}lava [ teks ]
${prefix}yellowglass [ teks ]
${prefix}purpleglass [ teks ]
${prefix}orangeglass [ teks ]
${prefix}greeglass [ teks ]
${prefix}cyanglass [ teks ]
${prefix}blueglass [ teks ]
${prefix}redglass [ teks ]
${prefix}purpleshnyglass [ teks ]
${prefix}captainamerica [ teks ]
${prefix}robotr2d2 [ teks ]
${prefix}toxic [ teks ]
${prefix}rainbowequalizer [ teks ]
${prefix}pinksparklingjewelry [ teks ]
${prefix}bluesparklingjewelry [ teks ]
${prefix}greensparklingjewelry [ teks ]
${prefix}purplesparklingjewelry [ teks ]
${prefix}goldsparklingjewelry [ teks ]
${prefix}redsparklingjewelry [ teks ]
${prefix}cyansparklingjewelry [ teks ]
${prefix}purpleglass2 [ teks ]
${prefix}decorativeglass [ teks ]
${prefix}chocolatecake [ teks ]
${prefix}strawberry [ teks ]
${prefix}koifish [ teks ]
${prefix}bread [ teks ]
${prefix}matrixstyle [ teks ]
${prefix}hororrblood [ teks ]
${prefix}neonlight [ teks ]
${prefix}thunder [ teks ]
${prefix}3dbox [ teks ]
${prefix}neon4 [ teks ]
${prefix}roadwarning [ teks ]
${prefix}3dsteel [ teks ]
${prefix}bokeh [ teks ]
${prefix}greenneon [ teks ]
${prefix}advancedglow [ teks ]
${prefix}dropwater [ teks ]
${prefix}breakwall [ teks ]
${prefix}chrismastgift [ teks ]
${prefix}honey [ teks ]
${prefix}plasticbagdrug [ teks ]
${prefix}horrorgift [ teks ]
${prefix}marbleslabs [ teks ]
${prefix}marble [ teks ]
${prefix}icecold [ teks ]
${prefix}fruitjuice [ teks ]
${prefix}rustymetal [ teks ]
${prefix}abstragold [ teks ]
${prefix}biscuit [ teks ]
${prefix}bagel [ teks ]
${prefix}wood [ teks ]
${prefix}scifi [ teks ]
${prefix}metalrainbow [ teks ]
${prefix}purplegem [ teks ]
${prefix}shinymetal [ teks ]
${prefix}yellowjewelry [ teks ]
${prefix}silverjewelry [ teks ]
${prefix}redjewelry [ teks ]
${prefix}purplejewelry [ teks ]
${prefix}orangejewelry [ teks ]
${prefix}greenjewelry [ teks ]
${prefix}cyanjewelry [ teks ]
${prefix}bluejewelry [ teks ]
${prefix}hotmetal [ teks ]
${prefix}hexagolden [ teks ]
${prefix}blueglitter [ teks ]
${prefix}purpleglitter [ teks ]
${prefix}pinkglitter [ teks ]
${prefix}greenglitter [ teks ]
${prefix}silverglitter [ teks ]
${prefix}goldglitter [ teks ]
${prefix}bronzeglitter [ teks ]
${prefix}erodedmetal [ teks ]
${prefix}carbon [ teks ]
${prefix}pinkcandy [ teks ]
${prefix}bluemetal [ teks ]
${prefix}bluegem [ teks ]
${prefix}blackmetal [ teks ]
${prefix}3dlowingmetal [ teks ]
${prefix}3dchrome [ teks ]
`

		Kirim.FakeGroup(from, menus, fakenya)
		} else if(btnid) {
				
			var urutan3 = []
			var cmdtextpro = ["neon","snowtext","cloudtext","3dluxury","3dgradient","blackpink","realisticcloud","cloudsky","sandsummerbeach","sandwriting","sandengraved","summerysandwriting","balloontext","3dglue","balloontext","metaldarkgold","neongalaxy","1917","minion3d","holographic3d","metalpurpledual","deluxesilver","glossybluemetal","deluxegold","glossycarbon","fabric","happnewyearfirework","newyear3d","neontext","metaldarkgoldeffect","helloweenfire","bloodontheroastedglass","xmas3d","jokerlogo","wicker","naturalleaves","fireworksparkle","skeleton","redfoilballon","purplefoilballon","pinkfoilballon","greenfoilballon","cyanfoilballon","bluefoilballon","goldfoilballon","steel","ultragloss","denim","decorategreen","decoratepurple","peridotstone","rock","lava","yellowglass","purpleglass","orangeglass","greeglass","cyanglass","blueglass","redglass","purpleshnyglass","captainamerica","robotr2d2","toxic","rainbowequalizer","pinksparklingjewelry","bluesparklingjewelry","greensparklingjewelry","purplesparklingjewelry","goldsparklingjewelry","redsparklingjewelry","cyansparklingjewelry","purpleglass2","decorativeglass","chocolatecake","strawberry","koifish","bread","matrixstyle","hororrblood","neonlight","thunder","3dbox","neon4","roadwarning","3dsteel","bokeh","greenneon","advancedglow","dropwater","breakwall","chrismastgift","honey","plasticbagdrug","horrorgift","marbleslabs","marble","icecold","fruitjuice","rustymetal","abstragold","biscuit","bagel","wood","scifi","metalrainbow","purplegem","shinymetal","yellowjewelry","silverjewelry","redjewelry","purplejewelry","orangejewelry","greenjewelry","cyanjewelry","bluejewelry","hotmetal","hexagolden","blueglitter","purpleglitter","pinkglitter","greenglitter","silverglitter","goldglitter","bronzeglitter","erodedmetal","carbon","pinkcandy","bluemetal","bluegem","blackmetal","3dlowingmetal","3dchrome"]
			var menutextpro = ["Neon Light","Snow Text","Cloud Text","3D Luxury","3D Gadient","Blackpink Text","Realistic Cloud","Cloud Sky","Sand Summer Beach","Sand Writing","Sand Engraved","Summery Writing","Ballon Text","3D Glue","Space 3D","Metal Dark Gold","Neon Galaxy","1917 Text","Minion 3D","Holographic 3D","Metal Purple","Deluxe Silver","Blue Metal","Deluxe Gold","Glossy Carbon","Fabric Text","Happy New Year","New Year 3D","Neon Text","Dark Gold Effect","Helloween Fire","Blood Text","Xmas 3D","Joker Logo","Wicker Text","Natural Leaves","Firework Sparkle","Skeleton Text","Red Foil Ballon","Purple Foil Ballon","Pink Foil Ballon","Green Foil Ballon","Cyan Foil Ballon","Blue Foil Ballon","Gold Foil Ballon","Steel Text","Ultra Gloss","Denim Text","Decorate Green","Decorate Purple","Peridot Stone","Rock Text","Lava Text","Yellow Glass","Purple Glass","Orange Glass","Green Glass","Cyan Glass","Blue Glass","Red Glass","Purple Shiny Glass","Capatain America","Robot R2D2","Toxic Text","Rainbow Equalizier","Pink Sparkling Jewelry","Blue Sparkling Jewelry","Green Sparkling Jewelry","Purple Sparkling Jewelry","Gold Sparkling Jewelry","Red Sparkling Jewelry","Cyan Sparkling Jewelry","Purple Glass 2 ","Decorative Glass","Chocolate Cake","Strawberry Text","Koi Fish","Bread Text","Matrix Style","Horror Blood","Neon Light","Thunder","3D Box","Neon 2","Road Warning","3D Steel","Bokeh Text","Green Neon","Advanced Glow","Drop Water","Break Wall","Chrismast Gift","Honey Text","Plastic Bag Drug","Horror Gift","Marble Slabs","Marble Text","Ice Old Text","Fruit Juice","Rusty Metal","Abstra Gold","Biscuit Text","Bagel Text","Wood Text","SCI FI Text","Metal Rainbow","Purple Gem","Shiny Metal","Yellow Jewelry","Silver Jewelry","Red Jewelry","Purple Jewelry","Orange Jewelry","Green Jewelry","Cyan Jewelry","Blue Jewelry","Hot Metal","Hexa Golden","Blue Glitter","Purple Glitter","Pink Glitter","Green Glitter","Silver Glitter","Gold Glitter","Bronze Glitter","Eroded Metal","Carbon Text","Pink Candy","Blue Metal","Blue Gem","Black Metal","3D Lowing Metal","3D Chrome"]
			let ngetang3 = 1
			let pilihane3 = 0
			for(let gege3 of cmdtextpro){
				const titel1 = menutextpro[pilihane3++]
				const gayana1 = {
					title: `╭────────────── ${ngetang3++} ─────────────╮`,
					rows:[
						{
							title: titel1,
							description: null,
							rowId: prefix + gege3		
						}
					]
				}
				urutan3.push(gayana1)
			}
			SendlistMSG(from, '*TEXTPRO TEXT MAKER*', 'Silahkan Pilih Sesuai Selera :)', urutan3)
		}
		break

			case 'neon':
			case 'snowtext':
			case 'cloudtext':
			case '3dluxury':
			case '3dgradient':
			case 'blackpink':
			case 'realisticcloud':
			case 'cloudsky':
			case 'sandsummerbeach':
			case 'sandwriting':
			case 'sandengraved':
			case 'summerysandwriting':
			case 'balloontext':
			case '3dglue':
			case 'balloontext':
			case 'metaldarkgold':
			case 'neongalaxy':
			case '1917':
			case 'minion3d':
			case 'holographic3d':
			case 'metalpurpledual':
			case 'deluxesilver':
			case 'glossybluemetal':
			case 'deluxegold':
			case 'glossycarbon':
			case 'fabric':
			case 'happnewyearfirework':
			case 'newyear3d':
			case 'neontext':
			case 'metaldarkgoldeffect':
			case 'helloweenfire':
			case 'bloodontheroastedglass':
			case 'xmas3d':
			case 'jokerlogo':
			case 'wicker':
			case 'naturalleaves':
			case 'fireworksparkle':
			case 'skeleton':
			case 'redfoilballon':
			case 'purplefoilballon':
			case 'pinkfoilballon':
			case 'greenfoilballon':
			case 'cyanfoilballon':
			case 'bluefoilballon':
			case 'goldfoilballon':
			case 'steel':
			case 'ultragloss':
			case 'denim':
			case 'decorategreen':
			case 'decoratepurple':
			case 'peridotstone':
			case 'rock':
			case 'lava':
			case 'yellowglass':
			case 'purpleglass':
			case 'orangeglass':
			case 'greeglass':
			case 'cyanglass':
			case 'blueglass':
			case 'redglass':
			case 'purpleshnyglass':
			case 'captainamerica':
			case 'robotr2d2':
			case 'toxic':
			case 'rainbowequalizer':
			case 'pinksparklingjewelry':
			case 'bluesparklingjewelry':
			case 'greensparklingjewelry':
			case 'purplesparklingjewelry':
			case 'goldsparklingjewelry':
			case 'redsparklingjewelry':
			case 'cyansparklingjewelry':
			case 'purpleglass2':
			case 'decorativeglass':
			case 'chocolatecake':
			case 'strawberry':
			case 'koifish':
			case 'bread':
			case 'matrixstyle':
			case 'hororrblood':
			case 'neonlight':
			case 'thunder':
			case '3dbox':
			case 'neon4':
			case 'roadwarning':
			case '3dsteel':
			case 'bokeh':
			case 'greenneon':
			case 'advancedglow':
			case 'dropwater':
			case 'breakwall':
			case 'chrismastgift':
			case 'honey':
			case 'plasticbagdrug':
			case 'horrorgift':
			case 'marbleslabs':
			case 'marble':
			case 'icecold':
			case 'fruitjuice':
			case 'rustymetal':
			case 'abstragold':
			case 'biscuit':
			case 'bagel':
			case 'wood':
			case 'scifi':
			case 'metalrainbow':
			case 'purplegem':
			case 'shinymetal':
			case 'yellowjewelry':
			case 'silverjewelry':
			case 'redjewelry':
			case 'purplejewelry':
			case 'orangejewelry':
			case 'greenjewelry':
			case 'cyanjewelry':
			case 'bluejewelry':
			case 'hotmetal':
			case 'hexagolden':
			case 'blueglitter':
			case 'purpleglitter':
			case 'pinkglitter':
			case 'greenglitter':
			case 'silverglitter':
			case 'goldglitter':
			case 'bronzeglitter':
			case 'erodedmetal':
			case 'carbon':
			case 'pinkcandy':
			case 'bluemetal':
			case 'bluegem':
			case 'blackmetal':
			case '3dlowingmetal':
			case '3dchrome':
			if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if(budy){	
                    if (!q) return reply(`Example: ${prefix + command} Adul Alhy`)
					reply(warn.mess.wait)
                    getBuffer(`https://api.xteam.xyz/textpro/${command}?text=${q}&APIKEY=${xteamkey}`).then((gambar) => {
                        fzn.sendMessage(from, gambar, image, { quoted: msg, caption: 'Berhasil Kak :v' })
                    })
					}else if(idlistmsg){
						captina = `*${titlelist} Maker*\n\nBalas Pesan Ini Lalu Masukan Teks Untuk Membuat Tema Seperti Ini`
						gambar = await getBuffer(`https://api.xteam.xyz/textpro/${command}?text=Example&APIKEY=${xteamkey}`)
						fzn.sendMessage(from, gambar, image, { quoted: msg, caption: captina, messageId: command+'TEXTPRO '+randomfzn() })
					}
					break

///====================================================================================================================================>

	
/****====================   MENU DOWNLOADER        =====================****/	
				case 'fb':
					if(idlistmsg){
					txtna = `*「 FACEBOOK DOWNLOADER 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					try {
						if (!q) return reply('Urlnya mana kak?')
						req = await getJson(`https://lolhuman.herokuapp.com/api/facebook2?apikey=${lolkey}&url=${q}`)
						reply(warn.mess.wait)
						buffer = await getBuffer(req.result)
						fzn.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: msg, caption: 'Nih Kak :)'})
						} catch {
						reply('Mungkin Linknya Tidak Valid Kak :v')
						}
					}
				break		
				case 'ig':
				if(idlistmsg){
					txtna = `*「 INSTAGRAM DOWNLOADER 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
					if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					try {
						if (!q) return reply('Urlnya mana kak?')
						req = await getJson(`https://fzn-guys.herokuapp.com/api/igdl?apikey=gege&url=${q}`)
						cptr = `*INSTAGRAM DOWNLOADER*\n\n*➸ Nama :* ${req.result.fullname}\n*➸ User :* ${req.result.username}\n*➸ Caption :* ${req.result.caption}`
						if (req.error) return reply(req.error)
						fzn.sendMessage(from, warn.mess.wait, text, {quoted: msg})
						Kirim.FileDariUrl(from, req.result.url, msg, cptr)
						} catch {
						reply('Mungkin Linknya Tidak Valid Kak :v')
						}
					}
				break
				case 'tiktok':
				if(idlistmsg){
					txtna = `*「 TIKTOK DOWNLOADER 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					try {
						if (!q) return reply('Urlnya mana kak?')
						req = await ttdownloader(`${q}`)
						reply(warn.mess.wait)
						buffer = await getBuffer(req.nowm)
						fzn.sendMessage(from, buffer, video, {mimetype: 'video/mp4', quoted: msg, caption: 'Nih Kak :)'})
						} catch {
						reply('Mungkin Linknya Tidak Valid Kak :v')
						}
					}
				break
				case 'ytmp4':
				if(idlistmsg){
					txtna = `*「 YTMP4 DOWNLOADER 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if (!q) return reply('Urlnya mana kak?')
					reply(warn.mess.wait)	
					anu = await getJson(`https://api.lolhuman.xyz/api/ytvideo2?apikey=${lolkey}&url=${q}`)
					if (anu.error) return reply(anu.error)
					ytt = `「 *YOUTUBE MP4* 」
					
*Judul:* ${anu.result.judul}
*Size:* ${anu.result.size}
					 
 Tunggu Sebentar kak...`
					fzn.sendMessage(from, {url: anu.result.thumbnail}, image,{caption: ytt, quoted: msg})
					fzn.sendMessage(from, {url: anu.result.link}, video,{mimetype: 'video/mp4',caption: 'Nih Kak :v', quoted: msg})
					}
					break 
				case 'ytmp3':
				if(idlistmsg){
					txtna = `*「 YTMP3 DOWNLOADER 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
					if (!q) return reply('Urlnya mana kak?')
					reply(warn.mess.wait)
                    anu = await getJson(`http://fazone-app.tk/apine.php?link=${q}`)
                    ytt = `「 *YOUTUBE MP3* 」
					
*Judul:* ${anu.title}
*Size:* ${anu.size}
					 
 Tunggu Sebentar kak...`
					fzn.sendMessage(from, {url: anu.thumb}, image,{caption: ytt, quoted: msg})
					fzn.sendMessage(from, {url: anu.result}, audio,{mimetype: "audio/mp4", quoted: msg, contextInfo:{"externalAdReply": {
          "title": anu.title,
          "body": "YouTube MP3",
          "mediaType": 2,
          "thumbnailUrl": anu.thumb,
          "mediaUrl": args[0],
          "thumbnail": fs.readFileSync("./src/fzn.jpg")
        }}})
					}
				break
				case 'sfiledl':
				if(idlistmsg){
					txtna = `*「 YTMP4 DOWNLOADER 」*\nSilahkan Balas pesan ini lalu ketik link nya`
					fzn.sendMessage(from, txtna, text, { quoted: msg, messageId: command+'GRUP '+randomfzn() })
					}else{
				if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
				  if (!q) return reply('Urlnya mana kak?')
				  req = await getJson(`https://fazone-api.herokuapp.com/api/sfiledl?url=${q}&apikey=${fznkey}`)
				  titel = req.title
				  hasil = req.result
				  gas = await getBuffer(hasil)
				  fzn.sendMessage(from, gas, MessageType.document, {mimetype: 'application/octet-stream', filename: `${titel}`, quoted: msg})
					}
				break 
//=========--------------------MENU GAME----------------------===============//
			case 'tebakgambar':
			if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
		timeout = 120000
         jidnye = from
		  if (jidnye in fzn.tebakgambar) {
			return fazone.sendMessage('Masih ada soal belum terjawab di chat ini', MessageType.text, {quoted: fzn.tebakgambar[from][0]})
		  }
		  gas = await getJson('https://docs-api-zahirrr.herokuapp.com/api/quote?type=tebakgambar')
		  caption = `
*「 TEBAK GAMBAR 」*\n\nTimeout *${(timeout / 1000).toFixed(2)} detik*
Ketik ${prefix}hint untuk hint
    `.trim()
  fzn.tebakgambar[jidnye] = [
    await fzn.sendMessage(from, await getBuffer(gas.images), image, { quoted: msg, caption: caption }),
    gas,
    setTimeout(() => {
      if (fzn.tebakgambar[jidnye]) fazone.sendMessage(`Waktu habis!\nJawabannya adalah *${gas.jawaban}*`, MessageType.text, {quoted: fzn.tebakgambar[from][0]})
		//gambargame.splice(from, 1)
      delete fzn.tebakgambar[jidnye]
    }, timeout)
  ]
        break
	case 'hint':
		var jawab = fzn.tebakgambar[from][1]
		reply('```' + jawab.jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_') + '```')
        break
	case 'tebaklagu':
		if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
			limitAdd(sender, limit)	
		const getRandom = () => {
			return `${Math.floor(Math.random() * 10000)}`
		}
		//fzn.tebaklagu
		//gambargame.push(from)
		timeout = 120000
         jidnye = from
		  if (jidnye in fzn.tebaklagu) {
			return fazone.sendMessage('Masih ada soal belum terjawab di chat ini', MessageType.text, {quoted: fzn.tebaklagu[from][0]})
		  }
		  gas = await getJson('http://fazone-app.tk/tebaklagu.php')
		  if(gas.preview === null) return reply('Server Error Ulangi Lagi')
		  caption = `
*「 TEBAK LAGU 」*\n\nTimeout *${(timeout / 1000).toFixed(2)} detik*
Silahkan Reply Pesan ini/Audionya
Dengan Mengetik teks judul lagu
Ketik ${prefix}cek untuk bantuan
    `.trim()
  fzn.tebaklagu[jidnye] = [
    await fzn.sendMessage(from, caption, text, { quoted: msg }),
    gas,
    setTimeout(() => {
      if (fzn.tebaklagu[jidnye]) fazone.sendMessage(`Waktu habis!\nJawabannya adalah *${gas.judul}*`, MessageType.text, {quoted: fzn.tebaklagu[from][0]})
		//gambargame.splice(from, 1)
      delete fzn.tebaklagu[jidnye]
    }, timeout)
  ]
   fzn.sendMessage(from, await getBuffer(gas.preview), audio, {quoted: msg, mimetype: 'audio/mp4', messageId:'BYFAZONE' + randomfzn()})
        break
		case 'cek':
		json = fzn.tebaklagu[from][1]
		reply('```' + json.judul.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_') + '```')
        break
		case 'tebakkata':
		//fzn.tebakkata
		//gambargame.push(from)
		if (isLimit(sender, isPremium, isOwner, limitCount, limit)) return reply (`Limit kamu sudah habis silahkan ${prefix}buylimit untuk membeli limit/upgrade premium agar unlimited limit`)
					limitAdd(sender, limit)	
		timeout = 120000
         jidnye = from
		  if (jidnye in fzn.tebakkata) {
			return fazone.sendMessage('Masih ada soal belum terjawab di chat ini', MessageType.text, {quoted: fzn.tebakkata[from][0]})
		  }
		  gas = await getJson('http://fazone-app.tk/tebakkata.php')
		  teksna = `
*「 TEBAK KATA 」*\n\n
${gas.pertanyaan}

Silahkan Reply Pesan ini Dengan Mengetik jawabannya
Ketik ${prefix}teka untuk bantuan
    `.trim()
  fzn.tebakkata[jidnye] = [
    await fzn.sendMessage(from, teksna, text, { quoted: msg }),
    gas,
    setTimeout(() => {
      if (fzn.tebakkata[jidnye]) fazone.sendMessage(`Waktu habis!\nJawabannya adalah *${gas.jawaban}*`, MessageType.text, {quoted: fzn.tebakkata[from][0]})
		//gambargame.splice(from, 1)
      delete fzn.tebakkata[jidnye]
    }, timeout)
  ]
        break
		case 'teka':
		json = fzn.tebakkata[from][1]
		reply('```' + json.jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_') + '```')
        break
//========================	END GAME ====================================//
			
	}
		
	} catch (e) {
    e = String(e)
    if (!e.includes("this.isZero")) {
	console.log('Message : %s' + e)
        }
	// console.log(e)
	}
}

///Jika Edit Disini Maka Harus Restart Bot Ulang Secara Manual...
