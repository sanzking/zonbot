const { WAConnection, MessageType, Presence, MessageOptions, Mimetype, WALocationMessage, WA_MESSAGE_STUB_TYPES, ReconnectMode, ProxyAgent, GroupSettingChange, waChatKey, mentionedJid, processTime } = require("@adiwajshing/baileys")
const qrcode = require("qrcode-terminal")
const moment = require("moment-timezone")
const fs = require("fs")
const ms = require('parse-ms')
const toMs = require('ms')
const fetch = require('node-fetch')
const { color, bgcolor } = require('./lib/color')
const { help } = require('./lib/help')
const { donasi } = require('./lib/donasi')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const { wait, simih, getBuffer, uploadImages, kepo, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const tiktod = require('tiktok-scraper')
const igdl = require('instagram-scraping')
const ytdl = require('ytdownload')
const brainly = require('brainly-scraper')
const axios = require("axios")
const ffmpeg = require('fluent-ffmpeg')
const imageToBase64 = require('image-to-base64');
const base64ToImage = require('base64-to-image');
var base64Img = require('base64-img');
const { removeBackgroundFromImageFile } = require('remove.bg')
const kasar = JSON.parse(fs.readFileSync('./src/antibadword.json'))
const virus = JSON.parse(fs.readFileSync('./src/antivirus.json'))
const autostick = JSON.parse(fs.readFileSync('./src/autosticker.json'))
const kotor = JSON.parse(fs.readFileSync('./src/kasar.json'))
const _registered = JSON.parse(fs.readFileSync('./src/registered.json'))
const register = require('./functions/register')
const _leveling = JSON.parse(fs.readFileSync('./src/leveling.json'))
const _level = JSON.parse(fs.readFileSync('./src/level.json'))
const level = require('./functions/level')
const anlink = JSON.parse(fs.readFileSync('./src/antilink.json'))
const setting = JSON.parse(fs.readFileSync('./setting.json'))
const _premium = JSON.parse(fs.readFileSync('./src/premium.json'))
const _ban = JSON.parse(fs.readFileSync('./src/banned.json'))
const _bot = JSON.parse(fs.readFileSync('./src/bot.json'))
const _afk = JSON.parse(fs.readFileSync('./src/afk.json'))
const limit = require('./functions/limit')
let _limit = JSON.parse(fs.readFileSync('./src/limit.json'))
const premium = require('./functions/premium')
const afk = require('./functions/afk')
const welkom = JSON.parse(fs.readFileSync('./src/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./src/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./src/simi.json'))
const setiker = JSON.parse(fs.readFileSync('./src/stik.json'))
const videonye = JSON.parse(fs.readFileSync('./src/video.json'))
const audionye = JSON.parse(fs.readFileSync('./src/audio.json'))
const imagenye = JSON.parse(fs.readFileSync('./src/image.json'))
const Math_js = require('mathjs')
const speed = require('performance-now')
const speedTest = require('@lh2020/speedtest-net');
const { Utils_1 } = require('./node_modules/@adiwajshing/baileys/lib/WAConnection/Utils')
const time = moment().tz('Asia/Jakarta').format("HH:mm:ss")
const cron = require('node-cron')
const exect = require('await-exec')
const webp = require('webp-converter')
let int

prefix = '#' && 'z' && '$' && ''
fake = '*SELFBOT*'
numbernye = '0@s.whatsapp.net'
targetprivate = '0'
blocked = []            
banChats = true
banChat = false
setgrup = "6289636006352-1606097314@g.us"
alasanoff = 'Mengtidur'
monospace = '```'
totalhit = setting.totalhit++
setthumb = `/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kHjYqJiYqNj40MjQ+TERETF9aX3x8p//CABEIAggCCAMBIgACEQEDEQH/xAAxAAEAAgMBAQAAAAAAAAAAAAAABQYCAwQBBwEBAAMBAAAAAAAAAAAAAAAAAAECAwT/2gAMAwEAAhADEAAAArUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhnWEeRmmb0x4rNVeRP0JhnnsAAEAkAAAAB5DdFKtn3u7C+cnM/ObnTSUFdAAAAAAAAAAAAAAAAPKFfaVbOTmatPW5sahZaxZdJTj7MewEnNFKzqo8Vq3tB7ISvvzlaPpD551RN6VOTi0y1bYkE1fhlYDTC7c+nGeeB74ifjosIz3AAAAAAAAAAAAAAAAR8gR888vtC0ywnuycrY4YGtrZW5HgvjWt0/vvlC9O7mRIbITUibxhc0yWjR0HJyWDpKpMboyNLd2fOJym1opVzzi3zxK+aZc11zyz19EWAAAAAAAAAAAAAAAAA8+ffQvnts7XyQmi1cJDv6rYZaIrgRIR8lKV2rfZZvYtA7Zv2JhMZ3wrnNa/JilZ26PmOOUgeS2dihO+VUrVvrsbXeb8j5BNsGewAAAAAAAAAAAAAAAAAGPz6cgr5e2LLkvy7IDGbjXhn+nbTXXnkiQSEAAGGaWmPlsUUzK1V69JfhiLHbCsTaGjX6Mj5DLoBIAAAAAAAAAAAAAAAHkZI0Sac1i4pTXk5q/7OxrnLs89QiQAAAAAAGramK1GXOtXrMRPJZbc1avVEl69VpGeoAAAAAAAAAAAAAAA8ICuZymnPJ1yVgbZd9n0dWfSFZAAAAAAAAAc/QmKVI9tc0ysVctcBOdw66pasuv0RYAAAAAAAAAAAAADyKyrM047ZVOzXm1SELc669Iz0AAAAAAAAAAAxqFxhb15eqBkr88Z9A+eStd7mjJPPUEgAAAAAAAAAAAeV2Vo1qJKR7NOSJ5bDwIg7rSrtTpClzmr1q2jRTPJi6KYmLmpgualk3RSxdFMIuamC55UoXxR5eLWFhnSzTuTFE6tM9rhzaJ4yp9k8rkb/R3F25dAJAAAAAAAAAAArkNKcGnPYNW3Vbjy4+zjWg7tSbtTscHZS044F892WGw1a+jnAltz074ePSdWvfoQEgAOq3UeUpa0DPSkzkHObc3br2a2G6tWWvLytjq9oy7giwAAAAAAAAAAFXj5CP157Dq26p48uPs41oO7Um7U7IauSsVaB0zXDt7uZXi5rLBHKJs36NkNoiWjfrlqJFXk3SXKrGeWKvLeCZunRFSuOtJnIOc15+3Xs1sN1esNeXkLRWLPl3BFgAAAAAAAAAAKvHyEfrz2HVt1Tx5cfZxrQd2pN2p2VWNk4y9U5By6kXlv5Vu7t0+qQ7PBd76N5lE4+Z4nNYIGcmkC26lpLX2xqnMJvY5mHmMtaTOQc5pz9uvZrYbq9Ya8vI2esWfLuCLAAAAAAAAAAAVePkI/XnsOrbqnjy4+zjWg7tSbtTsrsLbqjaGWK1ZzZX0Vn4nVtWw36udP0dGyWO4Q0UeegtMtbPnvSf9r5SVihYbU2aRxyy1pM5BzmvP269mthur1hry8jZ6vaMu4IsAAAAAAAAAABV4+dq+mFs1Z424/ePt4kwd2pN2p2KvaMYtRUpF6Zgj3o5dpt0++Hs9XUTbOCCyid7UmNun3yYwAPTyza5qlwpekzkHObc3br2YsNlen6q0nLPBzmXaEWAAAAAAAAAAA10S/ck1qk5X+PXmuEZC61dt2onRG10Q8rnfPg7xXNFqWiqLWKotYqi1iqLWKotYqi1iqZWkQMt0KgiwFJm4XRthcddW1s5Hn226vR0bDPUEgAAAAAAAAAAAY8Xd6iK1TOlHz+fr9z0yqWq98ETBd3nHMSnLHc5vs9PnydGegAAAAAAA5pinWmqfQbRw7+5TTz0ASAAAAAAAAAAAAAABRJPqrWmN3a9mdwk5OsiEmMwESAAAAAAAg5imXr0XqDna2CLgAAAAAAAAAAAAAAAAYUm8aJrTrVU9d87mjZKlgiQAAAAAAAGEfXrV3+43OW3IpqAAAAAAAAAAAAAAAAAABrrtm8V+d7rzDXpxd8PHzF12ULbC8KdtLYq2SbOrPhZ1WwRbFO0F04qnslMxfZKprFgn99ba8/VbAkAAAAAAAAAAAAAAAAAAAABjl4jk5ZOuTGyC0L5ZyXFbyuLGratRVrq16zMxTuytrh1RslS70WAAAAAAAAAAAAAAAAAAAAAAAAatlNmurm2W2+fD1dCtqJZVatS94UzXE92fPa5ZQVhVtRLTjWLV+jexUrnqCQAAAAAAAAAAAAAAAAAAABGIk/KVx2p9BfPRa6i8vS6b6OrN4UcXjVTBZdtVSvCjoXhRxeICGTG2+/OdqfoT56rb6H5QZZNpattbAkAAAAAAAAAAAAAAAADgpE7x6Zb5GR9ZRyRQjkiI5IiOSIjkiI5IiOSIjkiI5IiOSIjkiImCufNKv3P5v9Art0iugAAAAAAAAAAAAAAAAFU5ZCL057ELcgAAAAAAAAAADHLQVS/UH6JTu2imoAAAAAAAAAAAAAAAAEBA2OsaYWoW4gAAAGrlr7Se2QmmNLb7WbHOWYUAAAcnXwJr30b599Bp3+imgAAAAAAAAAAAAAAAAEXTrtRr43F57fhAAAee6E1mw1n6FTt26dymtE7eqM157EJ5AAAEbJRK/BfKRd8+0K6AAAAAAAAAAAAAAAAAc3z/AOjfOb5W3bz9F+EEAAMchUbTwwUdf0XGmc9Nd2/gs1+fYJ5wAAELNQLTZcanbMu0IuAAAAAAAAAAAAAAAAB587+iUC2c72R3fpw5MSuTEZMRkxHvPvJitkiW8zxKZMRkxGTEZMRlXbBW2kvZq/YMu0IuAAAAAAAAAAAAAAAAAot6p1qbJKDnNOIGYJAAAAAAAAAVmxVdrbJuPkMewFgAAAAAAAAAAAAAAAAPI6RrE1gJSKa89kyrJSzKx6WZWPSzKz4WdWfCzqyLMrHpZlY9LMrPhZ1Z8LPprw6uiO2Rr9D94uzLf0JAAAAAAAAAAAAAAAAAUG/VmacEhXPNeeyK4RY1cFjVwWNXBY1cFjVwWNXBY1cFjVwWNXBY1cFkr2G1ayz3J1Y9HoWAAAAAAAAAAAAAAAAAA58RAAAAAAAAAAADcQ2CZAAAAAAAAA//xAAC/9oADAMBAAIAAwAAACEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABD6wAAAIAAAAADVD0AAAAAAAAAAAAAAAACkPWgA3X9nIokAE3IAAAAAAAAAAAAAAAAAExL+jIqcpzi9s7TwAAAAAAAAAAAAAAAAADamRl7UIDv8jj4EAAAAAAAAAAAAAAAAAACqXesUz775xq7W8EAAAAAAAAAAAAAAAACNnq577777774myNAAAAAAAAAAAAAAAAAB5Aj7777777775ltAQAAAAAAAAAAAAAACP15777777777775RnEkAAAAAAAAAAAACiyRz7X8EEwwEEFT6nEKoEAAAAAAAAAAABNNfzUNGEDHAkAECP5RIUIAAAAAAAAAAABUNbwAZxUBUMAOWYDZQJWAAAAAAAAAAAABUNbwFegUd8kOyJUDRQJUIAAAAAAAAAAABUNbyAHAg1z/HnEMP8AUCVKAAAAAAAAAAAA2OX88ICpRDjCBCGB+UKMIAAAAAAAAAAAA+RWBW99EAAAAAUfe+FWEhAAAAAAAAAAAAA4vz2vjF++++++++pWwBAAAAAAAAAAAAAAAAt2sN+++++++++gzAAAAAAAAAAAAAAAAAA8Zz+++88+++++TgAAAAAAAAAAAAAAAAAAAnFZX50w59UUoxAAAAAAAAAAAAAAAAAAAAAAVWfrSZKNgAAAAAAAAAAAAAAAAAAAAAAAAN4sXtc8xoAAAAAAAAAAAAAAAAAAAAAFTy9f9tuf9phyRJAAAAAAAAAAAAAAAAAAo5CCCCCCCCCCC36AAAAAAAAAAAAAAAAAASwyyyyyyyyyyyn9AAAAAAAAAAAAAAAAAANDDDDCJ3qDDDDXsAAAAAAAAAAAAAAAAAALDDDDG/RdDDDDCLAAAAAAAAAAAAAAAAAA9jDDDCFTSDDDDWrAAAAAAAAAAAAAAAAAAqOPPPPu8vPPPPfjAAAAAAAAAAAAAAAAAAEqDCCCCCCCCCCPjAAAAAAAAAAAAAAAAAA9hhJJFFBJJFFdDNAAAAAAAAAAAAAAAAAAX1wwwwwwwwwwwRHAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBAAAAAAAAAA//EAAL/2gAMAwEAAgADAAAAEPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPEq/tPPPvPPPPPH2b/PPPPPPPPPPPPPPPPOwy6/D8zGNSOPGlKfPPPPPPPPPPPPPPPPAH5tkQ87AI4+PTPPfPPPPPPPPPPPPPPPPPIUR99xiRrTbloafPPPPPPPPPPPPPPPPPODl7Hv/PvvnLbBjFvPPPPPPPPPPPPPPPPOe6LfvvvvvvvvmScPPPPPPPPPPPPPPPPOLj3vvvvvvvvvvu/DkfPPPPPPPPPPPPPPKsznvvvvvvvvvvviXgmvPPPPPPPPPPPPDlk1/tvs8/v884/fuisFUPPPPPPPPPPPPC0KF/AuZwGcKgAAJfg1U+PPPPPPPPPPPPPwq14hdBQFgwQWjUfQ11gvPPPPPPPPPPPPgq1wFI7ZjTgGgYwPQ11lfPPPPPPPPPPPPQq1wUIuLLOm/wA8Eb4NdZTzzzzzzzzzzzy16JewEK5lEE8kIMf4NtsHzzzzzzzzzzzwzqmbX7zn333323375InEXzzzzzzzzzzzzzl5XaG4X77777777rUqHzzzzzzzzzzzzzzyjD7z73777777763rzzzzzzzzzzzzzzzzzznDz77777777bkBzzzzzzzzzzzzzzzzzzzz8txrHnXHN0iLDzzzzzzzzzzzzzzzzzzzzzw2j+157k/zzzzzzzzzzzzzzzzzzzzzzzzwiS2fJ2wcHzzzzzzzzzzzzzzzzzzzzy53EX7/AOs//pyxG0888888888888888888wZDDDDDDDDDDD1d888888888888888888lCAAAAAAAAAAARy888888888888888888JDDDDCbmlDDDDH1888888888888888888HLDDDSJcSDDDDW1888888888888888888yoDDDTdlTDDDDAC888888888888888888LMPPPP+OuPPPPb5888888888888888888CU/wDvvvvvvvvvsa/PPPPPPPPPPPPPPPPPLH/uuttsuuttr1vPPPPPPPPPPPPPPPPPPHls8888888888xx/PPPPPPPPPPPPPPPPPPIQAAAAAAAAAAA/PPPPPPPPPP/xAAtEQABAgQEBgMAAgMBAAAAAAACAAMBBBESEBQyUiAhMDEzQBMiQiNBNFBicf/aAAgBAgEBPwD/AFLbZOOUgoAyGoE6wJjcHBXjYZv5xVjMewJ9mz7w0+lKeZG2USUEfMiwBsi/ChKuEss5dRZT/tRkzRMOj+FHl3wlvDRA3QlM+H0oRISrBMv3p5/8ioNOH2TEt9rzX1h2VOEgA9QJ6WIdCbcJol8g/H8icdI/Tk9RoJcbzMl9R5Qwi8IqMyUey+cl8xIX6d0MwJK7B1kXOaKFJT1JVsh+0cDMQ7o3iPSq8QGUEDwn3wchVsxRQjDv6TDd5YGYgNYojI+/REkw5XkeEy1cN4+kyFjeDzlS6YlamzvGuDwWOU9BlgiLng+do8FCVCVCVCVCVCVCxYOhUwmWSPmKiJD360syJfaOMzqDBtkj7KEssqG9ZQd6yob1lQ3rKhvWUHesqKOWL+sBjTEwExpHUi5Rp1Zcf4cZnUCZbvKqt24QwjhDgeZrzHCGnGYh/KfVY8AYzOoExCjeEUOEcB4XIUcpwP8Alj1WP8cMZnUCa0Bh+cbhVwqo8LvkPgf8x9WW8AYzOoFLFUKcGoaI4W91VSwkI1ioY3Wo41OvBMeY+rLRq1jM6gQOWFyQGJ4RQo2mzUJZoVRCqovqn3q8ocL8auHGHVYe+MkJXacHmfk5wRtkH4QmQ9kMy6sy4sy4sy4sy4sy4sy4sy4jccL94jpX2Tr4wHl14EX9GoOFdCpp8iEbhQzAlqX8BIG2YlyT4DbWHR1KaIhEKKJub/SD+RnG4vyomR9GWCpXKYcvc9Nlz4zr+UbYu/YUQW9+hQsG2CPunnhbG0PVBwg7IZls9YKxk9KjKrKkss6ss6su6sqShLtj3NXy4JyaKPIV/wC+v9v6TfzHpQNuQ1GnjIC5LMOJk726pxoj0GiuHV7TTZOFROOC19AUXXIlVVF4arKknHBBu0EDrgohF8ao4WcvWgJF2UJQy7rKFvTLVg0/Sy5XVisuSy5f0a+F7essW9ZYkDJAWtPy3yFWCyhb0Uq4PqSwiLd6iZKpKpKpKpKpKpKpKpKpKpKpITKHdTTYiVYemxzZBWirRVoq0VaKtFWirRVoq0VaKtFWipzSHpyujjvHfxzncPTlNHFNEQjyUIlDmmTI2a8U15PTk+x8TzYmKGUJANg2w4pny+nJ6j6z/mP05XydZ0quH6bQETnLquiRD9UUPTljEXOfVutTpXOFGHqXnuirz3RV57oq890Vee6KvPdFXnuirz3RV57oq890Vee6KvPdFEZ7un//xAA5EQABAwICBgcIAQMFAAAAAAACAAEDBBIREwUUIjEyUhAhMDNAQlMVICM0QWJzg0NjcqIkUFFhsf/aAAgBAwEBPwD/AGmSQYxxdS1UvE6pq27r8vZ1M9mwHEjrMsts9lUtRfsv4Kr7tS1TwEYmC0eEm2T8LqPqjDoOaMN5p6yJtyLSFIJWua15NWjyoaiAvOhcX3dFcxXngqmpeYLLFo4SHJEuTwRCJDg6qKYY/uVPSiNpujmjDqdVOmYLssEWkru6C5Y18u7YWoVJliUi1SrH+b/J1l14ee7/AC/9Q11RH3kKptIRnwmoqwX41LEMw4rV2zbPMoYBiH7vB13ACkqrYgZlPXkRWQ7ZKHRxFtTKOlEeEE0GG9ZIrKDkTwiipn+in0eJ9Y7CGaopCwl2wVLWs44hwoTE6u5vCVkw7lLNJVyZcfAqWjjiHAEEYssPeMRJSwCX9qlhkpJL4doFR1EZkEjISEutvBVMuWHUq6oMzyA8yo6QY48GQCLD2JCp4RtxRiVDUXt3Rqin+nl8FpGqtEy5Vo+Fy+KXEajjtHsyG5VlMJiYP5lo2YgLIPiBQyXx4+AnnFgNhVbTy1FjCdqpYxGweX38femDEcVNTS62EsapZhC5iQmJbu2qprRsbiVRpErrIVTVk5TAJqm3H0PMIJ6lawtaWsktaPkWsLWlrKGoF96uRKsmKGJyFBpCpEutUVbeN7ICuHHtdJOTXv8A00Kpfmo/yKm3GpjsHBEVyxw60/8Ax0N0P0YP0QzYdT9Gkvl/2IVosvimKp3+CHa6T4ZvxoVS/NR/kVNuNTvjIiewbnQz1cnXGGz96hmvKwuLoboJGYxheazaw9sYQFlFLmf39Eb4jitJfL/sTcK0b3361TdwHa6T4ZvxoVS/NR/kVNuNSd4aq2J6Y1GQkAOydxKtC301grC5FaScSbeq1sIwJ+EZNtdTjiyj2q03D0+iPuwWkvl/2JuFaN779apu4DtdJ/zfjQql+aj/ACKm3GpwwNf9OipI7vhnIAqGIYx2OJD1FigcSZYNyqqMTLAUbC42kipBx2JJBFRxiA7KYUDYDgtJfL/sTcK0b37/AI1TdwHa6QjInNv6abqe1UvzUf5FTbjRheKMLehk6CeQOpiT1chLFP0YKGG3rfo0l8v+xNwrRYbZmqZsIQbtZ4cwfuVZo4ZCxfYUGjgikA71DJZvV4v51YP1WRGsgVqwrIjWRGsiNZEayIkMYt01MGcLgg0UP1NUtGI+TZQtb2ziL7wRRC4ngCgYXKx0VOXlWE7IpJGUBkRYP2VIAkR4poo28iZsPAyDlT9No/VMAtw9jOeAqmjsj8HPFmDh5kBFF1GhIS3djwo5xbcoICkK8/CnCMnEjpJA4DTlOG8E1RgtYZZ8Sz4lnxLWmTyyFuQxTyb1HSCHW6w+jeHe36qR4Q3gpJGPgBQxibdayY1MAgWDKOeNuMEFhdY+KmmGMcXQjJJtkmAWHBYFCWC1huRRg5HiaOIXQmUBfagO/r8MRCO9PWxfRa8PKpZsw8fKhqBEcFrQrWI/qCzoeVawK1oUc4mKgqsscHWvDyoKuIt6xZ/B1cu1h5VmLMWYsxZizFmLMWYsxZizEMipJCIbX8HpFi+Ngr5OdXyc6vk51fJzrMk51mSc6vLnWZJzq+TnV8nOr5OdXyc6hOQpWC9UHEfg9IDx/j96koCl+IfCn0VDvskVTRlCX2e7TDdUB+RUTbJeDrh20+9/cjG+VgVDCLvjyp2uHCxaSjHLmDl92hbGqBUfd+Dr/IpRtmP3BK07lQ1ok14+ZPWBbwrSVVsmF+2fu6OH/UgqTuvB1rbIKqbCoP8AJ7oSSRlsJ66q50REZXF7ujB+N+tU3cB4Ot7tV8ds5F2mjQLbNQjhGHg5nEYyvUsUcnUS9nwr2dAvZ0C9nQL2dAvZ0C9nQL2dAvZ0C9nQIdH07KFo4yDlQvs4+DqoyMOpS0rSFi5yCtQb1pFqLetItRb1pFqLetItRb1pFqLetItRb1pFqLetItRb1pFqLetItRb1pFBTEG43JQiQRgz+Eyo+VllR8rLKj5WWVHyssqPlZZUfKyyo+VllR8rLKj5WWVHyssqPlZZUfKyYAHcLdn//xABEEAABAwECBQ4NBQEAAwEAAAABAAIDBAUREiExQXEQExQVIjI0UVJTYZGSoSAjMDNAQlBUYmNygbFDc4LB0SREcOHx/9oACAEBAAE/Av8A0mXNaCSbgFVW268tpwLuWf6RtKuv4Q5Q2zWM3xDx0qkrYapt7MuducejV1rMpyY2DCf3BPtSvefPXdATLUr2Hz1/QQqK1o5zrcgwX9x9iW3VnCFO04sr1T08lRJgM/8AxCxo8HHI4lVNA6IYTTe3P0KnnfTzNkZm71G9r2Ne3IRePv6JadUaamJbv3YmrGTixkqGxtzfK/HxBT2UBvHG/iKILT0hWXVGopt1v24j7DrXYVZUH4z3KxmtELjnLtR1xLuIp4wXuHSrIN9BD9/z5LXY+W3rQc05x5G3ydcgHwlWW1uywTmF+pLlCtNoFRparAPjZx8I9h2rCY66TifugrOqmx3scbgTeCsJ3GqmpbAzLuswWVUUWs0sLM4bj8Caqp4R4yVrVLbsA82xz+4KS3Kt29DG96daFa7LUP8Ati/Cs6vc+Dxt5IOXjVbVuNLLrYN9yuVybLKzeyPGgplpVzMk7vvjUdvVI38bXdyitukfv8Jh6f8A4o5o5Bex4cOjwLehJjilHqkg/dU02szNfmzpk2Ey9j7wnvaxuE92JVM2vTF2bMrBhIZLKfWIA+3sOvohVxXZHDelSwyQvLJGkFNllaLg9w+6JKsuzHF7Zpm3Ab1vgWxWzxyiGN2CMG8kZVlTKeZ+RhTbNk9Z4Hem2dCMpcUyNrG4LRcFcVsaLmm9S2JBzLUaGn5FydZsfqvIT7OmGQgp8UrN8whMe+M4TXEHjCp7bnZilGGOoqmrqap82/HyTl1JI2yMcxwvByqtoJaV5xXszO/1Ne9u9cRoTnvdvnE6VR0MtU8XC5md/wDiijbFG1jRiHsSWGKZt0jA4dKmAbNK0ZA9w71Y9PAaZsutjDvOPUq66ClG7O6zNGVC3ajXbzGzA4s/Wn1TnDc4gpoI59/l41HSRM3rPuUcFgvc4BOr6VuQl2hOtXkw9ZRtOo4mj7LbCr5fcFs+r53uCFoVXLB+ybak+drCm2oz1oupMrKV+R92lYN+hS0UL/VwT0KWhlZk3Q6FjBxG4qktmVlzZ923lZ1FNHKzCY8EIgEXEYlbEEUNQwRsDb2Y1Y8EU1S4SMDgGXhAAC4C4exqnhE/7j/yrG4Az6nflV9sYN8dPlzv/wARJcSSSSc6goHP3T8Q4s6DVLVU8OU3niCltKZ293I705znG9xJTIpJN4wnQE2zao+qBpKbZD88w6kLIZnmd1LaiLnXo2QM0x6k6yJfVkae5PoKtv6d+hEEG4gjSmTSx7x5ChtR2SVt/SFHJFNvHKekjlyi48oKemkhOPJxqnqZqd+FG67jGY6VRWhFVN4njK1W9wiL9tWDwqT9v+/Y9Rwif9x35WzJditp24m48LpTI3SOwWjGqaiZHjyu4/8AFJLFC3Ce5T2hLJiZuW96AJNwyqGy5n+cOAO9RUFLH6mEfiQWCVgLA6VgdKwOlYCwSnsa4XOaCOlS2ZA/eXsPcp6GeHNhN4wg4g3gkFU9pZpu0rmPbiuIKqaC690Y0t/xNc5jg5puIzqrq3VWtl43TW3HpVg8Kk/b/v2MSpyDPMRkL3flQwvmfghQU7Im3D7njVVWsh3Lcb/wpJHSOwnG8qloJZ90dyzj49CgpoYRuG/fOsFYI8jiWCiCqighmx713GFPTSwG540HMoKmSA7nJnChninbe3q4lWUWFu2b7i49SwiBVvx5Y/Y1sV+WmjP1n+lHG6Vwa1U9O2Ftw61W1utbhm+4+JYyeMlUlnYNz5suZv8AqDUBd5YtT4w4Frm3hVlnmK97MbPwopHxPDmnGqapZOy/P6wVbR4Q1xmXP0prnMcHNNxBxFUFa2qhv9cb4exLTrdjQ7nfu3v+rGT0lUdNrLMe+OVVtXrLcFu/Pcsbj0lUNCId2/f/AIQbx+hFqr6DBvliG5zjiUcro3hzTjCgmZPHhD7hV9LgHXG5DlVJUvppmyN+44wo5GyMa9uQjF7Cc4NaXE4hlVXUmpndIcnqjiCs6mv8a7+KqJxDGXH7BPe57i5xxlWdR4AErxujvRxJrfRHNVfSay7DYNwe5U1QYJL8xyrcyM42kKpgMMhbmzKxazBfsd2Q7zT7CtuqwYxA3K7G7QoYjLI1gzprQxoaMgVbUa9L8IyKzqXXX4bhuG95TW+jSxNcxzXDcnKqiF0ErmH7HjVm1H6J/iq6DXocW+bjCa5zXAtNxGRUdQKinZJ16fYBIAJKqp9kVEknGcWhWZDcwyH1smhWhPrcWCMrkxjnua0ZTkVPC2JjWDIPSLRptcivG+ZjTXFrg4HGFFIJY2vGcKvh1qfFkdjCsSpwZnQnI/GNPsC159aoyBlkOCmML3taM5TWhrQ0ZALlWTa7O45hiCsmC/ClOhvpLheq2DWZ3Ab04wrLl30R0hV8WuQX5241G90b2vblab1FI2SNj25HC/06rtSnp9zvn8kf2q2ukrHNLmhobkCjkdG8PblC2xqMEjc5MqAvNwVNEIomM4hd6Va0N8WHyT3FQya1Kx/EVLahOJjMXTqUlrTU8YjwGuaMnGqW06aoNwOC7kn0y1LSLSYITj9d39BAFxuAvKjsyU75wb3rapvOnqVTQGFmHh3i9U/n4frahk8Fzmt3zgFsyk5+PrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzKT3iPrWzKT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrQqqZ2SdnX4U8Ykjc05xd1pwLXFpyg3KCjlmxjEONCyhzvcpLMlaNw4O7kQWnHiIVl2m55EExx+o7j0+lV9Rsele/Pm0rGT0qkpWwsxjdnLq2jwU6QqbhEP7jfAqauGnbe848wzlT2pUy704A6MqJLje4k6fQI5ZYj4t5boVNbDhinF/wAQTJGSMDmG8cfgT+fl+tys7grdJ1aulEzLwN2Mixg8SoKjZFMx+fPp9Jt9+5p2dJPUqBmHUt6MeocqarR4KdIVNwiH9xurXVraZmLG85B/ae973lzjeTn1ABqPHgMyeA8eQpauSmfe3J6zeNRSsmjbI04jq1HCJv3HflWdwVukp2TVrmYFS/pxqwH7moZxEHr9Jt/zlP8AS5WZwg/QdQ5U1WjwU6QqbhEP7jdSR7Y2Oe7IBeVPM6aV0js/d0arDqHwGnH4BGLyNl1WtTa2d4/uOrUcIm/cd+VZ3BW6SnZNW0+E/wAQrA87UfS30m3/ADlP9LlZnCD9B1DlTVaPBTpCpuEQ/uN1LZluiZHyjf1eBDHI924aSthVXI705jmG5wIKdl8AZPAcLjqx088m8YSjQVQ/TRBGUeBSy69TxycYx6lRwib63flWdwVukp2TVtLhP8QrA85UaG+k2/5yn+lyszhB+g6hypqtHgp0hU3CIf3G6lsOvqgOJg1aWAzyYObOpqmGkaGMbj4kLTmy4LEySGrjwSPtxKphMTy05vAYfAfkv1KGkEpwnb0d6qK9kRwI23kdSbast+NjfsnsgrYr25cx/wBTmlriDlGrY7r6W7kvOpUcIm+t35VncFbpKdk1bT4T/EKwN/UaG+k2/wCcp/pcrM4QfoOocqarR4KdIVNwiH9xupavDHfS3Vspvinn4lI8vkc45ymFUzi2ojPTd1q02+aPGCPABx+AdSHxVnYQy4BOrZjyJy3MWq0W3VJ6QDq2L5iT9z+tSo4RN9bvyrO4K3SU7Jq2nwn+IVgb+p0N9Jt/zlP9LlZnCD9B1DlTVaPBTpCpuEQ/uN1LW4YfoGrZcu/j+4VZTmKQ4tyciacaoYC+QPO9b3q0JA6UN5I/KeNTW5OQ7qWBJyHdSDX3bx3UsB/IPUsB/JPVqOyqhc2WlMZzXg/dTROheWu1LNpy2+V2fIquTXKh7hkyD7ati8Hk/c/rUqOETfW78qzuCt0lOyatp8J/iFYG/qdDfSbf85T/AEuVmcJP0HUOVNVo8FOkKm4RD+43Utpl0kT+Nt2q1xa4FpuKir4ZG4Mwu/CwbNGPxfWprQYG3Q9fEtKcMSs54ZWwH4ruvwal4ZBK7iadR4xKGZ8L8JqbWUk7bpAB0FXWdHuvF/lVVoYYLI8QznwLLZg0cfxXnUqOETfW78qzuCt0lOyatp8J/iFYG/qdDfSbf85T/S5WZwg/QdQ5U1WjwU6QqbhEP7jdS0INepnXZW7oeEzi1chVnVraqH4xvh4FrVgPiGH6/wDPIwxGaVkYzlNaGta0ZALurUqOETfW78qzuCt0lOyatpcJ/iFYHnKj6R6Tb+/ptDlZvCf4nUOVNVo8FOkKm4RD+43VtOj1mTXGjcO7j4LTj1XhRySRPD2OIIzqC3TddNF92o27SXbyRTWxNMCIxgDv8B4x+FZlHrTddeN27J0DVqOETfW78qzuCt0lOyatpcJ/iFYG/qdDfSbbhw6UPHqO7ioJNama/iKBBAIyFFuNAK0eCnSFTcIh/cbqua17S1wvByhVlmyQ3vj3TO8eDrnQtc6EXXjwA65a50LXOha50Jzr/AALjcBeTmVBZmBdJNlzN4vAqOETfW78qzuCt0lHIsEokAEk4gp5Ndle/jVhxYFK559d3cPSXsa9jmuyEXFVdM6mmdGf4njCpK4w7h+8/CjkZIL2OB1LRlj1kswhhXjEoCGzxE5A8FNc1wBaQQc/gVFnU02PBwXcYT7FlG8kadOJGyazib1raqt5A61tVW8gda2qreQOtbVVvIHWtqq3kDrW1VbyB1raqt5A61tVW8gda2qreQOtbVVvIHWtqq3kDrW1VbyB1raqt5A60LJrOJo+6jsXnJeyoKWCAeLZd05/BqOETfW5Wc5uxw2/HecWo+SOMXvcAquu17cMxM/KpKZ9TMIx9zxBMY1jGsbkAuHpVVRxVUeC/wCx4lVUFRTHdNvbyxkQN2RGSU5ZHderBVTwHxb9IzKC2InYpW4B48oTJGSC9jg7R6TVcJmu5bletdl5x3WiSqWz6ipO5bc3lnIqWkipY8Fg0nj9MuUlnUUmWBv2xfhbT2fzR7RVoUdPHQTa3E1uQ4kDc4HpVRY7TuoHXfCVLTTwnxkZHTmTXOab2uIPQo7UrGesHfUE22+XB1FC2aY5WyD7KstYu3NObhndnTayqabxM/rvVDV7JiwvWGJw9Dc7Ce53Gb1QUFNJRQmSJpJvxraag5o9oqOz6OPewN++P8q72BOzXYZGcppGpRya5TQu+HH9llUtm0knqYJ+HEpLFP6c3WE+yqxvqtdoKNFWD9B6cxzDc5pB6dSxWOumdmNwH29CrJNbpZnfD+dSBmtwxs5LQPYlow6zWStzE4Q+6sabcvhJyYx4VVRw1I3WUZCEyxWYW6mJGi5MYyNgYxtwGb0K2ZtzHCM+6Ks6HXqyIZgcI/b2LbdLhxCYZWZdChmdDI2RubvUUrJY2yNOIj0iWRkUbpHHEFNK6aV0jspVi0uBCZiMb8mj2KQCLirQojSzZPFu3pVDWupnXHGw5R/iZIyRgcxwIOf0aSRkbC57gAM6rq11S7FiYMg/1WdROqpsfm274/0gLsQ9jTwRzxGN4xFVlDLSP3WNmZyp6qandex2kZiqa04JcTjgO6fRKm04IsTd27oyKoqpqh18jtAzKioZat+LEzO5QwRwRiNguA9kPY17S1wBByhVdiHfUx/gf6Ukb43YL2lp4ioauoh3khu4syitp36kV/S1R2pRu9ct0hMmifvZGn7+UfNEzfSNGkqS1KNvrl2gKW2n/pxAdJU1VUTb+Q3cWZMY+R2CxpJ4gqSxDvqk/wAB/aYxrGhrRcB7LlhimbgyRhw6VNYULvNPLOjKFLZFbHkYHj4U+OSPfsc3SNRs0zd7K8aChX1g/Xd+ULUrh+pf/ELbes+DqW3FVyY+orbmq5MfUVtxVcmPqW29Z8HUjalcf1Lv4hGvrD+u78J00zt9I86TqRxSybyNztAUVj1r8rQwdJUNhQt87IXdAxBRQRQtwY2Bo6PaBF+VPoaR++p2dSNjUB/TI+5U9j0MYvdUOYOkhVDKVvmZXP47xcoIjNK2O+69bUv51vUtqZOdatqX863qUtmGOJ79dvuF+TUp6WyJf/JffxO3KbY9APUJ0uKZRUjMbYI9Nyu9qOc1rS5xuAylVlt5W0/bP9J8j5HYT3knjKwH4GHgnB48yoXBtXCTkvu68SwAsALACtHBZSSdOLrQBJAGdOa5puc0g9Kpa+ppt469vJORUdow1WLev5J/r2pLIyJhe83AKvtCSqddkjzN/wBVPTS1DsGMaTxKmsyCLG4YbuMqqg1+B8fHk0ogg3HEQqC0WStayQ3P/OpJJHG3Ce4AKvrDUvxbxuT/AFWVTmSoD/VZj+6kijlbgvYHBVVkkXugx/CVja7OCCrNtPXropj4zMeV7TtSu2TLgMPi295VJSPqZLsjRviooo4mBjG3DVtCzte8ZFv84405rmm5wIPEm1FQzE2Z4+6c978bnE6VS0U1SdyLm8rMoYGQRhjBiGrX2eJxhx+c/Kxg8RCsyt2TDuvON33++0bXqtZpsEHdSYvsmMc97WNGMm4KmgZTxNY37nj8GWCGYeMjDtKNkUZzOH3Udm0bMet36cayeDa1Jd49o6H/AOqjqTTVDJM3raECCLx7LrbShpcW+fyQprWrZP1MAcTUaioOWeTtFa/Pz0naK1+fnpO0U573b5xdpN6BIN4Ny16fnX9pa9Nzr+0ten51/aWvT86/tLXpudf2lr03Ov7RWvTc6/tFa9Nzr+0Vr03Ov7RWvTc6/tFa9Pzr+0ten51/aWvTc6/tIyynLI8/fU16bnX9orX5+ek7RWvz89J2imVlWzJUSdaprckBunbeOUFHKyRocxwIOT2LX1Wxacvz5G6U5znuLnG8k41TWQ5wwpnFvwjKtqqLkHrK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaK2qoubPaKfY9Kd7hN71VUctM7dZMzlZdaaeYMJ8W84+g8fsW3pPGws4m39asqFslTecjBf6VVQiankYeLFp1KV+HTQvOdgPsS3m/9EJ+BWUbp3fQryryryryryryryryryryryryryryryryryryryryryryryryrynuIY435jqUQuo6cfLb7Et8cHP1Kzj/0jQfSqg3QS/QdSIYMTB8I9iW+PEQn41Qn/qj8pJNFFv3gI2nT/F1JlfTO9e7T5StN1LLoTRe4DjPsW3B/xDoeFSm6oh+seTravWRgt357k5znG9xvKZR1Txe2B92hSRyRm6Rjm6QqarkgPG3OEx7XtDmnEfJWif8AldpCphfUwD5jfz7FtcX0EvRce9Rm6Rh+IeSJuUshkkc85yrJoGYAqJBeTvB/epLDHKwskbeFW0ppZyzNlboVly76P7jyVpnxDfrVni+tp/r/AB7FtIX0NR9Hk6jg8v0HUhAEUYGTBF2rb13/AD8e6Vm8KGg+StU7iMdJVki+vh6L/wAexatuFSzjjjdqRG+KM/CPIubhAjjCewsc5pyg3Kya1skQhcd2wYukajnNa0lxuAzq0avZVQXDeNxNVlxY3yfbyVqnHF91YgvrdEZ9iuF7XDjGpSm+ni+keSrqQy+MZvs441jaeIplq1zRdrt+kKerqZ/OSk9GZQQPmfc37lRRtjY1jcg8lah8c0fCrBH/AEyn5fsaQXSSDicVQG+kj+/k5qWGbfNx8YRspuaU9SZZkI3zi7uTWNY3Ba24eTtI/wDT/EKwBjqD9PsarF1VUD5rvyrNP/N/Iq9Xq9Xq9Xq9Xq9Xq9Xq9Xq9Xq9Xq9Xq9Xq9XquN9VJ9lYA8TMfj9jWkLq+o+r+lZh8S76vSak31Ev1FWGP+M9Lz7GtqLBrMLltH+KzpQ15YfWyekSSNjY5zsycS4klWbFrVFEDluv6/Y1o0myoLhvxjari03Zwqe0LsUuP4kKunP6oWyafnW9a2TT861bJp+db1rZNPzrVsmn51vWtk0/Ot61smn51q2TT863rWyafnWrZNPzretbJp+db1rZNPzrVsmn51vWtk0/OtWyafnW9a2TT863rWyafnWrZNPzretbJp+datk0/Ot60+up25DhHoVRUvmOPJmCs2iNTNjG4bvuno9j2xXP1w08ZuA35/r0qOWSJ4fG65wVFUipp2yZ846fY1dfsyov5wqgNLc/XcG+/FhLCoPk9ywqD5PcsKg+T3LCoPk9ywqD5PcsKg+T3LCoPk9ywqD5PcsKg+T3LCoPk9ywqD5PcsKg+T3LCoPk9ywqD5PcsKg+T3LCoPk9ywqD5PcsKg+T3LCoPk9ywqD5PcsKg+T3LCoPk9ywqD5Pcr7P8Ak9ykwdcfg73CNysHg8v7n9exrXs95fsiIX378f36VDDLM8MjbeVR0wpqdkY+56fY7qaneb3QsJ0LYVJ7vH2VsKk93j7K2FSe7x9lbCpPd4+ythUnu8fZWwqT3ePsrYVJ7vH2VsKk93j7K2FSe7x9lbCpPd4+ythUnu8fZWwqT3ePsrYVJ7vH2VsKk93j7K2FSe7x9lbCpPd4+ythUnu8fZWwqT3ePsrYVJ7vH2VsKk93j7K2FSe7x9lbCpPd4+ythUnu8fZWwqT3ePspkbGC5rQB0eif/8QAKxAAAQIDBgUFAQEAAAAAAAAAAQARITFREEFhcYHwUJGhwfEgQLHR4TBg/9oACAEBAAE/If8AJwUE6f2zp7IcEE2Ack3MufmJOREuOmw7I+MJgx5hPMICd7UdApX/AHUYl+FAAQ1yUQe6G3PLsp+BmwtGcbggYGJJkCC0TYBHbW1JPuOIovCKo4ZPSh/chETKJvQA4cRqSUcgz24oKfnHVEILgnIhBT3Ln0PAzmKXwX4ewusEcQC5CoKGCkCHJFfXN5F/B7CEsQGjFJjaqH8KLgvNGXrhnKww1eEFkVjnsIlMT8jwMyNI1Z9UQy8AUTBpUakg/wA2SiVSUcr3AxNsFoKCY8pqHnqnzKRbk7qjfUEFsj5YJxQLDOE0qmUTKBdW1CZ3Wn5pp0uPuoWGCOOaYn0J7IWfA1O8jZACoKEIQt6KAAF6urkDAL4Hhz8Dx6dPA4FCCu434jBMx1AQCIJJJNSVMjs0yanD0EEXTCe50SSJJJJmb1c+qYBGdLiX0WIaZlywiiUkmPhRJ9CPv5CUT1Zioj08rmsEQWKWxioP6+8FCKGMAdE6Z5NgzTmEc71xR1yuJkfieJ09kA4X2KZjDYDgmWPCC6w4MATI4ykN84GybUhVPpXkmtg7leqBwb4qKCWVRUrXzCjaJqSyh+QPtUbNB8tU+0Sbnwtj6EH8gUD8YR3R84Yk/wBKVh0gTBcEEtU76hH8j1nJAhEgIgiBCO/CH7Qsc7wjpwUwUOQPAJO6YlCDJ3Q8EASEuDbdWjQAOgOhHcj9iclElN3y59KGLhJk+83CnsCMKPMnQQ3kuUa6mIfHbLlcrkR7rswC8AFd5n+18lnSKnVOn8ygMjL5GUCwI5B5IcSA1FNEOJ2JFQcBOQrr7DIJrCG/QVC32K6n8OD7/WmzUYiE3l2yQo6JMJNywRogUqU+vYU2qAgElICaajgE+VXJqRdJIIMBAUQpp1QtzLMW5kTuZENywM0Dp2JYKPInYnWfhCY4kQYo4YT4O4UTMNmCEZ5NOgh5scAmEQbHsJRTXU/hwYADkwRUgSQNQSQAHM3BN9+RAMCldmR+WRMGY0XupGYtUDM4ICu/ixTCI3QQZ7p+EP6mYUqsyYkn2TuiyKedETvOTMhxXP0iCCxEfpBAxEA5jgrp0yrd7odUT0QKLOo1QXHjntmseRqSUNgB0o2uRDgEGT+wDgUKsWYuUTd8L/uEyDDq6YSA6P4nwMMQwd0e8/AuIQFLBx65cEgTJeCqNeiTUkoL9UXZUJIYTesQSZkugAGCcrx+1f8AJ7EgGBTQqFsw0xgms3UQTlUiFDOloap1hpdMR+XfFnwIeoAcqAJ7y5QU9agOoXqZ9KsSnhBHJzUmayJvzTETP2kJxIzCv2cRX9IejlDUIhpDnQKI3EdQVGm/wXhqn4C97aeavOETQINrCYZBOLG7+6vPMugr4+2AkIWBRQWjQG9PuXHuCdGbEhOPE5UIQ1zIhoE0fflgYAOTkjnZQOGSZ9GDIURLvICaA25WDNDPgzqfbkPNPYrpiLwmtxHByX1whCdCG8KevA0f5wA5NKcjNTphAaq7cTRMaYmiE6C3RKAYMPcNHEwmNfBm5RfE5hPoC75Xo70KGiI1Ahr71wndzWjmuQRQFkvNMIiQc06U52QRCIIDklgM0EneG8+6aWLCgKpyvTkG6DxkvhZGVaYiI1Qk88EnKqf3bf8Ausx3EGkEMpkoK/WS3X7UBogDMxitqvKBgHpDOAxLIiParwleErwleErwleErxleMrwleErwleErwlHmNwagQZF/TIOKgIkwzCGwKrBM4m+H7T4C0mTNA3CRDJ4zfej7e6Zu62coskklfeSUNEDEVHuCxtPtlfQCRaTFhHCKWO59I9Iak5t1Wq1Wq19Gq1Wq1sdGbGRANWpqEIKeQWkOt+qtirZejaAoq4FBkQ5Au94ITv3WyvcloSX0d0F3J/LYRcIq9Z/bK2gYZ5cR18cSsbuA6YUCgAjL0G7LwmTJlKIH8J7jyP0nYYIfvoA2mqJNbBsvKj4F+jt7nfKi1ExSmz+2VsKaxZMlMxu0CVp4NYDghStaHH0PF/EjzFb4T6ANrr6Qtwqfc75UW4mKU2f2ythRpv2X69DSqrItP8SwrQULZ/QTgfQ887ZSlZDmhT9BCPkEBEwYW4vFO1PmhA9RaJtdfSVu1T7nfKi3ExSmz+2VsI7/ee0JcwROgUoagN2JRrE1Rj9onixMpuvCyphqD6ITa+gXCwbjjyqRULAG4W+ULFxmBThoYXgNEBExGIytd6F8G0Ta6+kLf6n3O+VFuJilNn9srZvlLQC/lvIfqnpGJTwIohqveygQnqFo32jA2tAfQDghSRfogVUmzE0swgHi8LdvgtE2uvpC3up9zvlRbiYpTZ/bK2C2OW0QJTE6yP02553JocYIVRcgahJDPLrIwXr2QBJAAJJuC8gXmCPH5C86RAHIxmsFs6O/JkpCg3xEjXGxnrMYTSqGYT6FoN+4LRNrr6Qt7qfc75ULYMLJilNn9srZBe86H9tayBcFN9kZuHJbm6Jk+ELDQiSSSTk35p7KjtkegbvayZETI7kEIABOOvCATRHUUQmcUYaFCaYPymlks2ZHoczRLq/Vom119IW91Pud8qLUTFKbP7ZWw4gdpmOXoYWHA2JogkqDA5IIchtu96AMZFyysEOjA+qdS09KlCxYIBhaE2uvpK3mp9yJe3wRyVspilNn9sra6R3H4svSwFrRBqpINgQQOt8ipAQ0YKtd7+e5Xvaw6vqPDAIN8fQJtdfQG54OIY2+PuTA0XjyCtUgYGaO04HBq6IUMAXs/tlbRjIIl7o4Cefm1GPpk+y2Ooc3oMa2utrra6Zs3oHTiGAByU6HBHHBVNfSJtdULsCyEPoAOTRliogMBJXoofI9yJJzgYFO8tPqKhASXNGeXCyLsUJGSKMxEcAVEakAiD6C5PRL6SRo83F3Qd/pXj68fXj68fXj68fXj68fXj68fXj68fXj6OMc19VHB0w7lMIJERmLVX+jYqowIWvXo2a4KiAQfIxAVLT68hoMMDAe6MRMREcyR9z81URCBJjV0FYgYkbLkREgcxYlomcqg8qapKk/uWU3eUElDkakQ5J1Qp8OsKq+Mjfl7yIRRR3hmUgI7HmnDwBwIwNUIkHAAkYBOOBxRobk0uZi1WOsiYqAkXMRobPAr4pB7pjIvgcgUb1QsHQoD4AH+x7J2DrGj5igd2KqJqoux5o+C4EjF4Ced0Ca4qJsSIzQFEAGIcYp9Oc7Ek6J0e8F8NHuynugHWFcgY2CX+zjn+fZR9vgHGAfKYyE14fQcEL2aMfygmKC07/UEgSMZBBupUIGICYeyMkIlo3IvZwx/MOCsd7/9Kd4btReE8ifZe4ZRDfNTZF2oKLfF/wA8FOgOCGOLonALZDMIrcLyzVJQxg9tM2MSCREs7FICFzcqhgAMAGAGHBn1fSNQm4DhhyOdCpQRmoZ8FynI+zlNOxMORmVcISYAoMkXjFStxtRPCA92Yl6fnWnyRKGbhlIdq8iBYDxDdCpqRT6lF8vA/wBIvl4FJSKd4opxji/ROr7Q5Ahk13Do9mmJ8kFDDAC5uF5IGOyfjjzzLVgF2KOMYoYWdRFCleq3yV0c30oVCXeHdbM7rzj7RwK3RyfSp3ot8F1BUqAjBQXO4rW0doKOE9lesKGBPPiAAYAUSdyZloPNS3J95bPsLkbAjETJBMMWM5B154vHleeImAds87DADOG7E1lUE2I4L80AAYCHFBoQHIWARIPZcRqc5kdQ1GhmOKq8rR9ljlZ6z0Z/COJQCBJJgKkozokDFFANVPwhzTBjfd3FA6R3JKuOzmYpqUkBmKBgLTRkEODOD4QkicBIYi8EIAccHMv3YVBu8lBIEiVMyUJ0VXQFnRAIeWy+dob0CIQYEuIIUvmj/XEnRSRvD5k0l4o/qZRNrkiGmH7R2KJlAoYwKA2Rx31Ik9VmET2dfNMDibTUQA6D9rHkZEEKBUOKnDEPSSlrheKeBDAzVyVGoN/pZGyXzRLpD7ouIsVnokgAAAAAFw9LzLCAu7CwVOaCiODEG1+DuhD4oh3jciZAwA3WaLRe+q2h3W0O6Mgt0vsJ/MriCy82+1599rzb7Xm32vPvtb87rfndb87rfndb87rzb7Xm32vPvtBiAhmCbWAIAAgIAD7FtDutod0QfWGRyKEhspOoQPjuQv4KG98CpIll0IzJKExExHyKICE328ggggggggggggggggggggggJjLmzqgURnKkfpSLQDkcFGN3Jzm7Jhr8zuWnuRFTfhGSmjz4e1HBGq1vI/qKCDPuCxSsUrFKxSsUrFKxSsUrFKxSsUrFKxSsUrFKxSsUrFKxSsUrFKxSsUrFKxSn3IG5K5YcfFwSPlvhNCr7qee8hGRyWG4OQ4JktvMJrPI5j+gh8Bv5IEwejWHGaW6oEEAgu8Qf5vDAOZWDQOaAYAcEeJVJxbH/AJ0cIdyOTSTJLpzLU5k740aQzF3aMU4IA4P8mB1D1WLQuYcFz26VYVE5FH+IAJMAA50U/B7LBNlzJEAd1gcJ7iizLnEqSOXzL9v5NCqHwU3s3y4LqoeUU8EC4Br/ABM7WSMkClgFyWjH8EE7mXL+WZjcgtVvXwXAEdEJLGA3MfxAVkwdVedpopX+YGVgAoDkiwDJwJY07zqjPrg3Wf8AKE4FzUZqeoHBcfQc0JBOPcP5QxhGQHdQpBIDMQIIWn2RE80ygWMnIEHC+AL7WD+WUu8p+hZzP5wbD1cisgdx/nHuRinUFmh8HpRCgArh/NwxQHOK0+HzwbfjEoMUAmJiYmJiYmJiYmJiYmJiYmJiYmJiYmJiYuUXRZvAchwZqZuYFQHdwPcvLcE2Wq4MSHgRqEK7DrD3Etq5VFOiS51RxaJ3OPgz7XXGmqJEgQRiKEJmBGgJ6oE41YWQ8zZDzNsIeZsh5m2EPM2Q8zbCHmbIeZssPOSJc+MmQQHMwdy/g7oYkCBJPwWVjrX2xzkoQmRMUKQT4MG/w8OiEu2yFtBdoLtBdoLtBdoLtBdoLtBdoLtBdoLtBdoLtBdoLtBdoLtBdoLtBdoLtBdwJ4iKfgycnBjOBoMTBMFD27orA/IPXBEqciNYpngzLHzxEleELwheELwheELwheELwheELwheELwheELwheELwheELwheELwheELwheELwhYCeAD49p//xAArEAEAAgAEBAYDAQEBAQAAAAABABEhMVFhEEFxkVCBobHw8SBAwTDR4WD/2gAIAQEAAT8Q/wDk7i4pKfrUlNZZdS14I5+r1AzKxZ0cwdzHsIR9iCfnYXlzU6Vz+qIOcJmysePpWPDRQo5WJn7JIPxrdto2ArDwNOAPRbPhm1q2rVM+eZVCMbu/AlFqnMiCPOdC5uok6ZD8F/jf+6sbadArI5YWDH3ReccK50uqEmCt02CHQFQMaYl06DRHEioto8+fwJYF6PbpMENWr15Mcr5RkAlRhgOzHSse6ialvf5TH42TDWYSlXcs1igozQJPRcDLi5ZPOYfgzLd9wmMkbXsXhjNMhuCUCfTKW71A7/q9jwJiJZdO0QXQtTRTSLyEh9JWW8eJFxbV5I5CK1bTeBasPkAJ49cW5CrLj6HFLvYC7zcYftJd6bSL48hKOtyC1AOolUxgpYsKVzqcilM/8Anp6X6JCADoO4lZTyNWw1Ei8L6X8+ksl8AqKbIyV0SKovEbPBNbkNaNhcut5OzjD+ba35bsRzzBHZmVe6wTGvOAo8DX8/zAnOTmenDAauTuGaC57YR0wtoVd75xOjzCT5aYhlcsq7lxnNKWJoCMbsKNpj9vXK7C0R29kL5mRBBPdwdgjVcmLbxzXmwbPtYRmZzfRM/TpX2qY+q1N6LPQfD/ACW4s5C+tHL86DzyYBNsl9wcSVej2hIVnA27+xS4QxVvMhNuoJZsQLueiqe3vDSYyVR3ghicjAcyA9ZemP8Aq4vgmjIgGtxzGY/AGuhh2JWRbdgcJgGMxwXuIHV0QBwxEkELYRsyz2SpRyj2bbshY1HK9yMDjkgd4Sod5O7IhYDT+ECZTWgnuploOn9lN9JnvwHII7QPU9yMF2c+lJSBTmPvcJu62wPniMUSmdMepkyrbVFSU4Nop1HMekPFwQBU+Ted+eiZjswLRKFYm9yjXy6VpYRVMC7FJaStqAAAaAeC6cFAHzccdxfmZt60SipRTuucxqu5Mn+IoAAFBptGAAbX15EdWzpTqiiasjZPNgA1dYebkS3dJ77Xifm5qJzQ6D3Xgx7NB9hCl9JQFVgzSlEJ5sXZxlxRzKB6jgzVQh95YMorxgYPVmJ5FcU/uHFmrJrvowC9KClHkQtwXLveJic8JQ+xo5eaRdPURr+WrCtVeRDT5i5a7GUIGQq30DNjDt4wNxEgZQrToBiwkRcbElO9IpKRpwBR0iTEd6gfK8pWHyEZA5oZBdc6xip25cesvkuQrHVUfNLVBumccvEHDomMSphgHKuzBBNG/wDJeoF5h/oRudilLD2ZEyWaHg4dOYBarQG8L+X3BEJLIWS5g6s89MzN9DaNAQUcprOZPRXANA5BpA0OBqDYyhYss4DfN5Efx0vJxmtHVlVkHlhA/K3VOkcoPWOzwqvHZES8dVgu0zA5TEUdnXZhUC4l9buTIDTlP/G+UMIHaGH/ABhAgCiJSOYYcgDdUdCWeCUuri4YUD9jNxvsjVdC5YQc0z1n80lB6VZxaFtrvB9wZhzK2x3dTDNgBhiZeUyPbq5wP9OlQ2zqQtW0oKgZc7nlvBI3PmQ5HUYmEwKOK5JrojNKFEy8xshuaZwj5ZzhpqtpNDdL8DuWxZ+shhy4NUPW5XYafUU6Q7cccz/oPKWUCugYn3LBlvgwDoaw44DiaoBVVR+gLRhHuAUxE79Z1CDLVF6XwDmOowgaXEtpMR9yOohPjOfOXFhhmh817kBaRrDwIn97cgWsfgJvaiiEtt6GuZ5MiByOY+U6RHyyubo29iDZFhDIZjVBwuL0/wDf03KksgiC8Dkb99JfcgzJf6cSVGVXqw3OUxKs5RgTOWOL9KvMio+9u6/RmngLVb5OX+5esNPcHyIWskNA5+/WPjdUzJ18zBWwCllnnSZsovOXL+/q8qSyPBUn2Pe+TFSbbRhkurknJjbjd7wFN9+oleqRAgZc2WMDQK3Rw8AExWRgBmZZeU9DBE591tZz5st3l51zSVt1uUXq2M4tJNiz5y7rixMaMD9YTWRw6R7fFczmUglNyVhHOwJB6g8nCDRl203gjVL01/1i/wB4SVPiaoFyaLZ2mqHNQRrlDf8Ao0nzW5vi/wAqHpHPX9ikT+kMQPLbPQxR7Mp0cEMfhN3kEF8bmqunrlLFPTc3Flft4mcXu5xB9pBHSWt1Vj3WVwNUTLzi/wCzxpYVZSFyuQwubyd5XqhpPiK/spKXskuq9JLumoDNyDzGoaXttpNighHWnQQrlIXPolO/KAa5ftXG8EUmvZpqACAKOkr/ALTO60hMPndFQ9Kp2l3MvhYrQdGDz0PxXEWaQ9ZUnvf+w444448cY44449ynov7XDRIJYjYzTcv8Hxb2nIFX5ZzFhbFySn1lWmqL5uagxZm32AQ8MM8r0tSNmxSrR6iW0srMbr2jCH7CtwwPXDIrA1VYoX52veKuBc91vQM9WFW6OXH3xmn8LO4rjxmo5G7OWG035niMIhObO43L073MdWeaeaeaXu14LNZZrMau2eaeaeaeaIXbTCje7bw9TJ8yBNtCujuVDCy3abH/AI7cuNRHLKBBeXuZ7di5VBCzNIbYsYJ1/sxNAYDBC/JE7y7xavphv7IffvAM0nE+1w4GA0jaa3pwt8Zp4c4TALfkHOKp7tcV5HTbI4UuMF4z66HV5PZ+Fqy0olNDtKaHaU0O0AKwcH82XQXljQHM0jGBcuY5IeSPH5TVwsTFkwXV3jAUgVAanGI5fqYr/a1avycTh66ew4W+M08HaDRi1yG8V7GwtZkDYONynJ9OG7mERVPTjVrwwTLjVeaYdZm8a/Eo2hsyfMyePymrhR75CMyXWLT4lftNX4nU4eunsOFvjNPBFQt5Oh+C3gqqLDq5EFf5cX3qbFaEWGlZCzrz422Jgkx+zMfwoRkvBzDUuEqOaw4mlqJiHeqTyu5ktsCjqPEUaItYnLePTU/B58tq4Ue+QjMr44sznzf2mr8TqcPXT2HC3xmnhkqADRaeN6A6+dmRusJImyKNzjixdo8UC+TFa8rVeoZVirsTbP4XJuI0/CsMxrhc8Md/XQ5zH7/ZnkAzQG89nYm2CSFyStuctSIPQdyc3HYY/M4Py2rhR75CMyPji/t3avxOpw9dPYcLfGaeDva/o4hMG31Qk9YaRbMchcDyMCXLujotmWq3i3VazUSPdAoOCNPG6Gi8ek5Xx3cwiObWpgjQt7rT5RbcRbeeN8DC4hPmDKzbMGtU8clu4fy2rhR75CMyPji/t6QvxOpw9dPYcLfGaeGzCuIOxTdVSTM0/KhivuSiZGJcHaQobIa1G1FQ9Qs7BNpD1jL7oFr5E+NfyfOv5H5sqn6p8E/kQABaoFdpcNHkLJYkdYY1ESCdAPIbcLIb+GXgV7MFCgIZIUPnxWzVcH8tq4Ue+QjMj44v7elL8jrweunsOFvjNPBgsLdS4ONdgQcxgonYl7fEl4v6x6piStUXkyC2IkRas1xK+cxmsVcW0PUY+sWMraZuHk7HealHmwcwoq5hIv2YQswEcucic2IbQdZMURzxWOmKouGc4DRBKxyODhnHcQnNRQPmOHy2rhR75CMyPji8NLn+z1+Z1OHrp7Dhb4zTwd8vRq2o6qGJZlxbc3feDjkVrL0OicEAjkkIhTADjeRlF438s0ZfBQzlQZCVstWcIBHJIFBwRpmFVplM2/wGVrLNT+BDaaLwUHpw+W1cKPfIRmV8cWOj1mv7Gir78gNNIzge9PYcLfGaeF4NXd5xajSgydt2KKGb+FkcC6ek5XwoXkrzmcja41omSbOEvQOcM95b24qxXb0wEKqs24qt288eeu/HlSh6/ioZxu6nXP8A6OPy2rhR75CMCg5fY5x9iPd/Z3HCxp69S/WKh5jAVgGyAsiRMr1hAKtOFvjNPE7Z0Fg+M+TL3EtDB6ekgxxMtYY5QxyxgsHg4CJHVvDF40Rg1Y4VxApAATKbu/wtO0UjQDODjrbV2JUpu/fj8tq4ELQW2QmZEBzgBax6tC/QKg9AjhqQvU6/silaHmFMC1FWmHKggQnm3jWpAlQWqxOpmecBchekaZsXWBY3UvjFRkBXsQyiW4DUTBi0XwzHkZ1Fq5rWlq0sxyM0PoAzJel/2p5555555555558P38MrCLrrKpK0F7hYvSwiWnPS/wAMfzscXlpFEWmXTWOwAXjpehm+UYwDiuasL0IL60MYc2S1lhyCiP7NyMPm2IhoDgLR78WqGIEN7JNsbCdri466GUsVplt5wmzZ3DUIyeovYMECOvJH0mm8vLecr5QBaKuVsTDaVsStiVsStiVsStiVsStiVsStiVsf4A0uS74JYkRz0/5AqgtAj3iKy3alW94jsziCf04cvqEeff3EIAR5JG5+WVPol5u6sRexMKMNbgta9ZKCkfsyWpU2sYqGVwR5AWMDgWIzuEMNOwXcpZhQdf4Mz5emgpTFkCdFuXuA2q9I1MInUyGrBs/pIsNFXcZJtWfMjyRrKYqYEitoTl9+kOjaAAAoOR+7Uqc4Ojv1YJaqEckeTDUKja+9JFJ0zAI9c4mm63+kDCOjo5LBPPf8OVxMDlru0x3ivEXtf0mkNVPnuxiwpW1Ac2H/ANiwHhXgKQRFL0G/tIynGtVgD8ArbpK2r1gqspQFo4UkDFTYdJotsrceXI/rzvm/pGQYI0FgZWuz6BX2tIDwRH9sNTOxd3TaKKTZGpgAwPPUO44df2Dp2DXQG64R8awJiVUB0CNX1O4M4+CFdWFxBgSoy6i/2xpoahnKLIVswdtnbP8AWFMVswNDddM4DS8rm5CQRHU27oXikCgMAByrwY1ROjyE5JLoG6nRD3CYbziK+oa7mJKYGoWLpiII2JYnOZZy89v9ry3lmsUCoALVwCU55Q9JMrcFfaE1gkQ6c7xD9jo1XmnNeb4RUdENgdYK0Gb75mYli0rzz6yqLuIn1mBF9Xnv1YiXvNR63IGAHL+Yz06yr4UvJmfGnR4VU9ekKRBqnqxFDeSn2SI6FWvZUpl2Wr7SMyMWWjvXLrFal8xwr9U9AyeFM5twAbNTmO5HnhywfukPKEcuvosQ63BelmMoUQGudQK+hP6JAbd8GVmabb+AQmfVf8JA8368KzeX3eWZPQ/6WZJtv7FMh3wZSegs3qzEMAeYEQ8kCdaKIqKzM39YsH2eLdlgLzaAW1Wa7srw6mLyjmJYxezlPYFMzqH5xs5E0H++DP6iqNKulYxUwWULssf+2XBI5veJc3iKLrlcNxnucw5XXTKjsIQSNZWO5CQAYAGUrHxNNXKEDmrlFvXz92YSrLB0x5bZRNBXLWLIOSJKCvdaCTTZ1m93Te7pzG0uoxqHdKYtRQG9ymJcXkdEvzjyAafTDODtLugvcuWWV4nyypWD3WLCu9emK2yFCqUhSLMsbzyBel0qjFQ42GSwBOowapheq8kYWmoLxcax0NXYxjuMcpzSJiK8eqZQiZBNdHM6jH0Y6rDUmNGcLy5uJyhkQismj2mzXxFBzl0xozIcFy27XzNdDVciD+PgGa6rzXjUBpiOBPQRb7UGh6M2auHZdQ3/AMTaUwNmVEadDmlV7nOK811eGWBidagzd2CcnSCiedknLmIyvcKS08nwy4slmswmEevEdXl8VrqFqo8ubBH71ml/ND8ShoMEYnQYJczZqPewCHnjO5gy4UYAGmlfgkIM8noCUtW49weWZDkjAYiOTMJhOqWQfBax/despDXlIBLLBf2iwbks+vF06LBhSZBtfCBgfNkcsETl/sCRAgSJhw4IEAIEiJ4OKF1LxiXBbYBAByOLp0Jj6HdykslIEqdWVh0hWCWeCBoFx/QLsRTXkrU/9w0gehBDvpUVdbqk+iH69FFFFFFFFFFFFFFFFFFFFFFX1+d4SQQ1Av8A7oyauzJ6Blngn9UvryJOkBLu4QZPNnO87zvO87zvO87zvO87zvO87zvO87zvO87zvO87zvLdKiaS1MmK0kbW+ugL4Jvjd+ygwu9Ifdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdz7ufdxBU5/oZkL5EZ4x9h8Eq2/v5t9/S/2tRqelkVXReR/PDwS3XHfsRq59+n+fK4JvBYm10GLKIR1KHqxUcgEIAAFDETkjp/nXjn24Sqy2n1tU0mCvBPtvhJixRTfUH+YEo3tJ1b6TFXHfGc6PFZdFgJJybfoJj5QEE7Edeb5QBSsfM/nT/LEzH3hEJLGulrwW6c+xQxUrGOhMCnMa/wAUvskeQLZb8IAuTl0BDY9ajyPrzHlplMB56PqOYxr5R+bmr3EpllyCnzAf5dd6bCQH9PnDJl4JVdJ8WLLR3hXtgv8AxuI5Vd0wusaMICQaGlKrbi50YYvANCf+RV9ISLp7fkJDLwTA/wDoOYsHOYvXj/Q/xzv50hUPmkaK8xKnFGevEcM0IqzlKGZVymOwAPMRsCQ660ez/LpXvgQR8F2yYMOzqly7QJcTyPZ/kJYcEZ84bIYgpCPNl5iaynAAqHhCZWECeTWDH/0VYYLrUFJCq3NZq7q4/wCVin/2l8Vp+C2AQUH+aREudHYv8saii4RmYu+sxkjqvcSbIGzOtWzLlUVV/ni9/KT037/HwVa+qQNliCrcarszcm5Nybk3JuTcm5Nybk3JuTcm5Nybk3JuTcm5Nybk3JuS9Dkh5GEf+LdnPwUR9E7do3+wHBqLtd3JPq9gPBq9WOdcUQ9AApwDleY/sM3hXipwYB1Zacc+qrv1jXRY6I+DTKAq7JpS9pbX5GCiq6jFF4wxHkyribr9mp9en12fXp9dn16fXp9dn16fXZ9en16fXZ9en12fXp9en12fXp9dn1iNS8o2nqsDqu33huxNxtnLEpMAAOhtHwQgxssQFEDBlQANvmEwlnNmOiY6zzmOs855zHWecx1nnPOY6zzmOs855zHWecx14ZxTWMlC1dx1HmZMJo9NsPBgc5EBPnsBumNXN2Tdk3ZN2Tdk3ZN2Tdk3ZN2Tdk3ZN2Tdk3ZN2Tdk3ZN2Tdk3ZN2Td4Szb4UgyztZ7Q7/AH8Ga2aAFFFACKUq8OWkvUdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdphqdpbUjd9MCwcy+UHkO9ToV4LiI0cM+/ifsummmmmmmmmmmmmmmmmmmmmmi7E672B+p//9k=`
waktuafk = `${time}`
reason = 'Nothing'
const limitCount = 25
const arrayBulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']

const bulan = arrayBulan[moment().format('MM') - 1]

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `-[ _*RUNTIME*_ ]-\n${pad(hours)}*Jam* ${pad(minutes)}*Menit* ${pad(seconds)}*Detik*`
}
function tek(seconds){
  function tok(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${tok(hours)} Jam, ${tok(minutes)} Menit, ${tok(seconds)} Detik lalu`
}

function clamp(value, min, max) {
	return Math.min(Math.max(min, value), max)
}

function speedText(speed) {
    let bits = speed * 8;
    const units = ['', 'K', 'M', 'G', 'T'];
    const places = [0, 1, 2, 3, 3];
    let unit = 0;
    while (bits >= 2000 && unit < 4) {
      unit++;
      bits /= 1000;
    }

    return `${bits.toFixed(places[unit])} ${units[unit]}bps`;
}
waktuoff = `${time}`
const { exec } = require("child_process")

const benny = new WAConnection()

benny.on('qr', qr => {
   qrcode.generate(qr, { small: true })
   console.log(`[ ${time} ] QR code is ready`)
})

benny.on('credentials-updated', () => {
   const authInfo = benny.base64EncodedAuthInfo()
   console.log(`credentials updated!`)

   fs.writeFileSync('./benny3.json', JSON.stringify(authInfo, null, '\t'))
})

fs.existsSync('./benny3.json') && benny.loadAuthInfo('./benny3.json')

benny.connect();

benny.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await benny.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await benny.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `*Hai* *@${num.split('@')[0]}*\n*◪* *Welcome in group:*\n*├─* *${mdata.subject}*\n*│*\n*├─* *Intro dulu*\n*├─ ❏* *Nama:* \n*├─ ❏* *Umur:* \n*├─ ❏* *Asal kota:* \n*├─ ❏* *Kelas:* \n*├─ ❏* *Jenis kelamin:* \n*└─ ❏* *Nomor:* ${num.replace('@s.whatsapp.net', '')}\n*Semoga Betah yaa~~*\n${mdata.desc}`
				let buff = await getBuffer(ppimg)
				benny.sendMessage(mdata.id, buff, MessageType.image, {contextInfo: {mentionedJid: [num]}, caption: teks, quoted: { "key": { "participant": `${numbernye}`, "remoteJid": `${setgrup}`, "fromMe": false, "id": "B391837A58338BA8186C47E51FFDFD4A" }, "message": { "documentMessage": { "jpegThumbnail": buff, "mimetype": "application/octet-stream", "title": `*Welcome*`, "fileLength": "36", "pageCount": 0, "fileName": `_*Welcome*_` }}, "messageTimestamp": "1614069378", "status": "PENDING"}})
				} else if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await benny.getProfilePicture(`${num.split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `*◪* *Goodbye* *@${num.split('@')[0]}*\n*◪* *Leave from group:*\n*${mdata.subject}*\n*│*\n*└─ ❏* *Nomor:* ${num.replace('@s.whatsapp.net', '')}\n*GoodBye~~*`
				let buff = await getBuffer(ppimg)
				benny.sendMessage(mdata.id, buff, MessageType.image, {contextInfo: {mentionedJid: [num]}, caption: teks})
		} else if (anu.action == 'promote') {
			num = anu.participants[0]
			try {
					ppimg = await benny.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
			let buff = await getBuffer(ppimg)
			teks = `*◪* *PROMOTE DETECT*\n*├─* *Nomor:* ${num.replace('@s.whatsapp.net', '')}\n*└─ ❏* *@${num.split('@')[0]}*`
			benny.sendMessage(mdata.id, teks, MessageType.text, {contextInfo: {mentionedJid: [num]}, quoted: { "key": { "participant": `${numbernye}`, "remoteJid": `${setgrup}`, "fromMe": false, "id": "B391837A58338BA8186C47E51FFDFD4A" }, "message": { "documentMessage": { "jpegThumbnail": buff, "mimetype": "application/octet-stream", "title": `*PROMOTE*`, "fileLength": "36", "pageCount": 0, "fileName": `_*Welcome*_` }}, "messageTimestamp": "1614069378", "status": "PENDING"}})
		} else if (anu.action == 'demote') {
			num = anu.participants[0]
			try {
					ppimg = await benny.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
			let buff = await getBuffer(ppimg)
			teks = `*◪* *DEMOTE DETECT*\n*├─* *Nomor:* ${num.replace('@s.whatsapp.net', '')}\n*└─ ❏* *@${num.split('@')[0]}*`
			benny.sendMessage(mdata.id, teks, MessageType.text, {contextInfo: {mentionedJid: [num]}, quoted: { "key": { "participant": `${numbernye}`, "remoteJid": `${setgrup}`, "fromMe": false, "id": "B391837A58338BA8186C47E51FFDFD4A" }, "message": { "documentMessage": { "jpegThumbnail": buff, "mimetype": "application/octet-stream", "title": `*DEMOTE*`, "fileLength": "36", "pageCount": 0, "fileName": `_*Welcome*_` }}, "messageTimestamp": "1614069378", "status": "PENDING"}})
		}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	//
	benny.on('CB:Blocklist', json => {
		if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

benny.on('message-update', async (hurtz) => {
	try {
		const from = hurtz.key.remoteJid
		const messageStubType = WA_MESSAGE_STUB_TYPES[hurtz.messageStubType] || 'MESSAGE'
		const dataRevoke = JSON.parse(fs.readFileSync('./src/gc-revoked.json'))
		const dataCtRevoke = JSON.parse(fs.readFileSync('./src/ct-revoked.json'))
		const dataBanCtRevoke = JSON.parse(fs.readFileSync('./src/ct-revoked-banlist.json'))
		const sender = hurtz.key.fromMe ? benny.user.jid : hurtz.key.remoteJid.endsWith('@g.us') ? hurtz.participant : hurtz.key.remoteJid
		const isRevoke = hurtz.key.remoteJid.endsWith('@s.whatsapp.net') ? true : hurtz.key.remoteJid.endsWith('@g.us') ? dataRevoke.includes(from) : false
		const isCtRevoke = hurtz.key.remoteJid.endsWith('@g.us') ? true : dataCtRevoke.data ? true : false
		const isBanCtRevoke = hurtz.key.remoteJid.endsWith('@g.us') ? true : !dataBanCtRevoke.includes(sender) ? true : false

if (messageStubType == 'REVOKE' && isRevoke) {
                    const from = hurtz.key.remoteJid
                    const isGroup = hurtz.key.remoteJid.endsWith('@g.us') ? true : false
                    const sender = hurtz.key.fromMe ? benny.user.jid : isGroup ? hurtz.participant : hurtz.key.remoteJid
                    let int
                    let infoMSG = JSON.parse(fs.readFileSync('./src/.dat/msg.data3.json'))
                    const id_deleted = hurtz.key.id
                    const conts = hurtz.key.fromMe ? benny.user.jid : benny.contacts[sender] || { notify: jid.replace(/@.+/, '') }
                    const pushname = hurtz.key.fromMe ? benny.user.name : conts.notify || conts.vname || conts.name || '-'
                    const opt4tag = {
                         contextInfo: { mentionedJid: [sender] }
                    }
                    for (let i = 0; i < infoMSG.length; i++) {
                         if (infoMSG[i].key.id == id_deleted) {
                              const dataInfo = infoMSG[i]
                              const type = Object.keys(infoMSG[i].message)[0]
                              const timestamp = infoMSG[i].messageTimestamp
                              int = {
                                   no: i,
                                   type: type,
                                   timestamp: timestamp,
                                   data: dataInfo

                              }
                         }
                    }
                    const index = Number(int.no)
                    const body = int.type == 'conversation' ? infoMSG[index].message.conversation : int.type == 'extendedTextMessage' ? infoMSG[index].message.extendedTextMessage.text : int.type == 'imageMessage' ? infoMSG[index].message.imageMessage.caption : int.type == 'stickerMessage' ? 'Sticker' : int.type == 'audioMessage' ? 'Audio' : int.type == 'videoMessage' ? infoMSG[index].videoMessage.caption : infoMSG[index]
                    const mediaData = int.type === 'extendedTextMessage' ? JSON.parse(JSON.stringify(int.data).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : int.data
                    if (int.type == 'conversation' || int.type == 'extendedTextMessage') {
                      var itsme = '0@s.whatsapp.net'
					var split = `${fake}`
					const pingbro23 = {
						contextInfo: {
							participant: itsme,
							quotedMessage: {
								extendedTextMessage: {
									text: split,
								}
							}
						}
					}
                         const strConversation = `\`\`\`[ ⚠️ ] Terdeteksi pengapusan pesan [ ⚠️ ]

Nama : ${pushname} ( @${sender.replace('@s.whatsapp.net', '')} )
Tipe : Text
Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss DD/MM/YYYY')}
Pesan : ${body ? body : '-'}\`\`\`
`
                         benny.sendMessage(from, strConversation, MessageType.text, opt4tag)
                    } else if (int.type == 'stickerMessage') {
                         var itsme = '0@s.whatsapp.net'
					var split = `${fake}`
					const pingbro23 = {
						contextInfo: {
							participant: itsme,
							quotedMessage: {
								extendedTextMessage: {
									text: split,
								}
							}
						}
					}
                         const filename = `${sender.replace('@s.whatsapp.net', '')}-${moment().unix()}`
                         const savedFilename = await benny.downloadAndSaveMediaMessage(int.data, `./media/sticker/${filename}`);
                         const strConversation = `\`\`\`[ ⚠️ ] Terdeteksi pengapusan pesan [ ⚠️ ]

Nama : ${pushname} ( @${sender.replace('@s.whatsapp.net', '')} )
Tipe : Sticker
Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss DD/MM/YYYY')}\`\`\`
`
				const buff = fs.readFileSync(savedFilename)
				benny.sendMessage(from, strConversation, MessageType.text, opt4tag)
				benny.sendMessage(from, buff, MessageType.sticker, pingbro23)
				// console.log(stdout)
				fs.unlinkSync(savedFilename)

			} else if (int.type == 'imageMessage') {
				var itsme = '0@s.whatsapp.net'
					var split = `${fake}`
					const pingbro22 = {
						contextInfo: {
							participant: itsme,
							quotedMessage: {
								extendedTextMessage: {
									text: split,
								}
							}
						}
					}
				const filename = `${sender.replace('@s.whatsapp.net', '')}-${moment().unix()}`
				const savedFilename = await benny.downloadAndSaveMediaMessage(int.data, `./media/revoke/${filename}`);
				const buff = fs.readFileSync(savedFilename)
				const strConversation =  `\`\`\`[ ⚠️ ] Terdeteksi pengapusan pesan [ ⚠️ ]

Nama : ${pushname} ( @${sender.replace('@s.whatsapp.net', '')} )
Tipe : Image
Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss DD/MM/YYYY')}
Pesan : ${body ? body : '-'}\`\`\`
`
                         benny.sendMessage(from, buff, MessageType.image, { contextInfo: { mentionedJid: [sender] }, caption: strConversation })
                         fs.unlinkSync(savedFilename)
			} else if (int.type == 'audioMessageMessage') {

				var itsme = '0@s.whatsapp.net'

					var split = `${fake}`
					const pingbo22 = {
						contextInfo: {
							participant: itsme,
							quotedMessage: {
								extendedTextMessage: {
									text: split,
								}
							}
						}
					}
				const filename = `${sender.replace('@s.whatsapp.net', '')}-${moment().unix()}`
				const savedFilename = await benny.downloadAndSaveMediaMessage(int.data, `./media/revoke/${filename}`);
				const buff = fs.readFileSync(savedFilename)
				const strConversation =  `\`\`\`[ ⚠️ ] Terdeteksi pengapusan pesan [ ⚠️ ]

Nama : ${pushname} ( @${sender.replace('@s.whatsapp.net', '')} )
Tipe : Audio
Waktu : ${moment.unix(int.timestamp).format('HH:mm:ss DD/MM/YYYY')}
Pesan : ${body ? body : '-'}\`\`\`
`
                         benny.sendMessage(from, buff, MessageType.audio, { contextInfo: { mentionedJid: [sender] }, caption: strConversation })
                         fs.unlinkSync(savedFilename)
                         
                    }
               }
	} catch (e) {
		console.log('Message : %s', color(e, 'green'))
		// console.log(e)
	}
})

benny.on('message-new', async (ben) => {
	try {
		const txt = ben.message.conversation
		if (!ben.message) return
		if (ben.key && ben.key.remoteJid == 'status@broadcast') return
		let infoMSG = JSON.parse(fs.readFileSync('./src/.dat/msg.data3.json'))
		infoMSG.push(JSON.parse(JSON.stringify(ben)))
		fs.writeFileSync('./src/.dat/msg.data3.json', JSON.stringify(infoMSG, null, 2))
		const urutan_pesan = infoMSG.length
		if (urutan_pesan > 5000) {
			infoMSG.splice(0, 5000)
			fs.writeFileSync('./src/.dat/msg.data3.json', JSON.stringify(infoMSG, null, 2))
		}
		global.prefix
		global.blocked
		const content = JSON.stringify(ben.message)
		const from = ben.key.remoteJid
		const type = Object.keys(ben.message)[0]
		const barbarkey = '--'
		const naufalkey = 'pendekin'
		const vhtearkey = 'intitleindexofphp'
		const hujankey = 'AdelwinNL'
		const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
		const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
		body = (type === 'conversation' && ben.message.conversation.startsWith(prefix)) ? ben.message.conversation : (type == 'imageMessage') && ben.message.imageMessage.caption.startsWith(prefix) ? ben.message.imageMessage.caption : (type == 'videoMessage') && ben.message.videoMessage.caption.startsWith(prefix) ? ben.message.videoMessage.caption : (type == 'extendedTextMessage') && ben.message.extendedTextMessage.text.startsWith(prefix) ? ben.message.extendedTextMessage.text : ''
		budy = (type === 'conversation') ? ben.message.conversation : (type === 'extendedTextMessage') ? ben.message.extendedTextMessage.text : ''
		const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
		const args = body.trim().split(/ +/).slice(1)
		const isCmd = body.startsWith(prefix)
		const createSerial = require('./src/serial')
		const q = args.join(' ')
		

		mess = {
			wait: '[ WAIT ] Sedang di proses ...⏳',
			success: 'Berhasil!',
			levelon: '❬ ✔ ❭ *enable leveling*',
		    leveloff: ' ❬ X ❭  *disable leveling*',
		    levelnoton: '❬ X ❭ *leveling not aktif*',
			levelnol: '*LEVEL KAKAK MASIH* 0 °-°',
			error: {
				stick: 'Maaf, terjadi kesalahan saat convert gambar ke sticker',
				Iv: 'Linknya mokad:v'
			},
			only : {
				pc: 'Perintah ini hanya bisa digunakan di private chat saja!',
				Registered: `Kamu belum terdaftar di database!\n\nSilakan register dengan format:\n*${prefix}daftar* nama | umur\n\nNote:\nHarap save nomor ku agar bisa mendapatkan serial!!`,
				group: 'Grup only bruh...',
				ownerG: 'Owner grup only bruh...',
				ownerB: 'Lu siapa?',
				admin: 'Mimin grup only bruh...',
				premium: `Premium user only bruh...\nMau jadi user premium?\nChat wa.me/6289636006352`,
				Badmin: 'Jadiin gw admin dlu su!'
			}
		}

		const botNumber = benny.user.jid
		const ownerNumber = ["6289636006352@s.whatsapp.net","6281317635610@s.whatsapp.net"] // ganti nomer lu
		const isGroup = from.endsWith('@g.us')
		const sender = isGroup ? ben.participant : ben.key.remoteJid
		const totalchat = await benny.chats.all()
		pushname = benny.contacts[sender] != undefined ? benny.contacts[sender].vname || benny.contacts[sender].notify : undefined
		const groupMetadata = isGroup ? await benny.groupMetadata(from) : ''
		const groupName = isGroup ? groupMetadata.subject : ''
		const groupId = isGroup ? groupMetadata.jid : ''
		const groupMembers = isGroup ? groupMetadata.participants : ''
		const groupDesc = isGroup ? groupMetadata.desc : ''
		const groupOwner = isGroup ? groupMetadata.owner : ''
		const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
		const isRegistered = register.checkRegisteredUser(sender, _registered)
		const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
		const isGroupAdmins = groupAdmins.includes(sender) || false
		const isLevelingOn = isGroup ? _leveling.includes(from) : false
		const isAntilink = isGroup ? anlink.includes(from) : false
		const isWelkom = isGroup ? welkom.includes(from) : false
		const isKasar = isGroup ? kasar.includes(from) : false
		const isBot = isGroup ? _bot.includes(from) : false
		const isVirus = isGroup ? virus.includes(from) : false
		const isAutoSticker = isGroup ? autostick.includes(from) : false
		const isNsfw = isGroup ? nsfw.includes(from) : false
		const isSimi = isGroup ? samih.includes(from) : false
		const isOwner = ownerNumber.includes(sender)
		const isBanned = _ban.includes(sender)
		const isAfk = _afk.includes(sender)
		const isPremium = premium.checkPremiumUser(sender, _premium)
        const chats = type == 'conversation' || type == 'extendedTextMessage'
		const isUrl = (url) => {
			return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%.+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%+.~#?&/=]*)/, 'gi'))
		}
		const reply = (teks) => {
			benny.sendMessage(from, teks, text, { quoted: ben })
		}
		const cheat = (teks) => {
			benny.sendMessage(from, teks, text, { quoted: { "key": { "participant": `${numbernye}`, "remoteJid": `${setgrup}`, "fromMe": false, "id": "B391837A58338BA8186C47E51FFDFD4A" }, "message": { "documentMessage": { "jpegThumbnail": setthumb, "mimetype": "application/octet-stream", "title": `${fake}`, "fileLength": "36", "pageCount": 0, "fileName": `${fake}` }}, "messageTimestamp": "1614069378", "status": "PENDING"}})
		}
		const bisnis = (teks) => {
		benny.sendMessage(from, teks, text, { quoted: {
    "key": {
      "remoteJid": setgrup,
      "fromMe": false,
	  "participant": numbernye,
      "id": "0D5EAADD1166F55012EB42395DE58D61"
    },
    "message": {
      "productMessage": {
        "product": {
          "productImage": {
            "url": "https://mmg.whatsapp.net/d/f/AsFENZUsypKYO29kpNR2SrgcoBit6mDiApzGccFAPIAq.enc",
            "mimetype": "image/jpeg",
        "fileSha256": "iRrEuDPCvNe6NtOv/n+DARqlS1i2UbWqc25iw+qcwwo=",
        "fileLength": "19247",
        "height": 416,
        "width": 416,
        "mediaKey": "zvebSUI7DcnK9QHuUCJpNAtTsKai0MkvzrcNSYE5pHo=",
        "fileEncSha256": "t6pd+X7iNV/bwtti0KaOOjGBfOVhxPpnwnTs/QnD0Uw=",
        "directPath": "/v/t62.7118-24/29158005_1025181757972162_6878749864442314383_n.enc?oh=c97d5aea20257c3971a7248b339ee42d&oe=60504AC8",
        "mediaKeyTimestamp": "1613162019",
        "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kHjYqJiYqNj40MjQ+TERETF9aX3x8p//CABEIAggCCAMBIgACEQEDEQH/xAAxAAEAAgMBAQAAAAAAAAAAAAAABQYCAwQBBwEBAAMBAAAAAAAAAAAAAAAAAAECAwT/2gAMAwEAAhADEAAAArUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABhnWEeRmmb0x4rNVeRP0JhnnsAAEAkAAAAB5DdFKtn3u7C+cnM/ObnTSUFdAAAAAAAAAAAAAAAAPKFfaVbOTmatPW5sahZaxZdJTj7MewEnNFKzqo8Vq3tB7ISvvzlaPpD551RN6VOTi0y1bYkE1fhlYDTC7c+nGeeB74ifjosIz3AAAAAAAAAAAAAAAAR8gR888vtC0ywnuycrY4YGtrZW5HgvjWt0/vvlC9O7mRIbITUibxhc0yWjR0HJyWDpKpMboyNLd2fOJym1opVzzi3zxK+aZc11zyz19EWAAAAAAAAAAAAAAAAA8+ffQvnts7XyQmi1cJDv6rYZaIrgRIR8lKV2rfZZvYtA7Zv2JhMZ3wrnNa/JilZ26PmOOUgeS2dihO+VUrVvrsbXeb8j5BNsGewAAAAAAAAAAAAAAAAAGPz6cgr5e2LLkvy7IDGbjXhn+nbTXXnkiQSEAAGGaWmPlsUUzK1V69JfhiLHbCsTaGjX6Mj5DLoBIAAAAAAAAAAAAAAAHkZI0Sac1i4pTXk5q/7OxrnLs89QiQAAAAAAGramK1GXOtXrMRPJZbc1avVEl69VpGeoAAAAAAAAAAAAAAA8ICuZymnPJ1yVgbZd9n0dWfSFZAAAAAAAAAc/QmKVI9tc0ysVctcBOdw66pasuv0RYAAAAAAAAAAAAADyKyrM047ZVOzXm1SELc669Iz0AAAAAAAAAAAxqFxhb15eqBkr88Z9A+eStd7mjJPPUEgAAAAAAAAAAAeV2Vo1qJKR7NOSJ5bDwIg7rSrtTpClzmr1q2jRTPJi6KYmLmpgualk3RSxdFMIuamC55UoXxR5eLWFhnSzTuTFE6tM9rhzaJ4yp9k8rkb/R3F25dAJAAAAAAAAAAArkNKcGnPYNW3Vbjy4+zjWg7tSbtTscHZS044F892WGw1a+jnAltz074ePSdWvfoQEgAOq3UeUpa0DPSkzkHObc3br2a2G6tWWvLytjq9oy7giwAAAAAAAAAAFXj5CP157Dq26p48uPs41oO7Um7U7IauSsVaB0zXDt7uZXi5rLBHKJs36NkNoiWjfrlqJFXk3SXKrGeWKvLeCZunRFSuOtJnIOc15+3Xs1sN1esNeXkLRWLPl3BFgAAAAAAAAAAKvHyEfrz2HVt1Tx5cfZxrQd2pN2p2VWNk4y9U5By6kXlv5Vu7t0+qQ7PBd76N5lE4+Z4nNYIGcmkC26lpLX2xqnMJvY5mHmMtaTOQc5pz9uvZrYbq9Ya8vI2esWfLuCLAAAAAAAAAAAVePkI/XnsOrbqnjy4+zjWg7tSbtTsrsLbqjaGWK1ZzZX0Vn4nVtWw36udP0dGyWO4Q0UeegtMtbPnvSf9r5SVihYbU2aRxyy1pM5BzmvP269mthur1hry8jZ6vaMu4IsAAAAAAAAAABV4+dq+mFs1Z424/ePt4kwd2pN2p2KvaMYtRUpF6Zgj3o5dpt0++Hs9XUTbOCCyid7UmNun3yYwAPTyza5qlwpekzkHObc3br2YsNlen6q0nLPBzmXaEWAAAAAAAAAAA10S/ck1qk5X+PXmuEZC61dt2onRG10Q8rnfPg7xXNFqWiqLWKotYqi1iqLWKotYqi1iqZWkQMt0KgiwFJm4XRthcddW1s5Hn226vR0bDPUEgAAAAAAAAAAAY8Xd6iK1TOlHz+fr9z0yqWq98ETBd3nHMSnLHc5vs9PnydGegAAAAAAA5pinWmqfQbRw7+5TTz0ASAAAAAAAAAAAAAABRJPqrWmN3a9mdwk5OsiEmMwESAAAAAAAg5imXr0XqDna2CLgAAAAAAAAAAAAAAAAYUm8aJrTrVU9d87mjZKlgiQAAAAAAAGEfXrV3+43OW3IpqAAAAAAAAAAAAAAAAAABrrtm8V+d7rzDXpxd8PHzF12ULbC8KdtLYq2SbOrPhZ1WwRbFO0F04qnslMxfZKprFgn99ba8/VbAkAAAAAAAAAAAAAAAAAAAABjl4jk5ZOuTGyC0L5ZyXFbyuLGratRVrq16zMxTuytrh1RslS70WAAAAAAAAAAAAAAAAAAAAAAAAatlNmurm2W2+fD1dCtqJZVatS94UzXE92fPa5ZQVhVtRLTjWLV+jexUrnqCQAAAAAAAAAAAAAAAAAAABGIk/KVx2p9BfPRa6i8vS6b6OrN4UcXjVTBZdtVSvCjoXhRxeICGTG2+/OdqfoT56rb6H5QZZNpattbAkAAAAAAAAAAAAAAAADgpE7x6Zb5GR9ZRyRQjkiI5IiOSIjkiI5IiOSIjkiI5IiOSIjkiImCufNKv3P5v9Art0iugAAAAAAAAAAAAAAAAFU5ZCL057ELcgAAAAAAAAAADHLQVS/UH6JTu2imoAAAAAAAAAAAAAAAAEBA2OsaYWoW4gAAAGrlr7Se2QmmNLb7WbHOWYUAAAcnXwJr30b599Bp3+imgAAAAAAAAAAAAAAAAEXTrtRr43F57fhAAAee6E1mw1n6FTt26dymtE7eqM157EJ5AAAEbJRK/BfKRd8+0K6AAAAAAAAAAAAAAAAAc3z/AOjfOb5W3bz9F+EEAAMchUbTwwUdf0XGmc9Nd2/gs1+fYJ5wAAELNQLTZcanbMu0IuAAAAAAAAAAAAAAAAB587+iUC2c72R3fpw5MSuTEZMRkxHvPvJitkiW8zxKZMRkxGTEZMRlXbBW2kvZq/YMu0IuAAAAAAAAAAAAAAAAAot6p1qbJKDnNOIGYJAAAAAAAAAVmxVdrbJuPkMewFgAAAAAAAAAAAAAAAAPI6RrE1gJSKa89kyrJSzKx6WZWPSzKz4WdWfCzqyLMrHpZlY9LMrPhZ1Z8LPprw6uiO2Rr9D94uzLf0JAAAAAAAAAAAAAAAAAUG/VmacEhXPNeeyK4RY1cFjVwWNXBY1cFjVwWNXBY1cFjVwWNXBY1cFkr2G1ayz3J1Y9HoWAAAAAAAAAAAAAAAAAA58RAAAAAAAAAAADcQ2CZAAAAAAAAA//xAAC/9oADAMBAAIAAwAAACEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABD6wAAAIAAAAADVD0AAAAAAAAAAAAAAAACkPWgA3X9nIokAE3IAAAAAAAAAAAAAAAAAExL+jIqcpzi9s7TwAAAAAAAAAAAAAAAAADamRl7UIDv8jj4EAAAAAAAAAAAAAAAAAACqXesUz775xq7W8EAAAAAAAAAAAAAAAACNnq577777774myNAAAAAAAAAAAAAAAAAB5Aj7777777775ltAQAAAAAAAAAAAAAACP15777777777775RnEkAAAAAAAAAAAACiyRz7X8EEwwEEFT6nEKoEAAAAAAAAAAABNNfzUNGEDHAkAECP5RIUIAAAAAAAAAAABUNbwAZxUBUMAOWYDZQJWAAAAAAAAAAAABUNbwFegUd8kOyJUDRQJUIAAAAAAAAAAABUNbyAHAg1z/HnEMP8AUCVKAAAAAAAAAAAA2OX88ICpRDjCBCGB+UKMIAAAAAAAAAAAA+RWBW99EAAAAAUfe+FWEhAAAAAAAAAAAAA4vz2vjF++++++++pWwBAAAAAAAAAAAAAAAAt2sN+++++++++gzAAAAAAAAAAAAAAAAAA8Zz+++88+++++TgAAAAAAAAAAAAAAAAAAAnFZX50w59UUoxAAAAAAAAAAAAAAAAAAAAAAVWfrSZKNgAAAAAAAAAAAAAAAAAAAAAAAAN4sXtc8xoAAAAAAAAAAAAAAAAAAAAAFTy9f9tuf9phyRJAAAAAAAAAAAAAAAAAAo5CCCCCCCCCCC36AAAAAAAAAAAAAAAAAASwyyyyyyyyyyyn9AAAAAAAAAAAAAAAAAANDDDDCJ3qDDDDXsAAAAAAAAAAAAAAAAAALDDDDG/RdDDDDCLAAAAAAAAAAAAAAAAAA9jDDDCFTSDDDDWrAAAAAAAAAAAAAAAAAAqOPPPPu8vPPPPfjAAAAAAAAAAAAAAAAAAEqDCCCCCCCCCCPjAAAAAAAAAAAAAAAAAA9hhJJFFBJJFFdDNAAAAAAAAAAAAAAAAAAX1wwwwwwwwwwwRHAAAAAAAAAAAAAAAAAAABBBBBBBBBBBBBAAAAAAAAAA//EAAL/2gAMAwEAAgADAAAAEPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPEq/tPPPvPPPPPH2b/PPPPPPPPPPPPPPPPOwy6/D8zGNSOPGlKfPPPPPPPPPPPPPPPPAH5tkQ87AI4+PTPPfPPPPPPPPPPPPPPPPPIUR99xiRrTbloafPPPPPPPPPPPPPPPPPODl7Hv/PvvnLbBjFvPPPPPPPPPPPPPPPPOe6LfvvvvvvvvmScPPPPPPPPPPPPPPPPOLj3vvvvvvvvvvu/DkfPPPPPPPPPPPPPPKsznvvvvvvvvvvviXgmvPPPPPPPPPPPPDlk1/tvs8/v884/fuisFUPPPPPPPPPPPPC0KF/AuZwGcKgAAJfg1U+PPPPPPPPPPPPPwq14hdBQFgwQWjUfQ11gvPPPPPPPPPPPPgq1wFI7ZjTgGgYwPQ11lfPPPPPPPPPPPPQq1wUIuLLOm/wA8Eb4NdZTzzzzzzzzzzzy16JewEK5lEE8kIMf4NtsHzzzzzzzzzzzwzqmbX7zn333323375InEXzzzzzzzzzzzzzl5XaG4X77777777rUqHzzzzzzzzzzzzzzyjD7z73777777763rzzzzzzzzzzzzzzzzzznDz77777777bkBzzzzzzzzzzzzzzzzzzzz8txrHnXHN0iLDzzzzzzzzzzzzzzzzzzzzzw2j+157k/zzzzzzzzzzzzzzzzzzzzzzzzwiS2fJ2wcHzzzzzzzzzzzzzzzzzzzzy53EX7/AOs//pyxG0888888888888888888wZDDDDDDDDDDD1d888888888888888888lCAAAAAAAAAAARy888888888888888888JDDDDCbmlDDDDH1888888888888888888HLDDDSJcSDDDDW1888888888888888888yoDDDTdlTDDDDAC888888888888888888LMPPPP+OuPPPPb5888888888888888888CU/wDvvvvvvvvvsa/PPPPPPPPPPPPPPPPPLH/uuttsuuttr1vPPPPPPPPPPPPPPPPPPHls8888888888xx/PPPPPPPPPPPPPPPPPPIQAAAAAAAAAAA/PPPPPPPPPP/xAAtEQABAgQEBgMAAgMBAAAAAAACAAMBBBESEBQyUiAhMDEzQBMiQiNBNFBicf/aAAgBAgEBPwD/AFLbZOOUgoAyGoE6wJjcHBXjYZv5xVjMewJ9mz7w0+lKeZG2USUEfMiwBsi/ChKuEss5dRZT/tRkzRMOj+FHl3wlvDRA3QlM+H0oRISrBMv3p5/8ioNOH2TEt9rzX1h2VOEgA9QJ6WIdCbcJol8g/H8icdI/Tk9RoJcbzMl9R5Qwi8IqMyUey+cl8xIX6d0MwJK7B1kXOaKFJT1JVsh+0cDMQ7o3iPSq8QGUEDwn3wchVsxRQjDv6TDd5YGYgNYojI+/REkw5XkeEy1cN4+kyFjeDzlS6YlamzvGuDwWOU9BlgiLng+do8FCVCVCVCVCVCVCxYOhUwmWSPmKiJD360syJfaOMzqDBtkj7KEssqG9ZQd6yob1lQ3rKhvWUHesqKOWL+sBjTEwExpHUi5Rp1Zcf4cZnUCZbvKqt24QwjhDgeZrzHCGnGYh/KfVY8AYzOoExCjeEUOEcB4XIUcpwP8Alj1WP8cMZnUCa0Bh+cbhVwqo8LvkPgf8x9WW8AYzOoFLFUKcGoaI4W91VSwkI1ioY3Wo41OvBMeY+rLRq1jM6gQOWFyQGJ4RQo2mzUJZoVRCqovqn3q8ocL8auHGHVYe+MkJXacHmfk5wRtkH4QmQ9kMy6sy4sy4sy4sy4sy4sy4sy4jccL94jpX2Tr4wHl14EX9GoOFdCpp8iEbhQzAlqX8BIG2YlyT4DbWHR1KaIhEKKJub/SD+RnG4vyomR9GWCpXKYcvc9Nlz4zr+UbYu/YUQW9+hQsG2CPunnhbG0PVBwg7IZls9YKxk9KjKrKkss6ss6su6sqShLtj3NXy4JyaKPIV/wC+v9v6TfzHpQNuQ1GnjIC5LMOJk726pxoj0GiuHV7TTZOFROOC19AUXXIlVVF4arKknHBBu0EDrgohF8ao4WcvWgJF2UJQy7rKFvTLVg0/Sy5XVisuSy5f0a+F7essW9ZYkDJAWtPy3yFWCyhb0Uq4PqSwiLd6iZKpKpKpKpKpKpKpKpKpKpKpITKHdTTYiVYemxzZBWirRVoq0VaKtFWirRVoq0VaKtFWipzSHpyujjvHfxzncPTlNHFNEQjyUIlDmmTI2a8U15PTk+x8TzYmKGUJANg2w4pny+nJ6j6z/mP05XydZ0quH6bQETnLquiRD9UUPTljEXOfVutTpXOFGHqXnuirz3RV57oq890Vee6KvPdFXnuirz3RV57oq890Vee6KvPdFEZ7un//xAA5EQABAwICBgcIAQMFAAAAAAACAAEDBBIREwUUIjEyUhAhMDNAQlMVICM0QWJzg0NjcqIkUFFhsf/aAAgBAwEBPwD/AGmSQYxxdS1UvE6pq27r8vZ1M9mwHEjrMsts9lUtRfsv4Kr7tS1TwEYmC0eEm2T8LqPqjDoOaMN5p6yJtyLSFIJWua15NWjyoaiAvOhcX3dFcxXngqmpeYLLFo4SHJEuTwRCJDg6qKYY/uVPSiNpujmjDqdVOmYLssEWkru6C5Y18u7YWoVJliUi1SrH+b/J1l14ee7/AC/9Q11RH3kKptIRnwmoqwX41LEMw4rV2zbPMoYBiH7vB13ACkqrYgZlPXkRWQ7ZKHRxFtTKOlEeEE0GG9ZIrKDkTwiipn+in0eJ9Y7CGaopCwl2wVLWs44hwoTE6u5vCVkw7lLNJVyZcfAqWjjiHAEEYssPeMRJSwCX9qlhkpJL4doFR1EZkEjISEutvBVMuWHUq6oMzyA8yo6QY48GQCLD2JCp4RtxRiVDUXt3Rqin+nl8FpGqtEy5Vo+Fy+KXEajjtHsyG5VlMJiYP5lo2YgLIPiBQyXx4+AnnFgNhVbTy1FjCdqpYxGweX38femDEcVNTS62EsapZhC5iQmJbu2qprRsbiVRpErrIVTVk5TAJqm3H0PMIJ6lawtaWsktaPkWsLWlrKGoF96uRKsmKGJyFBpCpEutUVbeN7ICuHHtdJOTXv8A00Kpfmo/yKm3GpjsHBEVyxw60/8Ax0N0P0YP0QzYdT9Gkvl/2IVosvimKp3+CHa6T4ZvxoVS/NR/kVNuNTvjIiewbnQz1cnXGGz96hmvKwuLoboJGYxheazaw9sYQFlFLmf39Eb4jitJfL/sTcK0b3361TdwHa6T4ZvxoVS/NR/kVNuNSd4aq2J6Y1GQkAOydxKtC301grC5FaScSbeq1sIwJ+EZNtdTjiyj2q03D0+iPuwWkvl/2JuFaN779apu4DtdJ/zfjQql+aj/ACKm3GpwwNf9OipI7vhnIAqGIYx2OJD1FigcSZYNyqqMTLAUbC42kipBx2JJBFRxiA7KYUDYDgtJfL/sTcK0b37/AI1TdwHa6QjInNv6abqe1UvzUf5FTbjRheKMLehk6CeQOpiT1chLFP0YKGG3rfo0l8v+xNwrRYbZmqZsIQbtZ4cwfuVZo4ZCxfYUGjgikA71DJZvV4v51YP1WRGsgVqwrIjWRGsiNZEayIkMYt01MGcLgg0UP1NUtGI+TZQtb2ziL7wRRC4ngCgYXKx0VOXlWE7IpJGUBkRYP2VIAkR4poo28iZsPAyDlT9No/VMAtw9jOeAqmjsj8HPFmDh5kBFF1GhIS3djwo5xbcoICkK8/CnCMnEjpJA4DTlOG8E1RgtYZZ8Sz4lnxLWmTyyFuQxTyb1HSCHW6w+jeHe36qR4Q3gpJGPgBQxibdayY1MAgWDKOeNuMEFhdY+KmmGMcXQjJJtkmAWHBYFCWC1huRRg5HiaOIXQmUBfagO/r8MRCO9PWxfRa8PKpZsw8fKhqBEcFrQrWI/qCzoeVawK1oUc4mKgqsscHWvDyoKuIt6xZ/B1cu1h5VmLMWYsxZizFmLMWYsxZizEMipJCIbX8HpFi+Ngr5OdXyc6vk51fJzrMk51mSc6vLnWZJzq+TnV8nOr5OdXyc6hOQpWC9UHEfg9IDx/j96koCl+IfCn0VDvskVTRlCX2e7TDdUB+RUTbJeDrh20+9/cjG+VgVDCLvjyp2uHCxaSjHLmDl92hbGqBUfd+Dr/IpRtmP3BK07lQ1ok14+ZPWBbwrSVVsmF+2fu6OH/UgqTuvB1rbIKqbCoP8AJ7oSSRlsJ66q50REZXF7ujB+N+tU3cB4Ot7tV8ds5F2mjQLbNQjhGHg5nEYyvUsUcnUS9nwr2dAvZ0C9nQL2dAvZ0C9nQL2dAvZ0C9nQIdH07KFo4yDlQvs4+DqoyMOpS0rSFi5yCtQb1pFqLetItRb1pFqLetItRb1pFqLetItRb1pFqLetItRb1pFqLetItRb1pFBTEG43JQiQRgz+Eyo+VllR8rLKj5WWVHyssqPlZZUfKyyo+VllR8rLKj5WWVHyssqPlZZUfKyYAHcLdn//xABEEAABAwECBQ4NBQEAAwEAAAABAAIDBAUREiExQXEQExQVIjI0UVJTYZGSoSAjMDNAQlBUYmNygbFDc4LB0SREcOHx/9oACAEBAAE/Av8A0mXNaCSbgFVW268tpwLuWf6RtKuv4Q5Q2zWM3xDx0qkrYapt7MuducejV1rMpyY2DCf3BPtSvefPXdATLUr2Hz1/QQqK1o5zrcgwX9x9iW3VnCFO04sr1T08lRJgM/8AxCxo8HHI4lVNA6IYTTe3P0KnnfTzNkZm71G9r2Ne3IRePv6JadUaamJbv3YmrGTixkqGxtzfK/HxBT2UBvHG/iKILT0hWXVGopt1v24j7DrXYVZUH4z3KxmtELjnLtR1xLuIp4wXuHSrIN9BD9/z5LXY+W3rQc05x5G3ydcgHwlWW1uywTmF+pLlCtNoFRparAPjZx8I9h2rCY66TifugrOqmx3scbgTeCsJ3GqmpbAzLuswWVUUWs0sLM4bj8Caqp4R4yVrVLbsA82xz+4KS3Kt29DG96daFa7LUP8Ati/Cs6vc+Dxt5IOXjVbVuNLLrYN9yuVybLKzeyPGgplpVzMk7vvjUdvVI38bXdyitukfv8Jh6f8A4o5o5Bex4cOjwLehJjilHqkg/dU02szNfmzpk2Ey9j7wnvaxuE92JVM2vTF2bMrBhIZLKfWIA+3sOvohVxXZHDelSwyQvLJGkFNllaLg9w+6JKsuzHF7Zpm3Ab1vgWxWzxyiGN2CMG8kZVlTKeZ+RhTbNk9Z4Hem2dCMpcUyNrG4LRcFcVsaLmm9S2JBzLUaGn5FydZsfqvIT7OmGQgp8UrN8whMe+M4TXEHjCp7bnZilGGOoqmrqap82/HyTl1JI2yMcxwvByqtoJaV5xXszO/1Ne9u9cRoTnvdvnE6VR0MtU8XC5md/wDiijbFG1jRiHsSWGKZt0jA4dKmAbNK0ZA9w71Y9PAaZsutjDvOPUq66ClG7O6zNGVC3ajXbzGzA4s/Wn1TnDc4gpoI59/l41HSRM3rPuUcFgvc4BOr6VuQl2hOtXkw9ZRtOo4mj7LbCr5fcFs+r53uCFoVXLB+ybak+drCm2oz1oupMrKV+R92lYN+hS0UL/VwT0KWhlZk3Q6FjBxG4qktmVlzZ923lZ1FNHKzCY8EIgEXEYlbEEUNQwRsDb2Y1Y8EU1S4SMDgGXhAAC4C4exqnhE/7j/yrG4Az6nflV9sYN8dPlzv/wARJcSSSSc6goHP3T8Q4s6DVLVU8OU3niCltKZ293I705znG9xJTIpJN4wnQE2zao+qBpKbZD88w6kLIZnmd1LaiLnXo2QM0x6k6yJfVkae5PoKtv6d+hEEG4gjSmTSx7x5ChtR2SVt/SFHJFNvHKekjlyi48oKemkhOPJxqnqZqd+FG67jGY6VRWhFVN4njK1W9wiL9tWDwqT9v+/Y9Rwif9x35WzJditp24m48LpTI3SOwWjGqaiZHjyu4/8AFJLFC3Ce5T2hLJiZuW96AJNwyqGy5n+cOAO9RUFLH6mEfiQWCVgLA6VgdKwOlYCwSnsa4XOaCOlS2ZA/eXsPcp6GeHNhN4wg4g3gkFU9pZpu0rmPbiuIKqaC690Y0t/xNc5jg5puIzqrq3VWtl43TW3HpVg8Kk/b/v2MSpyDPMRkL3flQwvmfghQU7Im3D7njVVWsh3Lcb/wpJHSOwnG8qloJZ90dyzj49CgpoYRuG/fOsFYI8jiWCiCqighmx713GFPTSwG540HMoKmSA7nJnChninbe3q4lWUWFu2b7i49SwiBVvx5Y/Y1sV+WmjP1n+lHG6Vwa1U9O2Ftw61W1utbhm+4+JYyeMlUlnYNz5suZv8AqDUBd5YtT4w4Frm3hVlnmK97MbPwopHxPDmnGqapZOy/P6wVbR4Q1xmXP0prnMcHNNxBxFUFa2qhv9cb4exLTrdjQ7nfu3v+rGT0lUdNrLMe+OVVtXrLcFu/Pcsbj0lUNCId2/f/AIQbx+hFqr6DBvliG5zjiUcro3hzTjCgmZPHhD7hV9LgHXG5DlVJUvppmyN+44wo5GyMa9uQjF7Cc4NaXE4hlVXUmpndIcnqjiCs6mv8a7+KqJxDGXH7BPe57i5xxlWdR4AErxujvRxJrfRHNVfSay7DYNwe5U1QYJL8xyrcyM42kKpgMMhbmzKxazBfsd2Q7zT7CtuqwYxA3K7G7QoYjLI1gzprQxoaMgVbUa9L8IyKzqXXX4bhuG95TW+jSxNcxzXDcnKqiF0ErmH7HjVm1H6J/iq6DXocW+bjCa5zXAtNxGRUdQKinZJ16fYBIAJKqp9kVEknGcWhWZDcwyH1smhWhPrcWCMrkxjnua0ZTkVPC2JjWDIPSLRptcivG+ZjTXFrg4HGFFIJY2vGcKvh1qfFkdjCsSpwZnQnI/GNPsC159aoyBlkOCmML3taM5TWhrQ0ZALlWTa7O45hiCsmC/ClOhvpLheq2DWZ3Ab04wrLl30R0hV8WuQX5241G90b2vblab1FI2SNj25HC/06rtSnp9zvn8kf2q2ukrHNLmhobkCjkdG8PblC2xqMEjc5MqAvNwVNEIomM4hd6Va0N8WHyT3FQya1Kx/EVLahOJjMXTqUlrTU8YjwGuaMnGqW06aoNwOC7kn0y1LSLSYITj9d39BAFxuAvKjsyU75wb3rapvOnqVTQGFmHh3i9U/n4frahk8Fzmt3zgFsyk5+PrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzKT3iPrWzKT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrWzaT3iPrQqqZ2SdnX4U8Ykjc05xd1pwLXFpyg3KCjlmxjEONCyhzvcpLMlaNw4O7kQWnHiIVl2m55EExx+o7j0+lV9Rsele/Pm0rGT0qkpWwsxjdnLq2jwU6QqbhEP7jfAqauGnbe848wzlT2pUy704A6MqJLje4k6fQI5ZYj4t5boVNbDhinF/wAQTJGSMDmG8cfgT+fl+tys7grdJ1aulEzLwN2Mixg8SoKjZFMx+fPp9Jt9+5p2dJPUqBmHUt6MeocqarR4KdIVNwiH9xurXVraZmLG85B/ae973lzjeTn1ABqPHgMyeA8eQpauSmfe3J6zeNRSsmjbI04jq1HCJv3HflWdwVukp2TVrmYFS/pxqwH7moZxEHr9Jt/zlP8AS5WZwg/QdQ5U1WjwU6QqbhEP7jdSR7Y2Oe7IBeVPM6aV0js/d0arDqHwGnH4BGLyNl1WtTa2d4/uOrUcIm/cd+VZ3BW6SnZNW0+E/wAQrA87UfS30m3/ADlP9LlZnCD9B1DlTVaPBTpCpuEQ/uN1LZluiZHyjf1eBDHI924aSthVXI705jmG5wIKdl8AZPAcLjqx088m8YSjQVQ/TRBGUeBSy69TxycYx6lRwib63flWdwVukp2TVtLhP8QrA85UaG+k2/5yn+lyszhB+g6hypqtHgp0hU3CIf3G6lsOvqgOJg1aWAzyYObOpqmGkaGMbj4kLTmy4LEy