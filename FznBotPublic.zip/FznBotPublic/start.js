const {
    WAConnection: _WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange,
	Browsers
} = require('@adiwajshing/baileys')
const fs = require('fs')
const CFonts = require('cfonts')
const { spawn, exec, execSync, spawnSync } = require("child_process")
const chalk = require('chalk')
global.welkom = JSON.parse(fs.readFileSync('./database/welcome.json'))
const readline = require('readline');
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const simple = require('./lib/myfunc')
const WAConnection = simple.WAConnection(_WAConnection)
// COLOR
const color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text)
}
 
//BANNER
console.clear()
CFonts.say('FZNBOT', {
  font: 'chrome',
  align: 'center',
  gradient: ['red', 'magenta']
})
CFonts.say(`PUBLIC WA BOT BY FAZONE\nJust For Fun :v`, {
  font: 'console',
  align: 'center',
  gradient: ['red', 'magenta']
})
global.gas = []
require('./handler.js')
nocache('./handler.js', (module) => {
console.log(`${module} Telah Di Perbarui!!!`)
})

const start = async (sesi) => {
	const fzn = new WAConnection()
	global.fzn = fzn
	fzn.logger.level = 'warn'
	//fzn.browserDescription = Browsers.ubuntu('Safari')
	fzn.browserDescription = ['Fazone','Safari','18.04']
	//fzn.version = [2, 2119, 6]
    fzn.on('qr', () => {
        console.log(color('[','white'), color('!','red'), color(']','white'), 'SCAN QR TO CONNECT')
    })

    fs.existsSync(`./${sesi}.json`) && fzn.loadAuthInfo(`./${sesi}.json`)
    fzn.on('connecting', () => {
        console.log(color('Connecting...', 'red'))
    })
    fzn.on('open', () => {
        console.log(color('Connected...', 'green'))
    })
    await fzn.connect({timeoutMs: 30*1000})
        fs.writeFileSync(`./${sesi}.json`, JSON.stringify(fzn.base64EncodedAuthInfo(), null, '\t'))

    fzn.on('group-participants-update', async (anu) => {
		if (!global.welkom.includes(anu.jid)) return
		//client.updatePresence(from, Presence.unavailable)
		try {
			const mdata = await fzn.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await client.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				pushname = fzn.contacts[num].notify || fzn.contacts[num].vname
				teks = `[ *GRUP ${mdata.subject}* ] \n*__________________________*\n*User* : @${num.split('@')[0]}\n*Nama* : ${pushname}\n*Pesan Saya* : Hai Salam Kenal Member Baru...\nSemoga Betah ya :)\n*__________________________*\n`
				buff = await getBuffer(ppimg)
				fzn.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} else if (anu.action == 'remove') {
				num = anu.participants[0]
				teks = `Semoga Tenang Di Alam Sana @${num.split('@')[0]}`
				buff = await getBuffer(ppimg)
				fzn.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
	fzn.on('chat-update', async (message) => {  
        require('./handler.js')(fzn, message)
    })
}

if (!process.argv[2]){
rl.question('Enter Session Name: ', (answer) => {
      console.log('  ')
  if (!fs.existsSync(`./${answer}.json`)){
  console.log(color('[ CLIENT ]'), 'CREATING NEW CLIENT NAME: '+ answer)
  } else {
  console.log(color('[ CLIENT ]'), 'Connecting to SESSION NAME: '+ answer)
  }
  sessionname = answer
  global.gas.push(sessionname)
   rl.close();
start(sessionname)
});
} else if (process.argv[2]){
    sessionname = process.argv[2]
  console.log('  ')
   if (!fs.existsSync(`./${sessionname}.json`)){
  console.log(color('[ CLIENT ]'), 'CREATING NEW CLIENT NAME:'+ sessionname)
  } else {
  console.log(color('[ CLIENT ]'), 'Connecting to SESSION NAME: '+ sessionname)
}
global.gas.push(sessionname)
start(sessionname)
 rl.close();
}

/**
 * Uncache if there is file change
 * @param {string} module Module name or path
 * @param {function} cb <optional> 
 */
function nocache(module, cb = () => { }) {
    console.log('Module', `'${module}'`, 'is now being watched for changes')
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
}

function changeRes(module, cb){
	fs.watchFile(require.resolve(module), () => {
	 delete require.cache[require.resolve(module)]
	 if (cb) cb(module)
    })
}

/**
 * Uncache a module
 * @param {string} module Module name or path
 */
function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
}
